public interface MailSender {
    void send(String to, String body);
}
