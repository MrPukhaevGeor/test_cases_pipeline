public class NotificationService {

    private final MailSender mailSender;

    public NotificationService(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendNotification(User user, String message) {
        String body = "<html>" + message + "</html>";
        mailSender.send(user.getEmail(), body);
    }
}
