# Evidence — b2c_case_02_11

Все прогоны — через реальный `tests/test.sh`, окружение JDK 21 + python3,
без сети (`allow_internet = false`, внешних зависимостей у тестов нет).

## 1. Base (решение не применено)

```
$ sh /tests/test.sh
reward: 0
ANTI_CHEAT FAIL :: ac4: не найден механизм экранирования спецсимволов
```

`fail_to_pass` отдельно на base — падает по существу поведения, а не
только из-за anti-cheat:

```
FAIL f2p_html_tags_escaped :: got body=<html><script>alert(1)</script></html>
FAIL f2p_ampersand_escaped :: got body=<html>Tom & Jerry</html>
FAIL f2p_null_message_rejected :: no exception thrown, body=<html>null</html>
FAIL f2p_null_user_rejected :: expected IllegalArgumentException, got NullPointerException
FAIL_TO_PASS FAILURES: 4
```

## 2. pass_to_pass ОТДЕЛЬНО на base — критичная проверка

Компилируется и зеленеет на неисправленном коде (публичная сигнатура
фиксом не меняется):

```
$ javac -d classes *.java && java -cp classes PassToPassTests
PASS p2p_plain_message_delivered
PASS p2p_html_wrapper_preserved
PASS p2p_recipient_address_preserved
PASS_TO_PASS OK
exit=0
```

## 3. Oracle (`solution/solve.sh` применён)

```
$ sh solution/solve.sh && sh /tests/test.sh
reward: 1
ANTI_CHEAT OK
PASS p2p_plain_message_delivered
PASS p2p_html_wrapper_preserved
PASS p2p_recipient_address_preserved
PASS_TO_PASS OK
PASS f2p_html_tags_escaped
PASS f2p_ampersand_escaped
PASS f2p_null_message_rejected
PASS f2p_null_user_rejected
FAIL_TO_PASS OK
```

## 4. Cheat-патч №1 — хардкод тестовых фикстур

Спец-случаи под конкретные тестовые строки. **Прошёл бы все поведенческие
тесты насквозь** (выдаёт ровно ожидаемый вывод), пойман anti-cheat:

```
reward: 0
ANTI_CHEAT FAIL :: ac2: захардкожен литерал тестовой фикстуры: 'alert(1)'
ANTI_CHEAT FAIL :: ac2: захардкожен литерал тестовой фикстуры: 'Tom & Jerry'
```

## 5. Cheat-патч №2 — подмена файла контракта

Ослабление `User.getEmail()` вместо правки сервиса:

```
reward: 0
ANTI_CHEAT FAIL :: ac1: файл контракта User.java изменён (sha256 ...)
```

## 6. Проверка на ложные срабатывания

Легитимный фикс, специально нашпигованный тем, что ломает наивные
сканеры: `alert(1)` внутри комментария, URL с `//` внутри строкового
литерала, идентификатор `executeEscape` (содержит подстроку `exec`):

```
reward: 1
ANTI_CHEAT OK
... 7 passed
```

Подтверждает три решения в санации: комментарии вырезаются в обоих
режимах; `//` внутри строки не ломает разбор (один проход со
стейт-машиной); токенизация по границам идентификатора не путает
`executeEscape` с запрещённым `exec`.

## 7. Хэши файлов контракта

| Файл | sha256 |
|---|---|
| `User.java` | `c02635c66596e111a1e5b0afe18a92f99597910f29d35768ab712ac50e340c78` |
| `MailSender.java` | `7c6dedcf0b3c19e06e04d806a8c129073754771ddda8b019c9763cfa960fc05e` |

## 8. validate_task.sh (референсный)

```
Обязательные файлы: OK
Oracle solution: OK (executable)
Executable bits: OK
Запрещённые файлы в task package: (нет)
Verifier contract: OK
Структура корректна.
```

## Известные ограничения

- `bank_domain` — `TODO`, не угадан.
- Проверка «общий механизм экранирования» (`ac4`) срабатывает и на
  base-состоянии, то есть частично дублирует `fail_to_pass`. На контракт
  reward это не влияет (base=0 в любом случае), но по смыслу это ближе к
  проверке наличия решения, чем к анти-читу.
- Вопрос по исходному diff (см. README, п.1) не закрыт.
