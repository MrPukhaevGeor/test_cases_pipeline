#!/bin/sh
set -e

cat > /app/src/NotificationService.java << 'JAVA_EOF'
public class NotificationService {

    private final MailSender mailSender;

    public NotificationService(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendNotification(User user, String message) {
        if (user == null) {
            throw new IllegalArgumentException("user must not be null");
        }
        if (message == null) {
            throw new IllegalArgumentException("message must not be null");
        }
        String body = "<html>" + escapeHtml(message) + "</html>";
        mailSender.send(user.getEmail(), body);
    }

    private static String escapeHtml(String raw) {
        StringBuilder sb = new StringBuilder(raw.length());
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            switch (ch) {
                case '&':
                    sb.append("&amp;");
                    break;
                case '<':
                    sb.append("&lt;");
                    break;
                case '>':
                    sb.append("&gt;");
                    break;
                case '"':
                    sb.append("&quot;");
                    break;
                case '\'':
                    sb.append("&#39;");
                    break;
                default:
                    sb.append(ch);
            }
        }
        return sb.toString();
    }
}
JAVA_EOF

echo "solution applied"
