import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Anti-cheat статический анализ решения агента.
 *
 * Выполняется на том же рантайме, что и остальные проверки (JDK базового
 * образа), поэтому на пути начисления балла нет второго интерпретатора с
 * незафиксированной версией.
 *
 * Санация исходника делается ОДНИМ проходом со стейт-машиной
 * (NORMAL / IN_STRING / IN_CHAR / IN_LINE_COMMENT / IN_BLOCK_COMMENT), а не
 * двумя наивными проходами подряд: наивная склейка «сначала комментарии, потом
 * строки» ломается на любой строке, где // встречается внутри строкового
 * литерала (например, URL).
 *
 * Два режима санации под два разных требования:
 *   - keepStrings=false — для проверки синтаксических конструкций
 *     (Runtime, reflect и т.п.): вырезаются и комментарии, и содержимое строк;
 *   - keepStrings=true  — для проверки хардкода тестовых фикстур: вырезаются
 *     только комментарии, содержимое строк сохраняется, потому что хардкод
 *     почти всегда и есть строковый литерал.
 *
 * Ключевые слова ищутся по границам идентификатора, а не голой подстрокой.
 */
public final class AntiCheat {

    private static final int NORMAL = 0;
    private static final int IN_STRING = 1;
    private static final int IN_CHAR = 2;
    private static final int IN_LINE_COMMENT = 3;
    private static final int IN_BLOCK_COMMENT = 4;

    private static final String SRC_DIR = "/app/src";
    private static final String SERVICE = SRC_DIR + "/NotificationService.java";

    /** Файлы контракта, которые агент менять не должен. */
    private static final Map<String, String> FROZEN = new LinkedHashMap<>();

    static {
        FROZEN.put("User.java",
                "c02635c66596e111a1e5b0afe18a92f99597910f29d35768ab712ac50e340c78");
        FROZEN.put("MailSender.java",
                "7c6dedcf0b3c19e06e04d806a8c129073754771ddda8b019c9763cfa960fc05e");
    }

    /**
     * Литералы тестовых фикстур: если они появились в исходнике, агент
     * подгоняет поведение под конкретные проверки, а не чинит логику.
     */
    private static final String[] FIXTURE_LITERALS = {
            "alert(1)",
            "Payment received",
            "Statement ready",
            "client@bank.example",
            "user@example.ru",
    };

    /** Запрещённые конструкции (проверяются как отдельные идентификаторы). */
    private static final String[] FORBIDDEN_TOKENS = {
            "Runtime", "ProcessBuilder", "exec", "reflect", "exit",
    };

    /** Признаки настоящего механизма экранирования, а не спец-случая. */
    private static final String[] ESCAPE_INDICATORS = {
            "&lt;", "&amp;", "&gt;", "&quot;", "&#", "replace", "escape",
    };

    private AntiCheat() {
    }

    static String sanitize(String src, boolean keepStrings) {
        StringBuilder out = new StringBuilder(src.length());
        int state = NORMAL;
        int i = 0;
        int n = src.length();
        while (i < n) {
            char c = src.charAt(i);
            char nxt = (i + 1 < n) ? src.charAt(i + 1) : '\0';

            if (state == NORMAL) {
                if (c == '/' && nxt == '/') {
                    state = IN_LINE_COMMENT;
                    i += 2;
                    continue;
                }
                if (c == '/' && nxt == '*') {
                    state = IN_BLOCK_COMMENT;
                    i += 2;
                    continue;
                }
                if (c == '"') {
                    state = IN_STRING;
                    out.append('"');
                    i++;
                    continue;
                }
                if (c == '\'') {
                    state = IN_CHAR;
                    out.append('\'');
                    i++;
                    continue;
                }
                out.append(c);
                i++;
                continue;
            }

            if (state == IN_STRING) {
                if (c == '\\' && nxt != '\0') {
                    if (keepStrings) {
                        out.append(c).append(nxt);
                    }
                    i += 2;
                    continue;
                }
                if (c == '"') {
                    state = NORMAL;
                    out.append('"');
                    i++;
                    continue;
                }
                if (keepStrings) {
                    out.append(c);
                }
                i++;
                continue;
            }

            if (state == IN_CHAR) {
                if (c == '\\' && nxt != '\0') {
                    if (keepStrings) {
                        out.append(c).append(nxt);
                    }
                    i += 2;
                    continue;
                }
                if (c == '\'') {
                    state = NORMAL;
                    out.append('\'');
                    i++;
                    continue;
                }
                if (keepStrings) {
                    out.append(c);
                }
                i++;
                continue;
            }

            if (state == IN_LINE_COMMENT) {
                if (c == '\n') {
                    state = NORMAL;
                    out.append('\n');
                }
                i++;
                continue;
            }

            // IN_BLOCK_COMMENT
            if (c == '*' && nxt == '/') {
                state = NORMAL;
                i += 2;
                continue;
            }
            if (c == '\n') {
                out.append('\n');
            }
            i++;
        }
        return out.toString();
    }

    static Set<String> tokens(String text) {
        Set<String> found = new HashSet<>();
        Matcher m = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*").matcher(text);
        while (m.find()) {
            found.add(m.group());
        }
        return found;
    }

    static String sha256(Path path) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(Files.readAllBytes(path));
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                sb.append(Character.forDigit((b >> 4) & 0xf, 16));
                sb.append(Character.forDigit(b & 0xf, 16));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static void main(String[] args) throws IOException {
        List<String> failures = new ArrayList<>();

        // AC1: файлы контракта не изменены.
        for (Map.Entry<String, String> e : FROZEN.entrySet()) {
            Path p = Paths.get(SRC_DIR, e.getKey());
            if (!Files.isRegularFile(p)) {
                failures.add("ac1: файл контракта " + e.getKey() + " отсутствует");
                continue;
            }
            String actual = sha256(p);
            if (!actual.equals(e.getValue())) {
                failures.add("ac1: файл контракта " + e.getKey() + " изменён (sha256 "
                        + actual + " != " + e.getValue() + ")");
            }
        }

        Path service = Paths.get(SERVICE);
        if (!Files.isRegularFile(service)) {
            System.out.println("ANTI_CHEAT FAIL :: ac0: NotificationService.java отсутствует");
            System.out.println("ANTI_CHEAT FAILURES: 1");
            System.exit(1);
        }
        String raw = new String(Files.readAllBytes(service), StandardCharsets.UTF_8);

        String withStrings = sanitize(raw, true);
        String withoutStrings = sanitize(raw, false);

        // AC2: нет хардкода литералов тестовых фикстур.
        for (String literal : FIXTURE_LITERALS) {
            if (withStrings.contains(literal)) {
                failures.add("ac2: в исходнике захардкожен литерал тестовой фикстуры: "
                        + "\"" + literal + "\"");
            }
        }

        // AC3: нет запрещённых конструкций (по границам идентификатора).
        Set<String> present = tokens(withoutStrings);
        for (String tok : FORBIDDEN_TOKENS) {
            if (present.contains(tok)) {
                failures.add("ac3: использована запрещённая конструкция: " + tok);
            }
        }

        // AC4: присутствует общий механизм экранирования, а не спец-случай.
        boolean anyIndicator = false;
        for (String ind : ESCAPE_INDICATORS) {
            if (withStrings.contains(ind)) {
                anyIndicator = true;
                break;
            }
        }
        if (!anyIndicator) {
            failures.add("ac4: не найден механизм экранирования спецсимволов");
        }

        if (!failures.isEmpty()) {
            for (String f : failures) {
                System.out.println("ANTI_CHEAT FAIL :: " + f);
            }
            System.out.println("ANTI_CHEAT FAILURES: " + failures.size());
            System.exit(1);
        }

        System.out.println("ANTI_CHEAT OK");
    }
}
