/**
 * Общие инварианты экранирования для проверок кейса.
 *
 * Проверка НЕ сверяется с конкретным литералом эталона: корректных
 * представлений HTML-сущности несколько, и любое из них выполняет контракт.
 * Принимаются именованные (&amp; &lt; &gt; &quot; &apos;) и числовые ссылки
 * в десятичной (&#38;) и шестнадцатеричной (&#x26;) форме.
 *
 * Контракт задания проверяется двумя инвариантами:
 *   1) БЕЗОПАСНОСТЬ  — в теле письма не осталось сырых спецсимволов, то есть
 *      пользовательский текст не может быть интерпретирован как разметка;
 *   2) СОХРАННОСТЬ    — обратное декодирование сущностей даёт ровно исходный
 *      текст сообщения, то есть экранирование ничего не потеряло и не исказило.
 */
public final class EscapeCheck {

    static final char[] SPECIALS = {'&', '<', '>', '"', '\''};

    private EscapeCheck() {
    }

    /** Внутренняя часть тела письма между обёрткой <html> и </html>. */
    static String inner(String body) {
        if (body == null) {
            return null;
        }
        if (!body.startsWith("<html>") || !body.endsWith("</html>")) {
            return null;
        }
        return body.substring("<html>".length(), body.length() - "</html>".length());
    }

    /** Длина корректной HTML-сущности, начинающейся в позиции i, либо -1. */
    private static int entityLength(String s, int i) {
        if (s.charAt(i) != '&') {
            return -1;
        }
        int semi = s.indexOf(';', i + 1);
        if (semi < 0 || semi - i > 12) {
            return -1;
        }
        String inside = s.substring(i + 1, semi);
        if (inside.isEmpty()) {
            return -1;
        }
        if (inside.charAt(0) == '#') {
            String digits = inside.substring(1);
            if (digits.isEmpty()) {
                return -1;
            }
            boolean hex = digits.charAt(0) == 'x' || digits.charAt(0) == 'X';
            String body = hex ? digits.substring(1) : digits;
            if (body.isEmpty()) {
                return -1;
            }
            for (int k = 0; k < body.length(); k++) {
                char c = body.charAt(k);
                boolean ok = hex
                        ? Character.digit(c, 16) >= 0
                        : (c >= '0' && c <= '9');
                if (!ok) {
                    return -1;
                }
            }
            return semi - i + 1;
        }
        for (int k = 0; k < inside.length(); k++) {
            char c = inside.charAt(k);
            if (!Character.isLetterOrDigit(c)) {
                return -1;
            }
        }
        return semi - i + 1;
    }

    private static String namedToChar(String name) {
        if (name.equals("amp")) {
            return "&";
        }
        if (name.equals("lt")) {
            return "<";
        }
        if (name.equals("gt")) {
            return ">";
        }
        if (name.equals("quot")) {
            return "\"";
        }
        if (name.equals("apos")) {
            return "'";
        }
        return null;
    }

    /** Разворачивает HTML-сущности обратно в символы. */
    static String decode(String s) {
        if (s == null) {
            return null;
        }
        StringBuilder out = new StringBuilder(s.length());
        int i = 0;
        while (i < s.length()) {
            int len = entityLength(s, i);
            if (len < 0) {
                out.append(s.charAt(i));
                i++;
                continue;
            }
            String inside = s.substring(i + 1, i + len - 1);
            if (inside.charAt(0) == '#') {
                String digits = inside.substring(1);
                boolean hex = digits.charAt(0) == 'x' || digits.charAt(0) == 'X';
                int code = Integer.parseInt(hex ? digits.substring(1) : digits, hex ? 16 : 10);
                out.appendCodePoint(code);
            } else {
                String ch = namedToChar(inside);
                if (ch == null) {
                    // Неизвестная именованная сущность возвращается как есть:
                    // текст сообщения после декодирования должен совпасть с исходным.
                    out.append(s, i, i + len);
                } else {
                    out.append(ch);
                }
            }
            i += len;
        }
        return out.toString();
    }

    /**
     * В тексте не осталось сырых спецсимволов: символы {@code < > " '} не
     * встречаются вовсе, а {@code &} — только как начало корректной сущности.
     */
    static boolean noRawSpecials(String escaped) {
        if (escaped == null) {
            return false;
        }
        int i = 0;
        while (i < escaped.length()) {
            char c = escaped.charAt(i);
            if (c == '&') {
                int len = entityLength(escaped, i);
                if (len < 0) {
                    return false;
                }
                i += len;
                continue;
            }
            if (c == '<' || c == '>' || c == '"' || c == '\'') {
                return false;
            }
            i++;
        }
        return true;
    }

    /** Обе части контракта сразу: тело безопасно и текст не потерян. */
    static String violation(String body, String message) {
        String in = inner(body);
        if (in == null) {
            return "тело письма не обёрнуто в <html>...</html>: body=" + body;
        }
        if (!noRawSpecials(in)) {
            return "в теле остались неэкранированные спецсимволы: body=" + body;
        }
        String decoded = decode(in);
        if (!message.equals(decoded)) {
            return "после декодирования сущностей текст не совпал с исходным: "
                    + "ожидалось " + quote(message) + ", получено " + quote(decoded)
                    + " (body=" + body + ")";
        }
        return null;
    }

    static String quote(String s) {
        return s == null ? "null" : "\"" + s + "\"";
    }
}
