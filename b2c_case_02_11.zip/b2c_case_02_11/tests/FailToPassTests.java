public class FailToPassTests {

    static int failures = 0;

    static class RecordingMailSender implements MailSender {
        String lastTo;
        String lastBody;
        int calls = 0;

        public void send(String to, String body) {
            this.lastTo = to;
            this.lastBody = body;
            this.calls++;
        }
    }

    static void check(String name, boolean cond, String detail) {
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name + " :: " + detail);
            failures++;
        }
    }

    static void testHtmlTagsEscaped() {
        String name = "f2p_html_tags_escaped";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), "<script>alert(1)</script>");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        String body = sender.lastBody;
        if (body == null) {
            check(name, false, "mailSender.send was never called");
            return;
        }
        boolean rawTagAbsent = !body.contains("<script>");
        boolean escapedPresent = body.contains("&lt;script&gt;");
        check(name, rawTagAbsent && escapedPresent,
                "expected escaped tags, got body=" + body);
    }

    static void testAmpersandEscaped() {
        String name = "f2p_ampersand_escaped";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), "Tom & Jerry");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        String body = sender.lastBody;
        if (body == null) {
            check(name, false, "mailSender.send was never called");
            return;
        }
        check(name, body.contains("Tom &amp; Jerry"),
                "expected ampersand escaped, got body=" + body);
    }

    static void testNullMessageRejected() {
        String name = "f2p_null_message_rejected";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), null);
            check(name, false, "no exception thrown, calls=" + sender.calls
                    + " body=" + sender.lastBody);
        } catch (IllegalArgumentException expected) {
            check(name, sender.calls == 0,
                    "IllegalArgumentException thrown but mail was still sent");
        } catch (Throwable other) {
            check(name, false, "expected IllegalArgumentException, got " + other);
        }
    }

    static void testNullUserRejected() {
        String name = "f2p_null_user_rejected";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(null, "hello");
            check(name, false, "no exception thrown, calls=" + sender.calls);
        } catch (IllegalArgumentException expected) {
            check(name, sender.calls == 0,
                    "IllegalArgumentException thrown but mail was still sent");
        } catch (Throwable other) {
            check(name, false, "expected IllegalArgumentException, got " + other);
        }
    }

    public static void main(String[] args) {
        testHtmlTagsEscaped();
        testAmpersandEscaped();
        testNullMessageRejected();
        testNullUserRejected();
        if (failures > 0) {
            System.out.println("FAIL_TO_PASS FAILURES: " + failures);
            System.exit(1);
        }
        System.out.println("FAIL_TO_PASS OK");
    }
}
