import java.util.Random;

/**
 * FAIL_TO_PASS: проверки, которые обязаны падать на исходном коде и проходить
 * на решении, выполняющем видимый контракт из instruction.md.
 *
 * Проверяется ровно то, что написано в контракте, и ничем не больше:
 *   - экранирование всех пяти спецсимволов любым корректным способом
 *     (именованные или числовые ссылки — оба варианта равноправны);
 *   - экранирование как ОБЩИЙ механизм: инвариант держится на случайных
 *     сообщениях, а не на фиксированных строках фикстуры;
 *   - IllegalArgumentException при null в любом из аргументов, включая случай,
 *     когда null оба, и письмо при этом не отправляется.
 *
 * Сохранение публичной сигнатуры public void sendNotification(User, String)
 * проверяется в PassToPassTests: на исходном коде она уже корректна, поэтому
 * это контроль обратной совместимости, а не fail_to_pass.
 */
public class FailToPassTests {

    static int failures = 0;

    static class RecordingMailSender implements MailSender {
        String lastTo;
        String lastBody;
        int calls = 0;

        public void send(String to, String body) {
            this.lastTo = to;
            this.lastBody = body;
            this.calls++;
        }
    }

    static void check(String name, boolean cond, String detail) {
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name + " :: " + detail);
            failures++;
        }
    }

    /** Прогоняет одно сообщение и возвращает описание нарушения либо null. */
    static String runOnce(String message) {
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), message);
        } catch (Throwable t) {
            return "unexpected throwable on message " + EscapeCheck.quote(message) + ": " + t;
        }
        if (sender.calls != 1) {
            return "expected exactly 1 send call, got " + sender.calls
                    + " for message " + EscapeCheck.quote(message);
        }
        return EscapeCheck.violation(sender.lastBody, message);
    }

    /** Разметка в сообщении не должна попадать в тело письма как разметка. */
    static void testHtmlTagsEscaped() {
        String name = "f2p_html_tags_escaped";
        String violation = runOnce("<script>alert(1)</script>");
        check(name, violation == null, violation == null ? "" : violation);
    }

    /** Каждый из пяти спецсимволов контракта экранируется. */
    static void testAllFiveSpecialsEscaped() {
        String name = "f2p_all_five_specials_escaped";
        StringBuilder problems = new StringBuilder();
        for (char c : EscapeCheck.SPECIALS) {
            String message = "before" + c + "after";
            String violation = runOnce(message);
            if (violation != null) {
                problems.append("[").append(c).append("] ").append(violation).append("; ");
            }
        }
        String all = "все пять символов сразу: & < > \" '";
        String violation = runOnce(all);
        if (violation != null) {
            problems.append("[all] ").append(violation);
        }
        check(name, problems.length() == 0, problems.toString());
    }

    /**
     * Экранирование — общий механизм: инвариант держится на случайных
     * сообщениях. Спец-обработка отдельных строк (например, только тега
     * script) этот контроль не проходит.
     */
    static void testEscapingIsGeneral() {
        String name = "f2p_escaping_is_general";
        long seed = System.nanoTime();
        Random rnd = new Random(seed);
        char[] alphabet = {
                'a', 'b', 'z', 'A', 'Q', '0', '7', ' ', '.', '-', '_', '/', ':',
                'п', 'р', 'и', 'в', 'ё', '№',
                '&', '<', '>', '"', '\'',
        };
        String firstViolation = null;
        for (int i = 0; i < 25 && firstViolation == null; i++) {
            int len = 1 + rnd.nextInt(40);
            StringBuilder sb = new StringBuilder(len);
            for (int k = 0; k < len; k++) {
                sb.append(alphabet[rnd.nextInt(alphabet.length)]);
            }
            firstViolation = runOnce(sb.toString());
        }
        check(name, firstViolation == null,
                "seed=" + seed + " :: " + (firstViolation == null ? "" : firstViolation));
    }

    /** null в message: IllegalArgumentException и письмо не отправлено. */
    static void testNullMessageRejected() {
        String name = "f2p_null_message_rejected";
        checkNullRejected(name, new User("user@example.ru"), null);
    }

    /** null в user: IllegalArgumentException и письмо не отправлено. */
    static void testNullUserRejected() {
        String name = "f2p_null_user_rejected";
        checkNullRejected(name, null, "hello");
    }

    /** Оба аргумента null: тоже IllegalArgumentException, письмо не отправлено. */
    static void testBothNullRejected() {
        String name = "f2p_both_null_rejected";
        checkNullRejected(name, null, null);
    }

    static void checkNullRejected(String name, User user, String message) {
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(user, message);
            check(name, false, "no exception thrown, calls=" + sender.calls
                    + " body=" + sender.lastBody);
        } catch (IllegalArgumentException expected) {
            check(name, sender.calls == 0,
                    "IllegalArgumentException thrown but mail was still sent");
        } catch (Throwable other) {
            check(name, false, "expected IllegalArgumentException, got " + other);
        }
    }

    public static void main(String[] args) {
        testHtmlTagsEscaped();
        testAllFiveSpecialsEscaped();
        testEscapingIsGeneral();
        testNullMessageRejected();
        testNullUserRejected();
        testBothNullRejected();
        if (failures > 0) {
            System.out.println("FAIL_TO_PASS FAILURES: " + failures);
            System.exit(1);
        }
        System.out.println("FAIL_TO_PASS OK");
    }
}
