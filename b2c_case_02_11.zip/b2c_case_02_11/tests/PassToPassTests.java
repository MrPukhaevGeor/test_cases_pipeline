import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Random;

/**
 * PASS_TO_PASS: обратная совместимость. Эти проверки проходят и на исходном
 * коде, и на корректном решении — решение не должно ломать доставку обычного
 * текста, HTML-обёртку тела и адрес получателя.
 */
public class PassToPassTests {

    static int failures = 0;

    static class RecordingMailSender implements MailSender {
        String lastTo;
        String lastBody;
        int calls = 0;

        public void send(String to, String body) {
            this.lastTo = to;
            this.lastBody = body;
            this.calls++;
        }
    }

    static void check(String name, boolean cond, String detail) {
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name + " :: " + detail);
            failures++;
        }
    }

    /** Обычное текстовое сообщение доставляется и попадает в тело письма. */
    static void testPlainMessageDelivered() {
        String name = "p2p_plain_message_delivered";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), "Payment received");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        if (sender.calls != 1) {
            check(name, false, "expected exactly 1 send call, got " + sender.calls);
            return;
        }
        check(name, sender.lastBody != null && sender.lastBody.contains("Payment received"),
                "message text missing from body=" + sender.lastBody);
    }

    /** HTML-обёртка тела письма сохраняется. */
    static void testHtmlWrapperPreserved() {
        String name = "p2p_html_wrapper_preserved";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), "Payment received");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        String body = sender.lastBody;
        if (body == null) {
            check(name, false, "mailSender.send was never called");
            return;
        }
        check(name, body.startsWith("<html>") && body.endsWith("</html>"),
                "html wrapper lost, body=" + body);
    }

    /** Адрес получателя берётся из user и не искажается. */
    static void testRecipientAddressPreserved() {
        String name = "p2p_recipient_address_preserved";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("client@bank.example"), "Statement ready");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        check(name, "client@bank.example".equals(sender.lastTo),
                "recipient changed, got=" + sender.lastTo);
    }

    /**
     * Смешанный обычный текст (буквы, цифры, пунктуация, кириллица) доходит
     * без изменений: спецсимволов HTML в нём нет, поэтому экранирование не
     * должно ничего трогать. Входы случайные — проверяется свойство, а не
     * конкретная строка.
     */
    static void testMixedPlainTextUnchanged() {
        String name = "p2p_mixed_plain_text_unchanged";
        long seed = System.nanoTime();
        Random rnd = new Random(seed);
        char[] alphabet = {
                'a', 'b', 'c', 'X', 'Y', 'Z', '0', '5', '9', ' ', '.', ',', '-', '_', ':', '/',
                'п', 'л', 'а', 'т', 'ё', 'ж', '№',
        };
        String problem = null;
        for (int i = 0; i < 15 && problem == null; i++) {
            int len = 1 + rnd.nextInt(30);
            StringBuilder sb = new StringBuilder(len);
            for (int k = 0; k < len; k++) {
                sb.append(alphabet[rnd.nextInt(alphabet.length)]);
            }
            String message = sb.toString();

            RecordingMailSender sender = new RecordingMailSender();
            NotificationService service = new NotificationService(sender);
            try {
                service.sendNotification(new User("user@example.ru"), message);
            } catch (Throwable t) {
                problem = "unexpected throwable on " + EscapeCheck.quote(message) + ": " + t;
                break;
            }
            if (sender.calls != 1) {
                problem = "expected exactly 1 send call, got " + sender.calls;
                break;
            }
            String body = sender.lastBody;
            if (body == null || !body.startsWith("<html>") || !body.endsWith("</html>")) {
                problem = "html wrapper lost, body=" + body;
                break;
            }
            if (!body.contains(message)) {
                problem = "обычный текст изменён: ожидалось вхождение "
                        + EscapeCheck.quote(message) + ", body=" + body;
            }
        }
        check(name, problem == null, "seed=" + seed + " :: " + (problem == null ? "" : problem));
    }

    /**
     * Обратная совместимость сигнатуры: метод остаётся видимым снаружи пакета и
     * ничего не возвращает. Вызов из тестов того же пакета сам по себе этого не
     * гарантирует, поэтому сигнатура проверяется рефлексией.
     */
    static void testSignaturePublicVoid() {
        String name = "p2p_signature_public_void";
        try {
            Method m = NotificationService.class.getMethod(
                    "sendNotification", User.class, String.class);
            boolean isPublic = Modifier.isPublic(m.getModifiers());
            boolean isVoid = m.getReturnType() == void.class;
            boolean notStatic = !Modifier.isStatic(m.getModifiers());
            check(name, isPublic && isVoid && notStatic,
                    "expected public void sendNotification(User, String), got modifiers="
                            + Modifier.toString(m.getModifiers())
                            + " returnType=" + m.getReturnType().getName());
        } catch (NoSuchMethodException e) {
            check(name, false, "публичный метод sendNotification(User, String) не найден: " + e);
        }
    }

    public static void main(String[] args) {
        testPlainMessageDelivered();
        testHtmlWrapperPreserved();
        testRecipientAddressPreserved();
        testMixedPlainTextUnchanged();
        testSignaturePublicVoid();
        if (failures > 0) {
            System.out.println("PASS_TO_PASS FAILURES: " + failures);
            System.exit(1);
        }
        System.out.println("PASS_TO_PASS OK");
    }
}
