public class PassToPassTests {

    static int failures = 0;

    static class RecordingMailSender implements MailSender {
        String lastTo;
        String lastBody;
        int calls = 0;

        public void send(String to, String body) {
            this.lastTo = to;
            this.lastBody = body;
            this.calls++;
        }
    }

    static void check(String name, boolean cond, String detail) {
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name + " :: " + detail);
            failures++;
        }
    }

    /** Обычное текстовое сообщение доставляется и попадает в тело письма. */
    static void testPlainMessageDelivered() {
        String name = "p2p_plain_message_delivered";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), "Payment received");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        if (sender.calls != 1) {
            check(name, false, "expected exactly 1 send call, got " + sender.calls);
            return;
        }
        check(name, sender.lastBody != null && sender.lastBody.contains("Payment received"),
                "message text missing from body=" + sender.lastBody);
    }

    /** HTML-обёртка тела письма сохраняется. */
    static void testHtmlWrapperPreserved() {
        String name = "p2p_html_wrapper_preserved";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("user@example.ru"), "Payment received");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        String body = sender.lastBody;
        if (body == null) {
            check(name, false, "mailSender.send was never called");
            return;
        }
        check(name, body.startsWith("<html>") && body.endsWith("</html>"),
                "html wrapper lost, body=" + body);
    }

    /** Адрес получателя берётся из user и не искажается. */
    static void testRecipientAddressPreserved() {
        String name = "p2p_recipient_address_preserved";
        RecordingMailSender sender = new RecordingMailSender();
        NotificationService service = new NotificationService(sender);
        try {
            service.sendNotification(new User("client@bank.example"), "Statement ready");
        } catch (Throwable t) {
            check(name, false, "unexpected throwable: " + t);
            return;
        }
        check(name, "client@bank.example".equals(sender.lastTo),
                "recipient changed, got=" + sender.lastTo);
    }

    public static void main(String[] args) {
        testPlainMessageDelivered();
        testHtmlWrapperPreserved();
        testRecipientAddressPreserved();
        if (failures > 0) {
            System.out.println("PASS_TO_PASS FAILURES: " + failures);
            System.exit(1);
        }
        System.out.println("PASS_TO_PASS OK");
    }
}
