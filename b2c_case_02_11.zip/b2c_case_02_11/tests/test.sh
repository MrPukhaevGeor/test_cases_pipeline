#!/bin/sh
set -e
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

LOG=/logs/verifier/test.log
: > "$LOG"

WORK=/tmp/verify
rm -rf "$WORK"
mkdir -p "$WORK/classes"

# Verifier сам копирует тестовые файлы рядом с исходниками непосредственно
# перед прогоном: во время работы агента /tests не примонтирован.
cp /app/src/*.java "$WORK"/
cp /tests/FailToPassTests.java "$WORK"/
cp /tests/PassToPassTests.java "$WORK"/

if python3 /tests/anti_cheat.py >> "$LOG" 2>&1 \
   && javac -d "$WORK/classes" "$WORK"/*.java >> "$LOG" 2>&1 \
   && java -cp "$WORK/classes" PassToPassTests >> "$LOG" 2>&1 \
   && java -cp "$WORK/classes" FailToPassTests >> "$LOG" 2>&1; then
    echo 1 > /logs/verifier/reward.txt
fi

exit 0
