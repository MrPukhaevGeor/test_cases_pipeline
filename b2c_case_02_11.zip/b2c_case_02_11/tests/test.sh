#!/bin/sh
# Verifier кейса b2c_case_02_11.
#
# Контракт логов:
#   /logs/verifier/reward.txt   — РОВНО одна строка: 0 или 1;
#   /logs/verifier/test.log     — полный вывод компиляции и всех наборов проверок;
#   /logs/verifier/verifier.log — диагностика verifier (почему именно такой reward).
#
# Итоговый reward записывается ПОСЛЕ прогона проверок, поэтому значение,
# записанное агентом в reward.txt во время работы, перетирается.
set -u

LOG_DIR="${VERIFIER_LOG_DIR:-/logs/verifier}"
mkdir -p "$LOG_DIR"

REWARD_FILE="$LOG_DIR/reward.txt"
LOG="$LOG_DIR/test.log"
DIAG_LOG="$LOG_DIR/verifier.log"

# Полное число объявленных проверок (fail_to_pass + pass_to_pass в task.toml).
EXPECTED_F2P=6
EXPECTED_P2P=5

: > "$LOG"
: > "$DIAG_LOG"
printf '0\n' > "$REWARD_FILE"

log() { printf '%s\n' "$*" >> "$DIAG_LOG"; }

WORK="${VERIFIER_WORK:-/tmp/verify}"
rm -rf "$WORK"
mkdir -p "$WORK"
mkdir -p "$WORK/classes"

if ! command -v javac >/dev/null 2>&1; then
    log "[verifier] FATAL: javac недоступен"
    log "[verifier] outcome=environment_error reward=0"
    exit 0
fi

log "[verifier] runner: $(javac -version 2>&1)"

if [ ! -f /app/src/NotificationService.java ]; then
    log "[verifier] решение отсутствует: /app/src/NotificationService.java не найден"
    log "[verifier] outcome=solution_missing reward=0"
    exit 0
fi

# Verifier сам копирует тестовые файлы рядом с исходниками непосредственно
# перед прогоном: во время работы агента /tests не примонтирован.
cp /app/src/*.java "$WORK"/
cp /tests/EscapeCheck.java "$WORK"/
cp /tests/FailToPassTests.java "$WORK"/
cp /tests/PassToPassTests.java "$WORK"/
cp /tests/AntiCheat.java "$WORK"/

# Всё исполняется одним рантаймом (JDK базового образа): второго интерпретатора
# на пути начисления балла нет, во время проверки ничего не скачивается.
#
# Шаги не обрываются на первом падении, а выполняются все: в логе видно
# состояние каждого набора отдельно (в частности, pass_to_pass на исходном
# коде проходит, а падает только fail_to_pass).
STATUS=0

if javac -d "$WORK/classes" "$WORK"/*.java >> "$LOG" 2>&1; then
    log "[verifier] javac exit code: 0"

    java -cp "$WORK/classes" PassToPassTests >> "$LOG" 2>&1
    P2P_CODE=$?
    java -cp "$WORK/classes" FailToPassTests >> "$LOG" 2>&1
    F2P_CODE=$?
    java -cp "$WORK/classes" AntiCheat >> "$LOG" 2>&1
    AC_CODE=$?

    P2P_PASSED="$(grep -c '^PASS p2p_' "$LOG")"
    F2P_PASSED="$(grep -c '^PASS f2p_' "$LOG")"

    log "[verifier] pass_to_pass: exit=$P2P_CODE passed=$P2P_PASSED (ожидается $EXPECTED_P2P)"
    log "[verifier] fail_to_pass: exit=$F2P_CODE passed=$F2P_PASSED (ожидается $EXPECTED_F2P)"
    log "[verifier] anti_cheat:   exit=$AC_CODE"

    if [ "$P2P_CODE" -ne 0 ]; then
        STATUS=1
        log "[verifier] outcome=pass_to_pass_failed reward=0 (сломана обратная совместимость)"
    elif [ "$F2P_CODE" -ne 0 ]; then
        STATUS=1
        log "[verifier] outcome=fail_to_pass_failed reward=0 (контракт задания не выполнен)"
    elif [ "$AC_CODE" -ne 0 ]; then
        STATUS=1
        log "[verifier] outcome=anti_cheat_failed reward=0 (подгонка под проверки)"
    elif [ "$P2P_PASSED" -ne "$EXPECTED_P2P" ] || [ "$F2P_PASSED" -ne "$EXPECTED_F2P" ]; then
        STATUS=1
        log "[verifier] outcome=unexpected_test_count reward=0 (выполнены не все объявленные проверки)"
    else
        log "[verifier] outcome=all_checks_passed reward=1"
    fi
else
    echo "COMPILATION FAILED" >> "$LOG"
    STATUS=1
    log "[verifier] javac exit code: ненулевой"
    log "[verifier] outcome=compilation_failed reward=0"
fi

# Итоговая запись — ПОСЛЕ прогона проверок.
if [ "$STATUS" -eq 0 ]; then
    printf '1\n' > "$REWARD_FILE"
    log "[verifier] final reward=1"
else
    printf '0\n' > "$REWARD_FILE"
    log "[verifier] final reward=0"
fi

exit 0
