import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;

public class SafeDeserializer {

    public Object deserialize(byte[] data) throws Exception {
        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data));
        return in.readObject();
    }
}
