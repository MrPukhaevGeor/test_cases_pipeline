package com.acme.trusted;

import java.io.Serializable;

/** Доверенный объект расчётов. Только примитивные поля. */
public class TrustedPayload implements Serializable {

    private static final long serialVersionUID = 1L;

    private final int amount;
    private final long timestamp;

    public TrustedPayload(int amount, long timestamp) {
        this.amount = amount;
        this.timestamp = timestamp;
    }

    public int getAmount() {
        return amount;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
