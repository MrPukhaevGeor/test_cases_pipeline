package com.acme.untrusted;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

/**
 * Недоверенный объект. Побочный эффект в readObject срабатывает в момент
 * десериализации — до того, как вызывающий код увидит результат.
 */
public class EvilPayload implements Serializable {

    private static final long serialVersionUID = 1L;

    public static volatile boolean detonated = false;

    private final int marker;

    public EvilPayload(int marker) {
        this.marker = marker;
    }

    public int getMarker() {
        return marker;
    }

    private void readObject(ObjectInputStream in)
            throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        detonated = true;
    }
}
