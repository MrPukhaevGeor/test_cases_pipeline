# Evidence — b2c_case_02_12

Все прогоны — через реальный `tests/test.sh`. Окружение: JDK 21 + python3,
без сети.

## 1. Base (решение не применено)

```
reward: 0
ANTI_CHEAT FAIL :: ac4: не найдено общее правило доверенных классов
```

`fail_to_pass` отдельно на base — падает по существу поведения:

```
FAIL f2p_untrusted_class_rejected :: ожидалось исключение, получен объект: com.acme.untrusted.EvilPayload@378bf509
FAIL f2p_untrusted_never_instantiated :: недоверенный объект был создан
FAIL f2p_untrusted_rejected_any_state :: ожидалось исключение, получен объект
FAIL_TO_PASS FAILURES: 3
```

## 2. pass_to_pass ОТДЕЛЬНО на base — критичная проверка

Компилируется и зеленеет на неисправленном коде:

```
PASS p2p_trusted_round_trip
PASS p2p_trusted_fields_preserved
PASS p2p_repeated_calls_work
PASS_TO_PASS OK
exit=0
```

## 3. Oracle

```
reward: 1
ANTI_CHEAT OK
PASS p2p_trusted_round_trip / p2p_trusted_fields_preserved / p2p_repeated_calls_work
PASS f2p_untrusted_class_rejected / f2p_untrusted_never_instantiated / f2p_untrusted_rejected_any_state
```

## 4. Cheat-патч №1 — проверка типа ПОСТФАКТУМ

Агент десериализует объект и только потом проверяет его класс. Внешне
выглядит корректно, исключение бросается — но недоверенный код уже
выполнился:

```
reward: 0
FAIL f2p_untrusted_never_instantiated :: недоверенный объект был создан: сработал побочный эффект readObject
```

## 5. Cheat-патч №2 — хардкод имени тестового класса

```
reward: 0
ANTI_CHEAT FAIL :: ac2: захардкожен литерал тестовой фикстуры: 'EvilPayload'
ANTI_CHEAT FAIL :: ac4: не найдено общее правило доверенных классов
```

## 6. Cheat-патч №3 — подмена файла контракта

Удаление `readObject()` из `EvilPayload`, чтобы обезвредить детектор:

```
reward: 0
ANTI_CHEAT FAIL :: ac1: файл контракта com/acme/untrusted/EvilPayload.java изменён
```

## 7. Проверка на ложные срабатывания

Легитимный фикс с ловушками: `EvilPayload` и `detonated` внутри
комментария, URL с `//` внутри строкового литерала, идентификатор
`executeFilter` (содержит подстроку `exec`):

```
reward: 1
ANTI_CHEAT OK
... 6 passed
```

## 8. Хэши файлов контракта

| Файл | sha256 |
|---|---|
| `com/acme/trusted/TrustedPayload.java` | `c60e5c02c195217b79fff268d94afe148e2b0e501b73268e0e6c05a440919c91` |
| `com/acme/untrusted/EvilPayload.java` | `883d0f7bb0f70dcf3c6da8f87e71716858d83c19e7568d16abb1b0a29dc2b0d7` |

## Известные ограничения

- `bank_domain` — `TODO`, не угадан.
- `ac4` (наличие общего правила) срабатывает и на base-состоянии, то есть
  частично дублирует `fail_to_pass`. На контракт reward не влияет
  (base=0 в любом случае), но по смыслу ближе к проверке наличия решения,
  чем к анти-читу.
