#!/bin/sh
set -e

cat > /app/src/SafeDeserializer.java << 'JAVA_EOF'
import java.io.ByteArrayInputStream;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;

public class SafeDeserializer {

    private static final String TRUSTED_PACKAGE_PREFIX = "com.acme.trusted.";

    public Object deserialize(byte[] data) throws Exception {
        try (ObjectInputStream in =
                     new ObjectInputStream(new ByteArrayInputStream(data))) {
            in.setObjectInputFilter(SafeDeserializer::filter);
            return in.readObject();
        }
    }

    private static ObjectInputFilter.Status filter(ObjectInputFilter.FilterInfo info) {
        Class<?> clazz = info.serialClass();
        if (clazz == null) {
            return ObjectInputFilter.Status.UNDECIDED;
        }
        while (clazz.isArray()) {
            clazz = clazz.getComponentType();
        }
        if (clazz.isPrimitive()) {
            return ObjectInputFilter.Status.ALLOWED;
        }
        if (clazz.getName().startsWith(TRUSTED_PACKAGE_PREFIX)) {
            return ObjectInputFilter.Status.ALLOWED;
        }
        return ObjectInputFilter.Status.REJECTED;
    }
}
JAVA_EOF

echo "solution applied"
