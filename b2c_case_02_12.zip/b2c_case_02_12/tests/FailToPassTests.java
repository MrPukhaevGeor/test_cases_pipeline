import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;

import com.acme.trusted.TrustedPayload;
import com.acme.untrusted.EvilPayload;

public class FailToPassTests {

    static int failures = 0;

    static void check(String name, boolean cond, String detail) {
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name + " :: " + detail);
            failures++;
        }
    }

    static byte[] serialize(Object o) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(o);
        oos.close();
        return bos.toByteArray();
    }

    /** Недоверенный класс должен быть отклонён. */
    static void testUntrustedRejected() throws Exception {
        String name = "f2p_untrusted_class_rejected";
        byte[] data = serialize(new EvilPayload(7));
        SafeDeserializer d = new SafeDeserializer();
        try {
            Object result = d.deserialize(data);
            check(name, false, "ожидалось исключение, получен объект: " + result);
        } catch (Exception expected) {
            check(name, true, "");
        }
    }

    /**
     * Ключевая проверка: отклонение обязано происходить ДО создания объекта.
     * Побочный эффект в readObject недоверенного класса не должен сработать —
     * проверка постфактум (instanceof после десериализации) этот тест не проходит.
     */
    static void testUntrustedNeverInstantiated() throws Exception {
        String name = "f2p_untrusted_never_instantiated";
        byte[] data = serialize(new EvilPayload(7));
        EvilPayload.detonated = false;
        SafeDeserializer d = new SafeDeserializer();
        try {
            d.deserialize(data);
        } catch (Exception ignored) {
            // отклонение ожидаемо
        }
        check(name, !EvilPayload.detonated,
                "недоверенный объект был создан: сработал побочный эффект readObject");
    }

    /** Отклонение недоверенного класса не зависит от значения полей. */
    static void testUntrustedRejectedRegardlessOfState() throws Exception {
        String name = "f2p_untrusted_rejected_any_state";
        byte[] data = serialize(new EvilPayload(-12345));
        SafeDeserializer d = new SafeDeserializer();
        try {
            Object result = d.deserialize(data);
            check(name, false, "ожидалось исключение, получен объект: " + result);
            return;
        } catch (Exception expected) {
            // ok
        }
        byte[] trusted = serialize(new TrustedPayload(1, 1L));
        try {
            Object ok = d.deserialize(trusted);
            check(name, ok instanceof TrustedPayload,
                    "доверенный класс перестал десериализоваться: " + ok);
        } catch (Exception e) {
            check(name, false, "доверенный класс отклонён: " + e);
        }
    }

    public static void main(String[] args) throws Exception {
        testUntrustedRejected();
        testUntrustedNeverInstantiated();
        testUntrustedRejectedRegardlessOfState();
        if (failures > 0) {
            System.out.println("FAIL_TO_PASS FAILURES: " + failures);
            System.exit(1);
        }
        System.out.println("FAIL_TO_PASS OK");
    }
}
