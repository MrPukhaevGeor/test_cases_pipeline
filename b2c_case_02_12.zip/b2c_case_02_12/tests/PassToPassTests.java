import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;

import com.acme.trusted.TrustedPayload;

public class PassToPassTests {

    static int failures = 0;

    static void check(String name, boolean cond, String detail) {
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name + " :: " + detail);
            failures++;
        }
    }

    static byte[] serialize(Object o) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(o);
        oos.close();
        return bos.toByteArray();
    }

    /** Доверенный объект по-прежнему десериализуется и возвращает нужный тип. */
    static void testTrustedRoundTrip() throws Exception {
        String name = "p2p_trusted_round_trip";
        byte[] data = serialize(new TrustedPayload(4200, 1717171717L));
        SafeDeserializer d = new SafeDeserializer();
        try {
            Object result = d.deserialize(data);
            check(name, result instanceof TrustedPayload,
                    "ожидался TrustedPayload, получено: " + result);
        } catch (Exception e) {
            check(name, false, "неожиданное исключение: " + e);
        }
    }

    /** Значения полей доверенного объекта сохраняются без искажений. */
    static void testTrustedFieldsPreserved() throws Exception {
        String name = "p2p_trusted_fields_preserved";
        byte[] data = serialize(new TrustedPayload(4200, 1717171717L));
        SafeDeserializer d = new SafeDeserializer();
        try {
            TrustedPayload result = (TrustedPayload) d.deserialize(data);
            check(name, result.getAmount() == 4200 && result.getTimestamp() == 1717171717L,
                    "поля искажены: amount=" + result.getAmount()
                            + " timestamp=" + result.getTimestamp());
        } catch (Exception e) {
            check(name, false, "неожиданное исключение: " + e);
        }
    }

    /** Метод отрабатывает повторно на одном экземпляре сервиса. */
    static void testRepeatedCallsWork() throws Exception {
        String name = "p2p_repeated_calls_work";
        SafeDeserializer d = new SafeDeserializer();
        try {
            for (int i = 1; i <= 3; i++) {
                byte[] data = serialize(new TrustedPayload(i, i * 10L));
                TrustedPayload result = (TrustedPayload) d.deserialize(data);
                if (result.getAmount() != i) {
                    check(name, false, "итерация " + i + ": amount=" + result.getAmount());
                    return;
                }
            }
            check(name, true, "");
        } catch (Exception e) {
            check(name, false, "неожиданное исключение: " + e);
        }
    }

    public static void main(String[] args) throws Exception {
        testTrustedRoundTrip();
        testTrustedFieldsPreserved();
        testRepeatedCallsWork();
        if (failures > 0) {
            System.out.println("PASS_TO_PASS FAILURES: " + failures);
            System.exit(1);
        }
        System.out.println("PASS_TO_PASS OK");
    }
}
