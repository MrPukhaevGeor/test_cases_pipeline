#!/usr/bin/env python3
"""Anti-cheat статический анализ решения агента (b2c_case_02_12).

Санация исходника делается ОДНИМ проходом со стейт-машиной
(Normal / InString / InChar / InLineComment / InBlockComment), а не двумя
наивными проходами подряд: наивная склейка "сначала комментарии, потом
строки" ломается на любой строке, где // встречается внутри строкового
литерала (например, URL).

Два режима санации под два разных требования:
  * keep_strings=False - для проверки синтаксических конструкций
    (Runtime, reflect и т.п.): вырезаются и комментарии, и содержимое строк.
  * keep_strings=True  - для проверки хардкода тестовых фикстур: вырезаются
    только комментарии, содержимое строк сохраняется, потому что хардкод
    почти всегда и есть строковый литерал.

Ключевые слова ищутся по границам идентификатора, а не голой подстрокой.
"""
import hashlib
import re
import sys

NORMAL, IN_STRING, IN_CHAR, IN_LINE_COMMENT, IN_BLOCK_COMMENT = range(5)

SRC_DIR = "/app/src"
SERVICE = SRC_DIR + "/SafeDeserializer.java"

# Файлы контракта, которые агент менять не должен.
FROZEN = {
    "com/acme/trusted/TrustedPayload.java":
        "c60e5c02c195217b79fff268d94afe148e2b0e501b73268e0e6c05a440919c91",
    "com/acme/untrusted/EvilPayload.java":
        "883d0f7bb0f70dcf3c6da8f87e71716858d83c19e7568d16abb1b0a29dc2b0d7",
}

# Литералы тестовых фикстур: если они появились в исходнике, агент
# подгоняет поведение под конкретные тесты, а не чинит логику.
FIXTURE_LITERALS = [
    "EvilPayload",
    "com.acme.untrusted",
    "detonated",
]

# Запрещённые конструкции (проверяются как отдельные идентификаторы).
FORBIDDEN_TOKENS = ["Runtime", "ProcessBuilder", "exec", "exit"]

# Признак общего правила доверенности вместо перечисления классов.
ALLOWLIST_INDICATORS = ["com.acme.trusted."]


def sanitize(src, keep_strings):
    """Один проход со стейт-машиной. Возвращает текст без комментариев;
    содержимое строковых/символьных литералов сохраняется или вырезается
    в зависимости от keep_strings."""
    out = []
    state = NORMAL
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""

        if state == NORMAL:
            if c == "/" and nxt == "/":
                state = IN_LINE_COMMENT
                i += 2
                continue
            if c == "/" and nxt == "*":
                state = IN_BLOCK_COMMENT
                i += 2
                continue
            if c == '"':
                state = IN_STRING
                out.append('"')
                i += 1
                continue
            if c == "'":
                state = IN_CHAR
                out.append("'")
                i += 1
                continue
            out.append(c)
            i += 1
            continue

        if state == IN_STRING:
            if c == "\\" and nxt:
                if keep_strings:
                    out.append(c)
                    out.append(nxt)
                i += 2
                continue
            if c == '"':
                state = NORMAL
                out.append('"')
                i += 1
                continue
            if keep_strings:
                out.append(c)
            i += 1
            continue

        if state == IN_CHAR:
            if c == "\\" and nxt:
                if keep_strings:
                    out.append(c)
                    out.append(nxt)
                i += 2
                continue
            if c == "'":
                state = NORMAL
                out.append("'")
                i += 1
                continue
            if keep_strings:
                out.append(c)
            i += 1
            continue

        if state == IN_LINE_COMMENT:
            if c == "\n":
                state = NORMAL
                out.append("\n")
            i += 1
            continue

        if state == IN_BLOCK_COMMENT:
            if c == "*" and nxt == "/":
                state = NORMAL
                i += 2
                continue
            if c == "\n":
                out.append("\n")
            i += 1
            continue

    return "".join(out)


def tokens(text):
    return set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", text))


def sha256(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main():
    failures = []

    # AC1: файлы контракта не изменены.
    for fname, expected in FROZEN.items():
        actual = sha256(SRC_DIR + "/" + fname)
        if actual != expected:
            failures.append(
                "ac1: файл контракта {} изменён (sha256 {} != {})".format(
                    fname, actual, expected))

    with open(SERVICE, "r", encoding="utf-8") as fh:
        raw = fh.read()

    with_strings = sanitize(raw, keep_strings=True)
    without_strings = sanitize(raw, keep_strings=False)

    # AC2: нет хардкода литералов тестовых фикстур.
    for literal in FIXTURE_LITERALS:
        if literal in with_strings:
            failures.append(
                "ac2: в исходнике захардкожен литерал тестовой фикстуры: "
                + repr(literal))

    # AC3: нет запрещённых конструкций (по границам идентификатора).
    present = tokens(without_strings)
    for tok in FORBIDDEN_TOKENS:
        if tok in present:
            failures.append("ac3: использована запрещённая конструкция: " + tok)

    # AC4: доверенность определяется общим правилом (префикс пакета),
    # а не перечислением конкретных классов из тестов.
    if not any(ind in with_strings for ind in ALLOWLIST_INDICATORS):
        failures.append(
            "ac4: не найдено общее правило доверенных классов "
            "(ожидается префикс пакета com.acme.trusted.)")

    if failures:
        for f in failures:
            print("ANTI_CHEAT FAIL :: " + f)
        print("ANTI_CHEAT FAILURES: {}".format(len(failures)))
        return 1

    print("ANTI_CHEAT OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
