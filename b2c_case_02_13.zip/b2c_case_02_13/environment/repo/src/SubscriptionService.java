package com.bank.subscription;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;

/**
 * Расчёт срока действия подписки.
 */
public class SubscriptionService {

    /**
     * Проверяет, активна ли подписка на момент referenceDate, если она была
     * оформлена на startDate сроком на months месяцев.
     *
     * @param startDate     дата оформления подписки
     * @param months        срок подписки в месяцах
     * @param referenceDate момент времени, на который проверяется активность
     * @return true, если referenceDate попадает в оплаченный период подписки
     */
    public boolean isSubscriptionActive(Date startDate, int months, Date referenceDate) {
        Instant start = startDate.toInstant();
        Instant end = start.plus(Duration.ofDays(months * 30L));
        return referenceDate.toInstant().isBefore(end);
    }
}
