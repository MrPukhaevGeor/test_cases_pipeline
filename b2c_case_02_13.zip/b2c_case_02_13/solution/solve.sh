#!/bin/sh
set -eu

TARGET="/app/src/SubscriptionService.java"

cat > "$TARGET" <<'JAVA_EOF'
package com.bank.subscription;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Date;

/**
 * Расчёт срока действия подписки.
 */
public class SubscriptionService {

    /**
     * Проверяет, активна ли подписка на момент referenceDate, если она была
     * оформлена на startDate сроком на months месяцев.
     *
     * @param startDate     дата оформления подписки
     * @param months        срок подписки в месяцах
     * @param referenceDate момент времени, на который проверяется активность
     * @return true, если referenceDate попадает в оплаченный период подписки
     */
    public boolean isSubscriptionActive(Date startDate, int months, Date referenceDate) {
        LocalDate start = startDate.toInstant().atZone(ZoneOffset.UTC).toLocalDate();
        LocalDate end = start.plusMonths(months);
        LocalDate reference = referenceDate.toInstant().atZone(ZoneOffset.UTC).toLocalDate();
        return reference.isBefore(end);
    }
}
JAVA_EOF

echo "solve.sh: SubscriptionService.java patched"
