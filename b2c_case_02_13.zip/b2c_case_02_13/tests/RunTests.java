import com.bank.subscription.SubscriptionService;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Verifier-тесты для b2c_case_02_13.
 *
 * Каждый тест сам детектирует сбой: явный try/catch с FAIL при любом
 * исключении, никаких "тихо зеленеющих" веток.
 */
public class RunTests {

    private static int total = 0;
    private static int passed = 0;

    private static final SimpleDateFormat FMT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    static {
        FMT.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    private static Date d(String s) {
        try {
            return FMT.parse(s);
        } catch (Exception e) {
            throw new RuntimeException("bad fixture date: " + s, e);
        }
    }

    private static void check(String name, boolean expected, Date start, int months, Date ref) {
        total++;
        try {
            SubscriptionService svc = new SubscriptionService();
            boolean actual = svc.isSubscriptionActive(start, months, ref);
            if (actual == expected) {
                System.out.println("TEST " + name + ": PASS");
                passed++;
            } else {
                System.out.println("TEST " + name + ": FAIL (expected=" + expected + " actual=" + actual + ")");
            }
        } catch (Throwable t) {
            System.out.println("TEST " + name + ": FAIL (exception: " + t + ")");
        }
    }

    public static void main(String[] args) {

        // --- fail_to_pass: расходится 30-дневное приближение и реальный календарь ---

        // Январь (31 день): approx-конец = 31 января 00:00, реальный конец = 1 февраля.
        // referenceDate = 31 января, полдень — реально ещё активна, approx уже "закончилась".
        check("fail_to_pass_january_boundary",
                true,
                d("2024-01-01T00:00:00"), 1,
                d("2024-01-31T12:00:00"));

        // Март (31 день), аналогичный недосчёт на границе месяца.
        check("fail_to_pass_march_boundary",
                true,
                d("2024-03-01T00:00:00"), 1,
                d("2024-03-31T12:00:00"));

        // Февраль високосного 2024 года (29 дней): approx даёт конец на день позже
        // реального календарного конца — подписка не должна считаться активной.
        check("fail_to_pass_leap_february_overshoot",
                false,
                d("2024-02-01T00:00:00"), 1,
                d("2024-03-01T12:00:00"));

        // --- pass_to_pass: однозначные случаи, не зависящие от способа расчёта ---

        // Середина периода — очевидно активна при любой разумной реализации.
        check("pass_to_pass_clear_active",
                true,
                d("2024-04-01T00:00:00"), 1,
                d("2024-04-15T00:00:00"));

        // Много месяцев после окончания — очевидно неактивна при любой реализации.
        check("pass_to_pass_clear_expired",
                false,
                d("2024-01-01T00:00:00"), 1,
                d("2024-06-01T00:00:00"));

        System.out.println("SUMMARY " + passed + "/" + total);
        if (passed != total) {
            System.exit(1);
        }
    }
}
