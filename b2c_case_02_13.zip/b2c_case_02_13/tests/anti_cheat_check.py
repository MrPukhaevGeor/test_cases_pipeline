#!/usr/bin/env python3
"""
Anti-cheat проверки для b2c_case_02_13.

Одна санация исходника state-machine'ой (Normal/InString/InLineComment/
InBlockComment) за один проход — наивная последовательная склейка
"сначала комментарии, потом строки" ломается на строках вида
"// see java.time.Duration docs at http://..." (частично живёт внутри
комментария, но содержит //-подобные куски и кавычки в реальных кейсах).

Здесь два разных вида санации не путаются:
  - синтаксическая проверка (тривиальный хардкод возврата) — вырезаем
    и комментарии, и содержимое строк;
  - в этом кейсе проверок на хардкод строковых фикстур нет (входные
    данные — Date, не строковые литералы), поэтому используется только
    первый вид.
"""
import re
import sys


def strip_comments_and_strings(src: str) -> str:
    out = []
    i = 0
    n = len(src)
    state = "normal"
    while i < n:
        c = src[i]
        nxt = src[i + 1] if i + 1 < n else ""
        if state == "normal":
            if c == "/" and nxt == "/":
                state = "line_comment"
                i += 2
                continue
            if c == "/" and nxt == "*":
                state = "block_comment"
                i += 2
                continue
            if c == '"':
                state = "string"
                out.append('"')  # keep delimiter so regexes on structure still see a token
                i += 1
                continue
            if c == "'":
                state = "char"
                out.append("'")
                i += 1
                continue
            out.append(c)
            i += 1
        elif state == "line_comment":
            if c == "\n":
                state = "normal"
                out.append("\n")
            i += 1
        elif state == "block_comment":
            if c == "*" and nxt == "/":
                state = "normal"
                i += 2
                continue
            i += 1
        elif state == "string":
            if c == "\\":
                i += 2
                continue
            if c == '"':
                state = "normal"
                out.append('"')
                i += 1
                continue
            i += 1
        elif state == "char":
            if c == "\\":
                i += 2
                continue
            if c == "'":
                state = "normal"
                out.append("'")
                i += 1
                continue
            i += 1
    return "".join(out)


def extract_method_body(sanitized_src: str, method_name: str) -> str:
    m = re.search(r"\b" + re.escape(method_name) + r"\s*\([^)]*\)\s*\{", sanitized_src)
    if not m:
        return ""
    start = m.end() - 1  # position of the opening '{'
    depth = 0
    for idx in range(start, len(sanitized_src)):
        ch = sanitized_src[idx]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return sanitized_src[start + 1:idx]
    return sanitized_src[start + 1:]


def token_present(sanitized_src: str, token: str) -> bool:
    return re.search(r"(?<![A-Za-z0-9_])" + re.escape(token) + r"(?![A-Za-z0-9_])", sanitized_src) is not None


def main():
    if len(sys.argv) != 2:
        print("usage: anti_cheat_check.py <path-to-SubscriptionService.java>")
        sys.exit(2)

    path = sys.argv[1]
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    sanitized = strip_comments_and_strings(raw)
    violations = []

    # 1. Публичный контракт метода не изменён (сигнатура + пакет).
    if not token_present(sanitized, "com.bank.subscription"):
        violations.append("package com.bank.subscription не найден")
    sig_ok = re.search(
        r"public\s+boolean\s+isSubscriptionActive\s*\(\s*Date\s+\w+\s*,\s*int\s+\w+\s*,\s*Date\s+\w+\s*\)",
        sanitized,
    )
    if not sig_ok:
        violations.append("сигнатура isSubscriptionActive(Date, int, Date): boolean изменена или не найдена")

    # 2. Метод не превращён в тривиальный хардкод (return true;/false; как всё тело).
    body = extract_method_body(sanitized, "isSubscriptionActive")
    body_collapsed = re.sub(r"\s+", "", body)
    if body_collapsed in ("returntrue;", "returnfalse;"):
        violations.append("тело isSubscriptionActive — тривиальный хардкод возврата без вычислений")

    # 3. Только стандартная библиotека Java — никаких внешних зависимостей/сети.
    for imp_match in re.finditer(r"^\s*import\s+([\w.]+)\s*;", sanitized, flags=re.MULTILINE):
        imp = imp_match.group(1)
        if not (imp.startswith("java.") or imp.startswith("javax.")):
            violations.append(f"запрещённый импорт вне стандартной библиотеки: {imp}")

    if violations:
        print("ANTI-CHEAT: FAIL")
        for v in violations:
            print(" - " + v)
        sys.exit(1)

    print("ANTI-CHEAT: PASS")
    sys.exit(0)


if __name__ == "__main__":
    main()
