#!/bin/sh
set -u

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

WORK=/tmp/verifier_work
rm -rf "$WORK"
mkdir -p "$WORK/out"

# /tests монтируется отдельно от /app и может быть недоступен агенту во
# время его работы — копируем verifier-тесты в рабочую директорию перед
# прогоном, не полагаясь на то, что /tests смонтирован постоянно.
cp /tests/RunTests.java "$WORK/RunTests.java"
cp /tests/anti_cheat_check.py "$WORK/anti_cheat_check.py"

SRC=/app/src/SubscriptionService.java

if [ ! -f "$SRC" ]; then
    echo "SubscriptionService.java not found at $SRC" > /logs/verifier/pytest.log
    exit 0
fi

# --- anti-cheat: проверяем исходник до компиляции ---
if ! python3 "$WORK/anti_cheat_check.py" "$SRC" > /logs/verifier/anti_cheat.log 2>&1; then
    cat /logs/verifier/anti_cheat.log > /logs/verifier/pytest.log
    exit 0
fi

# --- компиляция и поведенческие тесты ---
if ! javac -d "$WORK/out" "$SRC" "$WORK/RunTests.java" > /logs/verifier/build.log 2>&1; then
    cat /logs/verifier/build.log > /logs/verifier/pytest.log
    exit 0
fi

if java -cp "$WORK/out" RunTests > /logs/verifier/pytest.log 2>&1; then
    echo 1 > /logs/verifier/reward.txt
fi

cat /logs/verifier/pytest.log
