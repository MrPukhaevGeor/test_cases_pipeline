#!/bin/sh
set -e

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

cd /app

if python -m pytest /tests/test_verifier.py -v --tb=short > /logs/verifier/pytest.log 2>&1; then
    echo 1 > /logs/verifier/reward.txt
fi
