"""Verifier для кейса data-mapping: обогащение бизнес-требования техническими путями.

Архитектура reward:
- pass_to_pass — инварианты окружения (входные файлы на месте). Истинны и на base,
  и после решения; не зависят от answer.txt.
- fail_to_pass — детерминированная проверка результата (answer.txt). На base файла нет,
  поэтому эти тесты падают; после solution/solve.sh — проходят.

Детерминированные тесты соответствуют критериям K1 (полнота) и K2 (корректность)
из judge_rubric. LLM-as-Judge применяется УМР поверх этих автотестов (см. task.toml).
"""
import os
import re
import pytest

ANSWER = "/app/answer.txt"
REQUIREMENT = "/app/business_requirement.txt"
DATA_MODEL = "/app/03_data_and_references.json"

# Полный набор валидных путей модели данных, релевантных требованию.
VALID_PATHS = {
    "individual.id",
    "individual.names",
    "individual.birthDate",
    "individual.countryResident",
    "individual.identifications.documentSeries",
    "individual.identifications.documentNumber",
    "individual.identifications.issuedByOrganization",
    "individual.phoneNumbers.phoneNumber",
    "individual.phoneNumbers.usageType.code",
    "individual.addresses",
}

# Обязательные к обогащению пути (K1 — полнота).
REQUIRED_PATHS = [
    "individual.id",
    "individual.names",
    "individual.birthDate",
    "individual.countryResident",
    "individual.identifications.documentSeries",
    "individual.identifications.documentNumber",
    "individual.identifications.issuedByOrganization",
    "individual.phoneNumbers.phoneNumber",
    "individual.addresses",
]

PATH_RE = re.compile(r"individual(?:\.[A-Za-z0-9]+)+")


def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _norm(text):
    # Устраняем чувствительность к ё/е при поиске русских маркеров.
    return text.replace("ё", "е")


def _answer():
    return _read(ANSWER)


def _technical_part(content):
    norm = _norm(content)
    marker = "Обоснование примененных кодов и значений"
    return norm.split(marker)[0] if marker in norm else norm


def _justification_part(content):
    norm = _norm(content)
    marker = "Обоснование примененных кодов и значений"
    parts = norm.split(marker)
    return parts[1] if len(parts) > 1 else ""


# ── pass_to_pass: инварианты окружения ───────────────────────────────────────

def test_business_requirement_input_exists():
    """PASS_TO_PASS: исходное бизнес-требование на месте и не повреждено."""
    assert os.path.exists(REQUIREMENT), "Входной файл business_requirement.txt отсутствует"
    assert "ЕПК ID" in _read(REQUIREMENT), "Входное требование повреждено"


def test_data_model_input_exists():
    """PASS_TO_PASS: модель данных доступна и содержит ключевые объекты."""
    assert os.path.exists(DATA_MODEL), "Входной файл 03_data_and_references.json отсутствует"
    model = _read(DATA_MODEL)
    assert "individual" in model and "usageType" in model, "Модель данных повреждена"


# ── fail_to_pass: результат работы агента ─────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: создан файл с результатом answer.txt."""
    assert os.path.exists(ANSWER), "Файл answer.txt не найден"


def test_answer_has_two_sections():
    """FAIL_TO_PASS: присутствуют обе обязательные части ответа."""
    norm = _norm(_answer())
    assert "Техническое описание доработки" in norm, "Нет раздела технического описания"
    assert "Обоснование примененных кодов и значений" in norm, "Нет раздела обоснования"


def test_all_required_paths_present():
    """FAIL_TO_PASS (K1 — полнота): все обязательные атрибуты обогащены путями."""
    technical = _technical_part(_answer())
    missing = [p for p in REQUIRED_PATHS if p not in technical]
    assert not missing, f"В техническом описании отсутствуют пути: {missing}"


def test_phone_condition_correct():
    """FAIL_TO_PASS (K2 — корректность): для НМТ задано условие usageType.code = 15."""
    technical = _technical_part(_answer())
    assert re.search(r"individual\.phoneNumbers\.usageType\.code\s*=\s*15", technical), \
        "Для НМТ не указано корректное условие usageType.code = 15"


def test_no_hallucinated_paths():
    """FAIL_TO_PASS (K2 — отсутствие галлюцинаций): используются только пути из модели."""
    found = set(PATH_RE.findall(_answer()))
    invalid = sorted(found - VALID_PATHS)
    assert not invalid, f"Использованы несуществующие в модели пути: {invalid}"


def test_justification_has_required_fields():
    """FAIL_TO_PASS: в обосновании присутствуют все обязательные поля."""
    justification = _justification_part(_answer())
    assert justification.strip(), "Раздел обоснования пуст"
    for field in ("Логика", "Релевантные данные", "Цитата", "Умозаключение"):
        assert field in justification, f"В обосновании отсутствует поле '{field}'"


def test_original_terms_preserved():
    """FAIL_TO_PASS (anti-cheat): бизнес-термины не удалены, а обогащены."""
    technical = _technical_part(_answer())
    for term in ("ЕПК ID", "ФИО", "гражданство", "паспорт", "НМТ", "адрес"):
        assert term in technical, f"Бизнес-термин '{term}' удалён — должен сохраняться"
