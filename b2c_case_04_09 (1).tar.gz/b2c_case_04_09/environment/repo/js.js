// Глобальная переменная
let config = { apiUrl: 'https://api.example.com' };

// Уязвимость: XSS при вставке данных в DOM
function displayUser(name) {
    document.getElementById('user-name').innerHTML = name; // Опасно!
}

// Логика: неправильная обработка промисов
async function fetchUserData(userId) {
    const response = await fetch(`${config.apiUrl}/users/${userId}`);
    const data = await response.json();
    return data; // Не проверяется статус ответа
}

// Утечка памяти: не удаляется обработчик события
function attachHandler() {
    window.addEventListener('resize', function() { console.log('Resize'); });
    // Нет соответствующего removeEventListener
}

// Небезопасное использование eval (демонстрационный пример)
function evaluateExpression(expr) {
    return eval(expr); // ОЧЕНЬ ОПАСНО
}

const userId = document.getElementById('user-id-input').value; // Не проверяется
fetchUserData(userId).then(displayUser);
