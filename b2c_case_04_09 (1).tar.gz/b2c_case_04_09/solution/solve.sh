#!/bin/sh
cat > /app/js.js << 'EOF'
// Глобальная переменная
let config = { apiUrl: 'https://api.example.com' };

// Исправлено: используем textContent для безопасной вставки данных в DOM
function displayUser(name) {
    document.getElementById('user-name').textContent = name;
}

// Исправлено: добавлена проверка статуса ответа
async function fetchUserData(userId) {
    const response = await fetch(`${config.apiUrl}/users/${userId}`);
    if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`);
    }
    const data = await response.json();
    return data;
}

// Исправлено: обработчик сохраняется для последующего удаления
const resizeHandler = function() { console.log('Resize'); };
function attachHandler() {
    window.addEventListener('resize', resizeHandler);
}
function detachHandler() {
    window.removeEventListener('resize', resizeHandler);
}

// Исправлено: eval заменён на безопасный парсер выражений
function evaluateExpression(expr) {
    const sanitized = expr.replace(/[^0-9+\-*/().\s]/g, '');
    if (sanitized !== expr) {
        throw new Error('Invalid expression');
    }
    return Function('"use strict"; return (' + sanitized + ')')();
}

// Исправлено: добавлена валидация входных данных
const rawUserId = document.getElementById('user-id-input').value;
const userId = rawUserId && rawUserId.trim() ? rawUserId.trim() : null;
if (userId) {
    fetchUserData(userId).then(displayUser);
}
EOF
