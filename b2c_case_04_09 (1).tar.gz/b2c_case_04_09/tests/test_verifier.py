import pytest

JS_FILE = '/app/js.js'


def read_source():
    with open(JS_FILE, 'r', encoding='utf-8') as f:
        return f.read()


# ── fail_to_pass ────────────────────────────────────────────────────────────

def test_no_innerHTML():
    """XSS: innerHTML не должен использоваться для вставки пользовательских данных."""
    source = read_source()
    assert 'innerHTML' not in source, \
        "Найдено использование innerHTML — замените на textContent"


def test_no_eval():
    """Code injection: eval() не должен использоваться."""
    source = read_source()
    assert 'eval(' not in source, \
        "Найдено использование eval() — замените на безопасную альтернативу"


def test_response_status_check():
    """Error handling: должна быть проверка статуса HTTP-ответа."""
    source = read_source()
    assert 'response.ok' in source or 'response.status' in source, \
        "Отсутствует проверка response.ok / response.status после fetch()"


# ── pass_to_pass ─────────────────────────────────────────────────────────────

def test_functions_still_exist():
    """Регрессия: все оригинальные функции должны остаться в файле."""
    source = read_source()
    for fn in ('displayUser', 'fetchUserData', 'attachHandler', 'evaluateExpression'):
        assert fn in source, f"Функция {fn} была удалена — нельзя удалять существующие функции"


def test_function_signatures_unchanged():
    """Регрессия: сигнатуры функций не должны измениться."""
    source = read_source()
    assert 'function displayUser(name)' in source, \
        "Сигнатура displayUser(name) изменена"
    assert 'fetchUserData(userId)' in source, \
        "Сигнатура fetchUserData(userId) изменена"
    assert 'evaluateExpression(expr)' in source, \
        "Сигнатура evaluateExpression(expr) изменена"


# ── anti-cheat ────────────────────────────────────────────────────────────────

def test_file_not_empty():
    """Anti-cheat: файл не должен быть очищен или содержать только комментарии."""
    source = read_source()
    non_comment_lines = [
        l for l in source.splitlines()
        if l.strip() and not l.strip().startswith('//')
    ]
    assert len(non_comment_lines) >= 10, \
        "Файл подозрительно короткий — агент мог удалить логику"
