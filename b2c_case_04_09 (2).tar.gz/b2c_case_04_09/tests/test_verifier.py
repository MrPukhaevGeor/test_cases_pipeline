import re
import pytest

JS_FILE = '/app/js.js'


def read_source():
    with open(JS_FILE, 'r', encoding='utf-8') as f:
        return f.read()


def strip_comments(source):
    """Убираем комментарии, чтобы проверять код, а не текст в комментариях.

    Блочные /* ... */ и строчные // ... до конца строки.
    Лукбехайнд (?<!:) бережёт схему URL (https://...), где // не комментарий.
    """
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.DOTALL)
    cleaned = []
    for line in source.splitlines():
        cleaned.append(re.sub(r'(?<!:)//.*$', '', line))
    return '\n'.join(cleaned)


# ── fail_to_pass ─────────────────────────────────────────────────────────────

def test_no_innerHTML_assignment():
    """XSS: присваивание через .innerHTML недопустимо (комментарии игнорируем)."""
    code = strip_comments(read_source())
    assert not re.search(r'\.innerHTML\s*=', code), \
        "Найдено присваивание через .innerHTML — замените на .textContent"


def test_no_eval():
    """Code injection: вызов eval() в коде недопустим (комментарии игнорируем)."""
    code = strip_comments(read_source())
    assert 'eval(' not in code, \
        "Найден вызов eval() в коде — замените на безопасную альтернативу"


def test_response_status_check():
    """Error handling: статус HTTP-ответа должен явно проверяться в условии if."""
    code = strip_comments(read_source())
    has_ok = bool(re.search(r'if\s*\(.*response\.ok', code))
    has_status = bool(re.search(r'if\s*\(.*response\.status', code))
    assert has_ok or has_status, \
        "Отсутствует явная проверка response.ok / response.status в условии if"


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_functions_still_exist():
    """Регрессия: все оригинальные функции должны остаться в файле."""
    source = read_source()
    for fn in ('displayUser', 'fetchUserData', 'attachHandler', 'evaluateExpression'):
        assert fn in source, \
            f"Функция {fn} была удалена — нельзя удалять существующие функции"


def test_function_signatures_unchanged():
    """Регрессия: сигнатуры всех функций не должны измениться."""
    source = read_source()
    assert 'function displayUser(name)' in source, \
        "Сигнатура displayUser(name) изменена"
    assert 'fetchUserData(userId)' in source, \
        "Сигнатура fetchUserData(userId) изменена"
    assert 'function attachHandler()' in source, \
        "Сигнатура attachHandler() изменена"
    assert 'evaluateExpression(expr)' in source, \
        "Сигнатура evaluateExpression(expr) изменена"


def test_file_not_empty():
    """Anti-cheat: файл не должен быть очищен или состоять только из комментариев."""
    source = read_source()
    non_comment = [
        l for l in source.splitlines()
        if l.strip() and not l.strip().startswith('//')
    ]
    assert len(non_comment) >= 10, \
        "Файл подозрительно короткий — агент мог удалить основную логику"
