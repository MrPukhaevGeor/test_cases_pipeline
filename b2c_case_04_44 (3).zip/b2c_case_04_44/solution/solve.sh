#!/bin/sh
cat > /app/answer.json << 'JSON'
{
  "file": "go.go",
  "changes": [
    {
      "element": "APIBaseURL",
      "type": "variable",
      "description": "Определена глобальная переменная типа string, хранящая базовый URL внешнего API. Используется в fetchUserData для формирования адреса запроса."
    },
    {
      "element": "fetchUserData",
      "type": "function",
      "description": "Функция принимает userID типа int, формирует URL через fmt.Sprintf, выполняет HTTP GET запрос через http.Get, читает тело ответа через ioutil.ReadAll и возвращает его как string вместе с error."
    },
    {
      "element": "saveToFile",
      "type": "function",
      "description": "Функция принимает data и filename типа string, записывает данные в файл через ioutil.WriteFile с правами 0644. Имя файла передаётся напрямую без валидации."
    },
    {
      "element": "main",
      "type": "function",
      "description": "Точка входа программы: считывает пользовательский ввод через fmt.Scanln, преобразует строку в int через strconv.Atoi, последовательно вызывает fetchUserData и saveToFile с обработкой ошибок через if err != nil."
    },
    {
      "element": "ioutil",
      "type": "import",
      "description": "Импортирован пакет io/ioutil для операций чтения HTTP-ответа (ReadAll) и записи файла (WriteFile). Пакет помечен как устаревший начиная с Go 1.16."
    }
  ],
  "important_findings": [
    {
      "element": "fetchUserData",
      "category": "security",
      "finding": "SSRF (Server-Side Request Forgery)",
      "detail": "Значение APIBaseURL подставляется в URL запроса напрямую без валидации. Если переменная может быть изменена внешним образом, возможна отправка запросов на произвольные внутренние адреса сети."
    },
    {
      "element": "fetchUserData",
      "category": "resource_leak",
      "finding": "Незакрытое тело HTTP-ответа resp.Body",
      "detail": "После вызова http.Get тело ответа resp.Body не закрывается через defer resp.Body.Close(). Это приводит к утечке ресурсов: соединения не возвращаются в пул, что при многократных вызовах исчерпывает дескрипторы."
    },
    {
      "element": "saveToFile",
      "category": "security",
      "finding": "Path Traversal",
      "detail": "Имя файла формируется через fmt.Sprintf из пользовательского ввода userID без санитизации. Передача значения типа '../etc/passwd' позволяет записать файл в произвольное место файловой системы."
    },
    {
      "element": "ioutil",
      "category": "deprecated",
      "finding": "Использование устаревшего пакета ioutil",
      "detail": "Функции ioutil.ReadAll и ioutil.WriteFile помечены deprecated с Go 1.16. Рекомендуется использовать io.ReadAll и os.WriteFile соответственно из актуальных пакетов стандартной библиотеки."
    },
    {
      "element": "main",
      "category": "error_handling",
      "finding": "Отсутствие обработки ошибки fmt.Scanln",
      "detail": "Возвращаемое значение ошибки функции fmt.Scanln игнорируется. При ошибке чтения stdin переменная input остаётся пустой строкой, что приводит к некорректному поведению strconv.Atoi на следующем шаге."
    }
  ]
}
JSON
