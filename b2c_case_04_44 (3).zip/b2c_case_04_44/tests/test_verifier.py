"""
Верификатор кейса b2c_case_04_44.
Агент пишет answer.json со структурированным анализом git diff.
Проверяет схему, элементы, обязательные findings и содержательность.
Keyword dump структурно невозможен — каждый элемент проверяется отдельно.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "e89c2aed6c00b0af76d8a60dde1b92bac27098bd668952d49ba3f0260e879c0a"
PROMPT_SHA256 = "0a28c2157a04c6ac76778f6f67c3e1e10a39296c39e797fa4d1398ee19a7d94e"

# Элементы реально присутствующие в diff — только они допустимы в ответе
# Читаем VALID_ELEMENTS из неизменяемой фикстуры (DRY — единственный источник правды)
def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)

VALID_ELEMENTS = {e.lower() for e in _load_schema()["valid_elements"]}

VALID_CATEGORIES = {"security", "resource_leak", "deprecated", "error_handling"}

# Обязательные findings: (нормализованный element, category, keywords-любое из)
REQUIRED_FINDINGS = [
    ("fetchuserdata", "security",      ["ssrf", "server-side request forgery", "подстановка"]),
    ("fetchuserdata", "resource_leak", ["body", "close", "утечка", "закрыт", "resp"]),
    ("savetofile",    "security",      ["path traversal", "traversal", "обход"]),
    (None,            "deprecated",    ["ioutil", "deprecated", "устарев"]),
]

# Элементы обязательные в секции changes
REQUIRED_IN_CHANGES = {"fetchuserdata", "savetofile", "apibaseurl", "main"}


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _norm(s):
    return (s or "").strip().lower()


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    import hashlib
    SCHEMA_SHA256 = "3130be710e9af678f0515aa3e9029219120c62f5bcbd37eed2c3f805e7152d2d"
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    h = hashlib.sha256(open(FIXTURE, "rb").read()).hexdigest()
    assert h == SCHEMA_SHA256, f"Fixture схема изменена: ожидался {SCHEMA_SHA256}, получен {h}"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_go():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла."""
    data = _load()
    assert "go" in _norm(data.get("file", "")), \
        f"Поле file не содержит имя Go-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: в changes минимум 4 элемента (функции + переменная + импорты)."""
    data = _load()
    assert len(data["changes"]) >= 4, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= 4"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты fetchUserData, saveToFile, APIBaseURL, main."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, \
        f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = []
    for c in data["changes"]:
        el = _norm(c.get("element", ""))
        if el not in VALID_ELEMENTS:
            invalid.append(c.get("element"))
    assert not invalid, \
        f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не является просто копипастом имени элемента)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, \
            f"description для '{el}' слишком короткий: {len(desc)} символов"
        # description не должен состоять только из имени элемента
        assert _norm(desc) != _norm(el), \
            f"description для '{el}' — просто копипаст имени элемента"
        # description должен содержать хотя бы 4 разных слова
        words = re.findall(r'\w+', desc.lower())
        assert len(set(words)) >= 4, \
            f"description для '{el}' содержит слишком мало уникальных слов: {set(words)}"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    valid = {"function", "variable", "import", "statement"}
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in valid, \
            f"Недопустимый type '{c.get('type')}' для элемента '{c.get('element')}'"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: в important_findings минимум 4 finding."""
    data = _load()
    assert len(data["important_findings"]) >= 4, \
        f"important_findings содержит {len(data['important_findings'])} элементов, нужно >= 4"


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = []
    for f in data["important_findings"]:
        el = _norm(f.get("element", ""))
        if el not in VALID_ELEMENTS:
            invalid.append(f.get("element"))
    assert not invalid, \
        f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст finding)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, \
            f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r'\w+', detail.lower())
        assert len(set(words)) >= 5, \
            f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), \
            f"detail для '{el}' — просто копипаст поля finding"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих пар (element, category) в important_findings."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")))
        assert key not in seen, \
            f"Дублирующая пара (element, category): {key}"
        seen.add(key)


# ── fail_to_pass: обязательные findings по контракту ─────────────────────────

def test_finding_ssrf_present():
    """FAIL_TO_PASS: найден finding с категорией security о SSRF в fetchUserData."""
    data = _load()
    findings = data["important_findings"]
    matched = [
        f for f in findings
        if _norm(f.get("element", "")) == "fetchuserdata"
        and _norm(f.get("category", "")) == "security"
        and any(kw in _norm(f.get("detail", "") + " " + f.get("finding", ""))
                for kw in ["ssrf", "server-side request forgery", "подстановка"])
    ]
    assert matched, \
        "Нет finding: fetchUserData / security / SSRF (server-side request forgery)"


def test_finding_resource_leak_present():
    """FAIL_TO_PASS: найден finding о незакрытом resp.Body (resource_leak) в fetchUserData."""
    data = _load()
    findings = data["important_findings"]
    matched = [
        f for f in findings
        if _norm(f.get("element", "")) == "fetchuserdata"
        and _norm(f.get("category", "")) == "resource_leak"
        and any(kw in _norm(f.get("detail", "") + " " + f.get("finding", ""))
                for kw in ["body", "close", "утечка", "закрыт", "resp"])
    ]
    assert matched, \
        "Нет finding: fetchUserData / resource_leak / незакрытый resp.Body"


def test_finding_path_traversal_present():
    """FAIL_TO_PASS: найден finding с категорией security о Path Traversal в saveToFile."""
    data = _load()
    findings = data["important_findings"]
    matched = [
        f for f in findings
        if _norm(f.get("element", "")) == "savetofile"
        and _norm(f.get("category", "")) == "security"
        and any(kw in _norm(f.get("detail", "") + " " + f.get("finding", ""))
                for kw in ["path traversal", "traversal", "обход", "путь"])
    ]
    assert matched, \
        "Нет finding: saveToFile / security / Path Traversal"


def test_finding_deprecated_ioutil_present():
    """FAIL_TO_PASS: найден finding о deprecated ioutil."""
    data = _load()
    findings = data["important_findings"]
    matched = [
        f for f in findings
        if _norm(f.get("category", "")) == "deprecated"
        and any(kw in _norm(f.get("detail", "") + " " + f.get("finding", "") + " " + f.get("element", ""))
                for kw in ["ioutil", "deprecated", "устарев"])
    ]
    assert matched, \
        "Нет finding: deprecated / ioutil (устаревший пакет)"
