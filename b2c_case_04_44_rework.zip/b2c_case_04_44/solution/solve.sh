#!/bin/sh
cat > /app/answer.json << 'JSON'
{
  "file": "go.go",
  "changes": [
    {
      "element": "APIBaseURL",
      "type": "variable",
      "description": "Определена глобальная переменная типа string со значением https://api.example.com, хранящая базовый URL внешнего API. Используется внутри fetchUserData для построения адреса запроса."
    },
    {
      "element": "fetchUserData",
      "type": "function",
      "description": "Функция принимает userID типа int, формирует URL через fmt.Sprintf, выполняет HTTP GET запрос через http.Get, читает тело ответа через ioutil.ReadAll и возвращает его как string вместе с error."
    },
    {
      "element": "saveToFile",
      "type": "function",
      "description": "Функция принимает data и filename типа string, записывает данные в файл через ioutil.WriteFile с правами 0644. Значение filename передаётся в вызов напрямую."
    },
    {
      "element": "main",
      "type": "function",
      "description": "Точка входа программы: считывает пользовательский ввод через fmt.Scanln, преобразует строку в int через strconv.Atoi, последовательно вызывает fetchUserData и saveToFile с проверкой err через if err != nil."
    },
    {
      "element": "ioutil",
      "type": "import",
      "description": "Импортирован пакет io/ioutil, используемый для чтения HTTP-ответа функцией ReadAll и записи файла функцией WriteFile."
    },
    {
      "element": "http.Get",
      "type": "statement",
      "description": "Вызов пакета net/http, выполняющий GET-запрос по строке url; результат присваивается переменным resp и err внутри fetchUserData."
    },
    {
      "element": "fmt.Scanln",
      "type": "statement",
      "description": "Вызов пакета fmt, считывающий строку из стандартного ввода в переменную input внутри функции main."
    }
  ],
  "important_findings": [
    {
      "element": "fetchUserData",
      "category": "resource_leak",
      "finding": "Незакрытое тело HTTP-ответа resp.Body",
      "detail": "После вызова http.Get тело ответа resp.Body не закрывается через defer resp.Body.Close(). Это приводит к утечке ресурсов: соединения не возвращаются в пул транспорта, что при многократных вызовах исчерпывает файловые дескрипторы."
    },
    {
      "element": "saveToFile",
      "category": "security",
      "finding": "saveToFile — небезопасный sink без валидации filename",
      "detail": "Функция принимает параметр filename и передаёт его напрямую в ioutil.WriteFile без какой-либо проверки или очистки пути. Сама функция не ограничивает содержимое filename; единственный вызов в main() строит имя из числового userID, поэтому в текущем diff путь traversal не эксплуатируется, но отсутствие валидации внутри функции остаётся риском для любого другого вызывающего кода."
    },
    {
      "element": "ioutil",
      "category": "deprecated",
      "finding": "Использование устаревшего пакета ioutil",
      "detail": "Функции ioutil.ReadAll и ioutil.WriteFile объявлены deprecated начиная с Go 1.16. Рекомендуемая замена — io.ReadAll и os.WriteFile соответственно из актуальных пакетов стандартной библиотеки."
    },
    {
      "element": "main",
      "category": "error_handling",
      "finding": "Игнорируется ошибка fmt.Scanln",
      "detail": "Вызов fmt.Scanln(&input) возвращает ошибку, которая не проверяется и не обрабатывается. При сбое чтения из стандартного ввода переменная input может остаться пустой строкой, и код перейдёт к strconv.Atoi без учёта этой ошибки. Ошибка strconv.Atoi, в отличие от неё, обрабатывается корректно через if err != nil сразу после вызова."
    }
  ]
}
JSON
