"""
Верификатор кейса b2c_case_04_44.
Агент пишет answer.json со структурированным анализом git diff (Go).
Проверяет схему, элементы, обязательные findings и содержательность.

Схема, допустимые элементы/категории/типы, пороги объёма, обязательные и
альтернативные findings загружаются ЕДИНОЖДЫ из неизменяемой фикстуры
/tests/fixtures/answer_schema.json (DRY — единственный источник правды).

Контракт после раунда ревью:

Обязательными являются только те findings, которые ОДНОЗНАЧНО обоснованы и кодом,
и категорией:
  1. fetchUserData / resource_leak — resp.Body не закрывается.
  2. ioutil       / deprecated     — ioutil.ReadAll и ioutil.WriteFile.
  3. main         / error_handling — игнорируется ошибка fmt.Scanln.

Каждый обязательный finding проверяется НЕ одним произвольным keyword'ом, а
AND-группой ключевых слов (конкретный факт кода И конкретная техническая суть
проблемы), чтобы generic-ответ вида «нашли уязвимость, всё плохо» не мог получить
reward=1 — только предметный анализ diff.

Сверх обязательных findings ответ должен закрыть минимум один пункт из пула
alternative_findings. Пул — прямое следствие замечания ревью: verifier был
привязан к одному спорному обязательному finding (saveToFile / security), из-за
чего правдоподобная альтернативная рецензия получала reward=0. Теперь
saveToFile / security лежит в пуле наравне с непроверенным resp.StatusCode,
отсутствием таймаута у http.Get и изменяемым пакетным APIBaseURL.

Намеренно НЕ являются обязательными (обоснование — notes_on_dropped_findings):
  - saveToFile / security: единственный показанный call site формирует имя как
    user_<числовой userID>.json, риск управления путём из него не следует;
  - SSRF на fetchUserData: APIBaseURL захардкожен, userID типа int;
  - отсутствие таймаута у http.Get как security: спорная таксономия.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "9692355e36f101c7ca9b0388322b94d7c5cb6d8e282261ba347d742ef3f5c207"
PROMPT_SHA256 = "0a28c2157a04c6ac76778f6f67c3e1e10a39296c39e797fa4d1398ee19a7d94e"
SCHEMA_SHA256 = "086a0a2c9018f8957e67630ec123e162efd08e2fe85876097cc3f202e87ade1f"


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]
ALTERNATIVE_FINDINGS = _SCHEMA["alternative_findings"]
MIN_CHANGES = _SCHEMA["min_changes"]
MIN_FINDINGS = _SCHEMA["min_findings"]
MIN_ALTERNATIVE_FINDINGS = _SCHEMA["min_alternative_findings"]


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _norm(s):
    return (s or "").strip().lower()


def _finding_text(f):
    return _norm(f.get("finding", "") + " " + f.get("detail", ""))


def _spec_categories(spec):
    """Спецификация задаёт либо одну категорию, либо набор допустимых: для части
    замечаний таксономия объективно неоднозначна (например, отсутствие таймаута —
    это и security, и resource_leak, и error_handling), и агент не обязан
    угадывать единственный вариант."""
    if "categories" in spec:
        return {c.lower() for c in spec["categories"]}
    return {spec["category"].lower()}


def _match_spec(data, spec):
    """Спецификация засчитана, если найдена запись с совпадающим element и
    категорией из допустимого набора, чей текст (finding + detail) содержит ВСЕ
    ключевые слова хотя бы одной из групп keyword_groups (AND внутри группы,
    OR между группами). Одиночное общеупотребительное слово контракт не
    закрывает."""
    el = _norm(spec["element"])
    cats = _spec_categories(spec)
    for f in data["important_findings"]:
        if _norm(f.get("element", "")) != el:
            continue
        if _norm(f.get("category", "")) not in cats:
            continue
        text = _finding_text(f)
        if any(all(kw in text for kw in group) for group in spec["keyword_groups"]):
            return f
    return None


def _spec_by_id(specs, spec_id):
    for s in specs:
        if s["id"] == spec_id:
            return s
    raise KeyError(spec_id)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_go():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла."""
    data = _load()
    assert "go" in _norm(data.get("file", "")), \
        f"Поле file не содержит имя Go-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: объём changes не ниже порога из фикстуры — 4 обязательных
    элемента (функции + переменная) плюс минимум по одному import и statement.
    Порог продублирован в instruction.md, скрытых порогов в кейсе нет."""
    data = _load()
    assert len(data["changes"]) >= MIN_CHANGES, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= {MIN_CHANGES}"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты fetchUserData, saveToFile, APIBaseURL, main."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, \
        f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_type_coverage():
    """FAIL_TO_PASS: changes должны содержать не только function/variable, но и
    хотя бы один import и хотя бы одну statement-level конструкцию
    (например http.Get, fmt.Scanln, ioutil.WriteFile и т.п.)."""
    data = _load()
    types_present = {_norm(c.get("type", "")) for c in data["changes"]}
    assert "import" in types_present, \
        "В changes нет ни одного элемента с type=import"
    assert "statement" in types_present, \
        "В changes нет ни одного элемента с type=statement"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"]
               if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, \
        f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не является просто копипастом имени элемента)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, \
            f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), \
            f"description для '{el}' — просто копипаст имени элемента"
        words = re.findall(r'\w+', desc.lower())
        assert len(set(words)) >= 4, \
            f"description для '{el}' содержит слишком мало уникальных слов: {set(words)}"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, \
            f"Недопустимый type '{c.get('type')}' для элемента '{c.get('element')}'"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: объём important_findings не ниже порога из фикстуры."""
    data = _load()
    assert len(data["important_findings"]) >= MIN_FINDINGS, \
        f"important_findings содержит {len(data['important_findings'])} элементов, нужно >= {MIN_FINDINGS}"


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, \
        f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст finding)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, \
            f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r'\w+', detail.lower())
        assert len(set(words)) >= 5, \
            f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), \
            f"detail для '{el}' — просто копипаст поля finding"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих пар (element, category) в important_findings."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")))
        assert key not in seen, \
            f"Дублирующая пара (element, category): {key}"
        seen.add(key)


def test_findings_have_distinct_details():
    """FAIL_TO_PASS: одно и то же объяснение не может закрывать несколько разных
    findings — повторяющийся detail означает generic-текст, скопированный между
    записями."""
    data = _load()
    seen = {}
    for f in data["important_findings"]:
        key = _norm(f.get("detail", ""))
        assert key not in seen, (
            f"detail записи для '{f.get('element')}' дословно повторяет detail "
            f"записи для '{seen[key]}'"
        )
        seen[key] = f.get("element")


# ── fail_to_pass: обязательные findings по контракту (AND-группы keywords) ───

def test_finding_resource_leak_present():
    """FAIL_TO_PASS: fetchUserData / resource_leak — конкретно про resp.Body
    И отсутствие close/defer."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "resp_body_not_closed")
    assert _match_spec(data, spec), (
        f"Нет finding: {spec['element']} / {spec['category']} — незакрытый resp.Body. "
        f"Нужно назвать и сам объект, и суть проблемы, а не общее ключевое слово"
    )


def test_finding_deprecated_ioutil_present():
    """FAIL_TO_PASS: finding о deprecated ioutil должен называть ОБЕ функции —
    ioutil.ReadAll И ioutil.WriteFile, а не просто слово 'ioutil'."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "deprecated_ioutil")
    assert _match_spec(data, spec), (
        f"Нет finding: {spec['element']} / {spec['category']} — deprecated "
        f"ioutil.ReadAll и ioutil.WriteFile"
    )


def test_finding_scanln_ignored_error_present():
    """FAIL_TO_PASS: main / error_handling — именно про fmt.Scanln И про то,
    что его ошибка игнорируется. Это не про strconv.Atoi — там ошибка
    обрабатывается корректно (if err != nil ниже по коду)."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "scanln_ignored_error")
    assert _match_spec(data, spec), (
        f"Нет finding: {spec['element']} / {spec['category']} — игнорируемая "
        f"ошибка fmt.Scanln"
    )


def test_at_least_one_alternative_finding_present():
    """FAIL_TO_PASS: сверх обязательных findings ответ закрывает минимум
    MIN_ALTERNATIVE_FINDINGS пунктов из пула технически обоснованных альтернатив
    (небезопасный sink saveToFile, непроверенный resp.StatusCode, отсутствие
    таймаута у http.Get, изменяемый пакетный APIBaseURL). Пул заменил жёсткую
    привязку к одному спорному обязательному finding."""
    data = _load()
    matched = [spec["id"] for spec in ALTERNATIVE_FINDINGS if _match_spec(data, spec)]
    assert len(matched) >= MIN_ALTERNATIVE_FINDINGS, (
        f"Закрыто альтернативных findings: {len(matched)} ({matched}), "
        f"нужно >= {MIN_ALTERNATIVE_FINDINGS}. Допустимые варианты: "
        f"{[s['id'] for s in ALTERNATIVE_FINDINGS]}"
    )


def test_finding_does_not_misattribute_atoi_error_handling():
    """FAIL_TO_PASS (anti-cheat): error_handling finding не должен утверждать,
    что ошибка strconv.Atoi не обрабатывается — в коде она явно проверяется
    через if err != nil сразу после вызова. Ответ не должен путать Atoi и Scanln."""
    data = _load()
    for f in data["important_findings"]:
        if _norm(f.get("category", "")) != "error_handling":
            continue
        text = _finding_text(f)
        if "atoi" in text:
            assert "scanln" in text, (
                "error_handling finding упоминает strconv.Atoi как источник "
                "необработанной ошибки, хотя в коде она обрабатывается корректно; "
                "необработана только ошибка fmt.Scanln"
            )
