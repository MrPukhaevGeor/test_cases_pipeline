"""
Верификатор кейса b2c_case_04_44.
Агент пишет answer.json со структурированным анализом git diff.
Проверяет схему, элементы, обязательные findings и содержательность.

Каждый обязательный finding проверяется НЕ одним произвольным keyword'ом,
а конъюнкцией из двух групп ключевых слов (конкретный факт кода И конкретная
техническая суть проблемы), чтобы generic-ответ вида "нашли уязвимость,
всё плохо" не мог получить reward=1 — только предметный анализ diff.

Обязательными являются только те findings, которые ОДНОЗНАЧНО обоснованы и
кодом, и категорией:
  1. fetchUserData / resource_leak — resp.Body не закрывается.
  2. saveToFile   / security       — filename попадает в ioutil.WriteFile без
     валидации (unsafe sink; в текущем call site имя строится из числового
     userID, поэтому готовый Path Traversal из этого diff НЕ следует — формулировка
     не переоценивает эксплуатируемость).
  3. ioutil       / deprecated     — ioutil.ReadAll и ioutil.WriteFile.
  4. main         / error_handling — игнорируется ошибка fmt.Scanln.

Намеренно НЕ являются обязательными:
  - SSRF на fetchUserData: APIBaseURL захардкожен, userID типа int — пользователь
    не контролирует host/scheme, SSRF из diff не следует.
  - "отсутствие таймаута у http.Get" как security: спорная таксономия
    (reliability/DoS, а не чистый security). Агент вправе добавить такой finding
    под подходящей категорией, но верификатор его не требует и не запрещает.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "9692355e36f101c7ca9b0388322b94d7c5cb6d8e282261ba347d742ef3f5c207"
PROMPT_SHA256 = "0a28c2157a04c6ac76778f6f67c3e1e10a39296c39e797fa4d1398ee19a7d94e"


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


VALID_ELEMENTS = {e.lower() for e in _load_schema()["valid_elements"]}
VALID_CATEGORIES = {"security", "resource_leak", "deprecated", "error_handling"}

# Элементы обязательные в секции changes (конкретные имена)
REQUIRED_IN_CHANGES = {"fetchuserdata", "savetofile", "apibaseurl", "main"}


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _norm(s):
    return (s or "").strip().lower()


def _finding_text(f):
    return _norm(f.get("finding", "") + " " + f.get("detail", ""))


def _matches_groups(text, group_a, group_b):
    return any(kw in text for kw in group_a) and any(kw in text for kw in group_b)


def _assert_required_finding(element, category, group_a, group_b, label):
    """Обязательный finding засчитывается только если совпал element+category
    И встретился хотя бы один keyword ИЗ КАЖДОЙ группы (факт кода + суть проблемы)."""
    data = _load()
    matched = [
        f for f in data["important_findings"]
        if (element is None or _norm(f.get("element", "")) == element)
        and _norm(f.get("category", "")) == category
        and _matches_groups(_finding_text(f), group_a, group_b)
    ]
    assert matched, (
        f"Нет finding: {element or '(любой элемент)'} / {category} / {label} — "
        f"нужно упомянуть факт из {group_a} И суть проблемы из {group_b}, "
        f"а не только общее ключевое слово"
    )


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    SCHEMA_SHA256 = "ab1c807c2744af9bf0cab67830184e583e25e91126748db07231c826b692a4c3"
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    h = hashlib.sha256(open(FIXTURE, "rb").read()).hexdigest()
    assert h == SCHEMA_SHA256, f"Fixture схема изменена: ожидался {SCHEMA_SHA256}, получен {h}"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_go():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла."""
    data = _load()
    assert "go" in _norm(data.get("file", "")), \
        f"Поле file не содержит имя Go-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: в changes минимум 6 элементов — 4 обязательных
    (функции + переменная) плюс минимум по одному import и statement."""
    data = _load()
    assert len(data["changes"]) >= 6, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= 6"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты fetchUserData, saveToFile, APIBaseURL, main."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, \
        f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_type_coverage():
    """FAIL_TO_PASS: инструкция требует анализировать 'все функции, переменные
    и конструкции из diff' — changes должны содержать не только function/variable,
    но и хотя бы один import и хотя бы одну statement-level конструкцию
    (например http.Get, fmt.Scanln, ioutil.WriteFile и т.п.)."""
    data = _load()
    types_present = {_norm(c.get("type", "")) for c in data["changes"]}
    assert "import" in types_present, \
        "В changes нет ни одного элемента с type=import"
    assert "statement" in types_present, \
        "В changes нет ни одного элемента с type=statement"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = []
    for c in data["changes"]:
        el = _norm(c.get("element", ""))
        if el not in VALID_ELEMENTS:
            invalid.append(c.get("element"))
    assert not invalid, \
        f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не является просто копипастом имени элемента)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, \
            f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), \
            f"description для '{el}' — просто копипаст имени элемента"
        words = re.findall(r'\w+', desc.lower())
        assert len(set(words)) >= 4, \
            f"description для '{el}' содержит слишком мало уникальных слов: {set(words)}"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    valid = {"function", "variable", "import", "statement"}
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in valid, \
            f"Недопустимый type '{c.get('type')}' для элемента '{c.get('element')}'"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: в important_findings минимум 4 finding."""
    data = _load()
    assert len(data["important_findings"]) >= 4, \
        f"important_findings содержит {len(data['important_findings'])} элементов, нужно >= 4"


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = []
    for f in data["important_findings"]:
        el = _norm(f.get("element", ""))
        if el not in VALID_ELEMENTS:
            invalid.append(f.get("element"))
    assert not invalid, \
        f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст finding)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, \
            f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r'\w+', detail.lower())
        assert len(set(words)) >= 5, \
            f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), \
            f"detail для '{el}' — просто копипаст поля finding"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих пар (element, category) в important_findings."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")))
        assert key not in seen, \
            f"Дублирующая пара (element, category): {key}"
        seen.add(key)


# ── fail_to_pass: обязательные findings по контракту (AND-группы keywords) ───

def test_finding_resource_leak_present():
    """FAIL_TO_PASS: fetchUserData / resource_leak — конкретно про resp.Body
    И отсутствие close/defer."""
    _assert_required_finding(
        "fetchuserdata", "resource_leak",
        ["body", "resp"], ["close", "defer", "закры"],
        "незакрытый resp.Body",
    )


def test_finding_savetofile_unsafe_sink_present():
    """FAIL_TO_PASS: saveToFile / security — конкретно про параметр filename
    И отсутствие валидации/очистки пути (unsafe sink), без переоценки
    эксплуатируемости: единственный call site строит имя из числового userID,
    поэтому готовый Path Traversal сценарий из этого diff не следует."""
    _assert_required_finding(
        "savetofile", "security",
        ["filename"], ["валидац", "провер", "очистк", "sanitiz"],
        "saveToFile как unsafe sink без валидации filename",
    )


def test_finding_deprecated_ioutil_present():
    """FAIL_TO_PASS: finding о deprecated ioutil должен называть ОБЕ функции —
    ioutil.ReadAll И ioutil.WriteFile, а не просто слово 'ioutil'."""
    _assert_required_finding(
        None, "deprecated",
        ["ioutil.readall"], ["ioutil.writefile"],
        "deprecated ioutil.ReadAll и ioutil.WriteFile",
    )


def test_finding_scanln_ignored_error_present():
    """FAIL_TO_PASS: main / error_handling — именно про fmt.Scanln И про то,
    что его ошибка игнорируется. Это не про strconv.Atoi — там ошибка
    обрабатывается корректно (if err != nil ниже по коду)."""
    _assert_required_finding(
        "main", "error_handling",
        ["scanln"], ["ошибк", "error", "игнориру"],
        "игнорируемая ошибка fmt.Scanln",
    )


def test_finding_does_not_misattribute_atoi_error_handling():
    """FAIL_TO_PASS (anti-cheat): error_handling finding не должен утверждать,
    что ошибка strconv.Atoi не обрабатывается — в коде она явно проверяется
    через if err != nil сразу после вызова. Ответ не должен путать Atoi и Scanln."""
    data = _load()
    for f in data["important_findings"]:
        if _norm(f.get("category", "")) != "error_handling":
            continue
        text = _finding_text(f)
        if "atoi" in text:
            assert "scanln" in text, (
                "error_handling finding упоминает strconv.Atoi как источник "
                "необработанной ошибки, хотя в коде она обрабатывается корректно; "
                "необработана только ошибка fmt.Scanln"
            )
