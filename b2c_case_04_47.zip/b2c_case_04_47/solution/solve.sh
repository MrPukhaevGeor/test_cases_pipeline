#!/bin/sh
cat > /app/answer.json << 'JSON'
{
  "file": "csharp.cs",
  "changes": [
    {
      "element": "CSharpWithErrors",
      "type": "class",
      "description": "Добавлен публичный класс, объединяющий статическое поле конфигурации и три статических метода: получение данных по сети, запись результата на диск и точку входа приложения."
    },
    {
      "element": "ApiBaseUrl",
      "type": "variable",
      "description": "Объявлено публичное статическое поле типа string со значением базового адреса внешнего API. Модификатора readonly или const нет, значение используется при формировании URL запроса."
    },
    {
      "element": "FetchUserData",
      "type": "function",
      "description": "Асинхронный метод принимает userId типа int, собирает адрес интерполяцией строки, создаёт экземпляр HttpClient в блоке using, выполняет GetAsync и возвращает тело ответа строкой через ReadAsStringAsync."
    },
    {
      "element": "SaveToFile",
      "type": "function",
      "description": "Метод принимает две строки, data и filename, и записывает содержимое на диск одним вызовом File.WriteAllText. Значение filename используется как путь без дополнительной обработки."
    },
    {
      "element": "Main",
      "type": "function",
      "description": "Асинхронная точка входа: печатает приглашение через Console.Write, читает строку через Console.ReadLine, преобразует её в число вызовом int.Parse и последовательно вызывает FetchUserData и SaveToFile."
    },
    {
      "element": "HttpClient",
      "type": "statement",
      "description": "Экземпляр клиента создаётся оператором using внутри тела метода, то есть заново при каждом обращении, вместо переиспользования одного общего долгоживущего объекта."
    },
    {
      "element": "File.WriteAllText",
      "type": "statement",
      "description": "Вызов записи текста в файл принимает путь и содержимое, создаёт или перезаписывает целевой файл и не выполняет проверок переданного пути."
    },
    {
      "element": "System.Net.Http",
      "type": "import",
      "description": "Подключено пространство имён стандартной библиотеки, откуда берётся тип HttpClient и связанные с ним методы асинхронных сетевых запросов."
    }
  ],
  "important_findings": [
    {
      "element": "FetchUserData",
      "category": "error_handling",
      "status": "confirmed",
      "finding": "Статус HTTP-ответа не проверяется перед чтением тела",
      "detail": "Перед чтением тела через ReadAsStringAsync не проверяется response.IsSuccessStatusCode и не вызывается EnsureSuccessStatusCode. При ответе 404 или 500 метод вернёт тело ошибки вызывающему коду как обычный успешный результат, и дальше оно будет сохранено на диск как данные пользователя."
    },
    {
      "element": "Main",
      "category": "error_handling",
      "status": "confirmed",
      "finding": "Необработанное исключение int.Parse на нечисловом вводе",
      "detail": "Строка из Console.ReadLine передаётся в int.Parse без проверки. На нечисловом вводе вызов выбрасывает FormatException, на пустом потоке ввода Console.ReadLine возвращает null и вызов выбрасывает ArgumentNullException. Ни одно из этих исключений не перехватывается, процесс аварийно завершается; безопасный вариант — int.TryParse."
    },
    {
      "element": "FetchUserData",
      "category": "resource_leak",
      "status": "confirmed",
      "finding": "Новый HttpClient на каждый вызов метода",
      "detail": "Экземпляр HttpClient создаётся заново на каждый вызов метода. Сам блок using освобождает объект корректно, в том числе при выходе через исключение, но закрытые TCP-соединения остаются в состоянии TIME_WAIT, поэтому при частых обращениях исчерпывается пул эфемерных портов. Штатное решение — один долгоживущий клиент или IHttpClientFactory."
    },
    {
      "element": "File.WriteAllText",
      "category": "error_handling",
      "status": "confirmed",
      "finding": "Ошибки записи файла не обрабатываются",
      "detail": "Вызов File.WriteAllText выполняется без обработки исключений. Если у процесса нет прав на запись в каталог, диск заполнен или файл занят другим процессом, IOException или UnauthorizedAccessException поднимется до Main и завершит программу, а уже полученные по сети данные будут потеряны."
    },
    {
      "element": "ApiBaseUrl",
      "category": "code_quality",
      "status": "confirmed",
      "finding": "Публичное изменяемое статическое поле конфигурации",
      "detail": "Поле объявлено как public static без readonly и const, то есть любой код внутри процесса может изменить базовый адрес сервиса во время работы приложения. Это общее изменяемое глобальное состояние: конфигурация не инкапсулирована, а поведение сетевого метода зависит от того, кто и когда переписал значение."
    },
    {
      "element": "FetchUserData",
      "category": "security",
      "status": "not_applicable",
      "finding": "SSRF через параметр userId",
      "detail": "Типовая для такого кода проверка. Базовый адрес задан строковой константой, а userId имеет тип int и подставляется только в сегмент пути. Управлять схемой, хостом или портом запроса вызывающая сторона через этот параметр не может, поэтому данный класс уязвимости текущим потоком данных не обосновывается."
    }
  ]
}
JSON
