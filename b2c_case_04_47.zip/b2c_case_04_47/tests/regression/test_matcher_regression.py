"""
Regression-тесты самого verifier'а кейса b2c_case_04_47 (не часть reward-контракта агента).

Проверяют matcher на фиксированных контрольных ответах, а не на живом ответе агента:

  1. negative_negation.json — ответ, где element/category/ключевые слова верные и
     status=confirmed, но текст утверждает ОТСУТСТВИЕ проблемы («SSRF отсутствует»,
     «Path Traversal отсутствует», «проблема не подтверждается»). Matcher обязан
     не засчитать обязательные findings.

  2. negative_generic_keywords.json — формальное упоминание проблемы без механики
     дефекта («может привести к ошибке»). Matcher обязан не засчитать обязательные
     findings.

  3. positive_alt_savetofile.json / positive_alt_endpoint.json — технически
     корректные альтернативные рецензии, сформулированные другими словами и
     закрывающие РАЗНЫЕ пункты пула альтернатив. Обе обязаны закрывать контракт
     полностью, иначе verifier даёт ложноотрицательный результат.

Плюс регрессы на замечания последнего раунда:
  - отрицание дефекта не закрывает контракт, но отрицательные формы
    («небезопасный приёмник») и рекомендация («безопасный вариант — TryParse»)
    отрицанием не считаются;
  - субъективная оценка качества замечанием не является;
  - тип элемента сверяется с тем, чем элемент является в коде;
  - совпадения расходуются один к одному;
  - привязка к месту вызова (int.Parse, GetAsync) принимается наравне с привязкой
    к методу;
  - дедупликация ослаблена до тройки (element, category, finding).

Дополнительно проверяется, что список valid_elements фикстуры не разъезжается с
фактическим diff.txt.

Запускать вручную при любом изменении matcher'а / keyword_groups / causal_markers /
denial_patterns, до сдачи кейса. Не входит в tests/test.sh и на reward не влияет —
это проверка качества самого verifier'а, а не агента.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
sys.path.insert(0, TESTS_DIR)

import test_verifier as tv  # noqa: E402

# diff.txt лежит в пакете рядом с tests/, а в рантайме (tests примонтированы
# как /tests) — в /app. Проверяем обе раскладки, иначе тест падает с
# FileNotFoundError при запуске из собранного окружения.
_DIFF_CANDIDATES = (
    os.path.join(os.path.dirname(TESTS_DIR), "environment", "repo", "diff.txt"),
    os.path.join(tv.APP, "diff.txt"),
)
_REPO_DIFF = next(
    (p for p in _DIFF_CANDIDATES if os.path.isfile(p)), _DIFF_CANDIDATES[0]
)


def _load_fixture(name):
    with open(os.path.join(HERE, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _matched_required(data):
    assigned, _ = tv._assignment(data)
    return [s["id"] for s in tv.REQUIRED_FINDINGS if s["id"] in assigned]


def _matched_alternatives(data):
    _, alternatives = tv._assignment(data)
    return alternatives


# ── 1. отрицание не должно закрывать контракт ────────────────────────────────

def test_negation_answer_does_not_satisfy_required_findings():
    data = _load_fixture("negative_negation.json")
    matched = _matched_required(data)
    assert not matched, (
        f"Matcher засчитал ответ-отрицание как подтверждение проблемы: {matched}"
    )


def test_negation_answer_does_not_satisfy_alternatives():
    data = _load_fixture("negative_negation.json")
    matched = _matched_alternatives(data)
    assert not matched, f"Matcher засчитал отрицание как альтернативный finding: {matched}"


def test_negation_detected_by_presence_check():
    """Каждая запись контрольного ответа помечена confirmed, но текстом отрицает
    проблему — проверка наличия обязана это увидеть."""
    data = _load_fixture("negative_negation.json")
    offenders = [
        f["element"] for f in data["important_findings"]
        if tv._is_confirmed(f) and tv._is_denial(tv._finding_text(f))
    ]
    assert len(offenders) == len(data["important_findings"]), (
        f"Не все отрицающие записи распознаны как отрицание; распознаны: {offenders}"
    )


def test_negative_word_forms_are_not_denial():
    """Отрицательные формы и рекомендации описывают дефект, а не его отсутствие:
    «небезопасный приёмник» и «безопасный вариант — TryParse» отрицанием
    считаться не должны."""
    affirmations = (
        "Метод остаётся небезопасным приёмником данных, если имя придёт извне.",
        "Исключение не перехватывается; безопасный вариант — int.TryParse.",
        "При некорректном вводе процесс завершается аварийно.",
    )
    for text in affirmations:
        assert not tv._is_denial(text), f"Утверждение о дефекте принято за отрицание: {text!r}"


# ── 2. формальное упоминание без механики не должно закрывать контракт ───────

def test_generic_keywords_answer_does_not_satisfy_required_findings():
    data = _load_fixture("negative_generic_keywords.json")
    matched = _matched_required(data)
    assert not matched, (
        f"Matcher засчитал generic-объяснение без механики дефекта: {matched}"
    )


def test_generic_keywords_answer_does_not_satisfy_alternatives():
    data = _load_fixture("negative_generic_keywords.json")
    matched = _matched_alternatives(data)
    assert not matched, f"Matcher засчитал generic-объяснение как альтернативный finding: {matched}"


def test_bare_mozhet_is_not_a_causal_marker():
    """Общая фраза «может привести к ошибке» причинной связкой не считается."""
    assert not tv._has_causal_link(
        "Использование этого вызова может привести к ошибке в работе программы.", "security"
    ), "«может привести к ошибке» ошибочно принято за причинную связку"


# ── 3. корректные альтернативные рецензии обязаны проходить ──────────────────

def test_alternative_reviews_satisfy_full_contract():
    for name in ("positive_alt_savetofile.json", "positive_alt_endpoint.json"):
        data = _load_fixture(name)

        matched_req = _matched_required(data)
        missing = [s["id"] for s in tv.REQUIRED_FINDINGS if s["id"] not in matched_req]
        assert not missing, (
            f"{name}: verifier не засчитал обязательные findings, "
            f"сформулированные синонимично: {missing}"
        )

        matched_alt = _matched_alternatives(data)
        assert len(matched_alt) >= tv.MIN_ALTERNATIVE_FINDINGS, (
            f"{name}: закрыто альтернативных findings {len(matched_alt)} "
            f"({matched_alt}), нужно >= {tv.MIN_ALTERNATIVE_FINDINGS}"
        )

        confirmed = tv._confirmed_findings(data)
        assert len(confirmed) >= tv.MIN_CONFIRMED_FINDINGS, (
            f"{name}: подтверждённых findings {len(confirmed)}, "
            f"нужно >= {tv.MIN_CONFIRMED_FINDINGS}"
        )


def test_alternative_reviews_cover_different_alternatives():
    """Две контрольные рецензии закрывают РАЗНЫЕ пункты пула — иначе пул
    альтернатив фактически не проверен."""
    a = set(_matched_alternatives(_load_fixture("positive_alt_savetofile.json")))
    b = set(_matched_alternatives(_load_fixture("positive_alt_endpoint.json")))
    assert a and b and a != b, (
        f"Контрольные рецензии закрывают один и тот же набор альтернатив: {a} / {b}"
    )


# ── 4. семантика записей (замечание F002) ────────────────────────────────────

def test_subjective_assessment_is_detected():
    subjective = (
        "Код написан неаккуратно и выглядит устаревшим.",
        "В целом код плохого качества, автору стоило бы переписать фрагмент.",
        "Метод сделан наспех.",
    )
    for text in subjective:
        assert tv._is_subjective(text), f"Субъективная оценка не распознана: {text!r}"


def test_technical_wording_is_not_subjective():
    technical = (
        "Метод создаёт новый HttpClient при каждом вызове, поэтому сокеты копятся в TIME_WAIT.",
        "Статус ответа не проверяется, и тело ошибки возвращается как данные.",
    )
    for text in technical:
        assert not tv._is_subjective(text), f"Технический факт принят за оценку: {text!r}"


def test_element_type_mapping_rejects_wrong_types():
    """Метод не может быть variable, пространство имён — function."""
    assert "function" in tv.ELEMENT_TYPES["fetchuserdata"]
    assert "variable" not in tv.ELEMENT_TYPES["fetchuserdata"]
    assert tv.ELEMENT_TYPES["system.net.http"] == {"import"}
    assert tv.ELEMENT_TYPES["csharpwitherrors"] == {"class"}


# ── 5. один к одному и привязка к месту вызова (замечания F002/F003) ─────────

def test_merged_record_closes_only_one_spec():
    """«Сборная» запись, перечисляющая сразу два дефекта, закрывает ровно одну
    спецификацию."""
    merged = {
        "element": "FetchUserData",
        "category": "error_handling",
        "status": "confirmed",
        "finding": "Ошибки сети и разбора",
        "detail": ("IsSuccessStatusCode не проверяется, поэтому тело ошибки вернётся как "
                   "данные; кроме того на нечисловом вводе вылетает FormatException, "
                   "которое нигде не перехватывается."),
    }
    data = {"file": "csharp.cs", "changes": [], "important_findings": [merged]}
    assigned, _ = tv._assignment(data)
    assert len(assigned) == 1, f"Одна запись закрыла несколько спецификаций: {sorted(assigned)}"


def test_call_site_binding_is_accepted():
    """Привязка к конкретному вызову принимается наравне с привязкой к методу."""
    cases = (
        ("int_parse_unhandled", "int.Parse", "error_handling",
         "На нечисловом вводе int.Parse выбрасывает FormatException, и это исключение "
         "нигде не перехватывается, поэтому процесс завершается аварийно."),
        ("no_status_check", "GetAsync", "error_handling",
         "Результат GetAsync читается сразу: IsSuccessStatusCode не проверяется, поэтому "
         "при ответе 404 тело ошибки вернётся вызывающему коду как данные."),
    )
    for spec_id, element, category, detail in cases:
        spec = tv._spec_by_id(tv.REQUIRED_FINDINGS, spec_id)
        record = {"element": element, "category": category, "status": "confirmed",
                  "finding": "Замечание к вызову", "detail": detail}
        assert tv._record_matches_spec(record, spec), (
            f"Привязка к месту вызова '{element}' не принята для {spec_id}"
        )


def test_two_distinct_problems_share_element_and_category():
    """Две содержательно разные проблемы одного метода в одной категории —
    законный ответ: дедупликация работает по тройке, а не по паре."""
    data = _load_fixture("positive_alt_endpoint.json")
    extra = {
        "element": "Main", "category": "error_handling", "status": "confirmed",
        "finding": "Нет обработки сетевой ошибки",
        "detail": ("Вызов FetchUserData выполняется без try/catch, поэтому при недоступности "
                   "сервиса исключение поднимется из точки входа и процесс завершится."),
    }
    data["important_findings"].append(extra)
    keys = [(f["element"].lower(), f["category"].lower(), f["finding"].lower())
            for f in data["important_findings"]]
    assert len(keys) == len(set(keys)), "Тройки (element, category, finding) должны различаться"
    missing = [s["id"] for s in tv.REQUIRED_FINDINGS if s["id"] not in _matched_required(data)]
    assert not missing, f"Добавление второй проблемы той же пары сломало контракт: {missing}"


# ── 6. фикстура не разъезжается с diff ───────────────────────────────────────

def test_valid_elements_actually_present_in_diff():
    """Каждый элемент из valid_elements реально встречается в diff.txt —
    список элементов и типов синхронизирован с фактическим кодом."""
    with open(_REPO_DIFF, "r", encoding="utf-8") as f:
        diff = f.read()
    missing = [e for e in tv._SCHEMA["valid_elements"] if e not in diff]
    assert not missing, f"valid_elements содержит элементы, которых нет в diff: {missing}"


def test_element_types_cover_all_valid_elements():
    """Для каждого допустимого элемента задан допустимый набор типов."""
    missing = [e for e in tv._SCHEMA["valid_elements"] if e.lower() not in tv.ELEMENT_TYPES]
    assert not missing, f"Для элементов не задан тип: {missing}"


def test_required_and_alternative_elements_are_valid():
    """Элементы всех спецификаций входят в valid_elements (нет опечаток)."""
    specs = tv.REQUIRED_FINDINGS + tv.ALTERNATIVE_FINDINGS
    bad = [s["id"] for s in specs if not tv._spec_elements(s) <= tv.VALID_ELEMENTS]
    assert not bad, f"Спецификации ссылаются на элементы вне valid_elements: {bad}"
