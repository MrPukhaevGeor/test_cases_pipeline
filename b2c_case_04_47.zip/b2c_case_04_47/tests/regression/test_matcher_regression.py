"""
Регрессионные тесты verifier'а кейса b2c_case_04_47 (на reward агента не влияют).

Норма кейса (решение владельца 28.09): засчитываются любые не менее трёх подтверждённых
записей о реальных дефектах показанного кода; обязательного состава и формулировок нет.

Каждая фикстура прогоняется через ВСЕ fail_to_pass-проверки verifier'а как answer.json
агента: позитив обязан пройти все, негатив — упасть хотя бы на одной.

Позитивы — технически верные рецензии в разном составе и разными словами: пять находок с
привязкой разбора к userId, HttpClient в категории code_quality и законным not_applicable
про автоматический Dispose (G1 из отчёта УМР); набор HTTP status + int.Parse +
File.WriteAllText/error_handling; синонимичные и английские формулировки; правда со
словами «нет/отсутствует/риск»; сетевые исключения вместо записи файла.

Негативы — рецензии, которые обязаны отклоняться: подтверждённый directory traversal
через filename (K2), ошибки File.WriteAllText как not_applicable из-за «корректного
окружения» (M1), «using не вызывает Dispose при исключении», ложное описание операции в
changes, SSRF, «GetAsync бросает исключение на 404», посторонняя запись вместо третьей
находки, несвязанная привязка, несуществующий элемент, набор терминов, отрицание,
мягкое отрицание, общая фраза, субъективная оценка.

Запуск: python -m pytest tests/regression -q
"""
import json
import os
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
sys.path.insert(0, TESTS_DIR)

import test_verifier as tv  # noqa: E402

_DIFF_CANDIDATES = (
    os.path.join(os.path.dirname(TESTS_DIR), "environment", "repo", "diff.txt"),
    os.path.join(tv.APP, "diff.txt"),
)
_REPO_DIFF = next((p for p in _DIFF_CANDIDATES if os.path.isfile(p)), _DIFF_CANDIDATES[0])

_P2P = {"test_inputs_present_and_untouched", "test_fixture_schema_intact",
        "test_visible_contract_matches_fixture"}

POSITIVE = [
    "positive_changes_extra_elements.json",
    "positive_g1_five_findings.json",
    "positive_negation_words.json",
    "positive_network_errors.json",
    "positive_status_parse_write.json",
    "positive_synonyms_en.json"
]
NEGATIVE = [
    "negative_denial_confirmed.json",
    "negative_false_change.json",
    "negative_generic.json",
    "negative_generic_keywords.json",
    "negative_getasync_throws.json",
    "negative_k2_traversal.json",
    "negative_keyword_soup.json",
    "negative_logging_extra.json",
    "negative_m1_not_applicable.json",
    "negative_negation.json",
    "negative_soft_denial.json",
    "negative_ssrf.json",
    "negative_subjective.json",
    "negative_unknown_element.json",
    "negative_unrelated_binding.json",
    "negative_using_dispose.json"
]
SOFT_AND_NAMED_DENIALS = [
    "SSRF отсутствует: адрес формируется из константы.",
    "Path Traversal отсутствует, потому что идентификатор имеет тип int.",
    "Уязвимость не подтверждается, так как вход числовой.",
    "Переполнение буфера невозможно, так как длина адреса фиксирована.",
    "Это не проблема, поэтому менять ничего не нужно.",
    "Это нормально для учебного кода, поэтому оставить как есть.",
    "Утечки здесь нет, ресурс освобождается сам.",
    "Проверка здесь не нужна.",
    "Вызов безопасен при любом вводе.",
    "No SSRF here because the base URL is constant."
]
TRUTHFUL_WITH_NEGATION_WORDS = [
    "Нет проверки кода ответа, это риск: если сервер вернёт 404, тело ошибки будет сохранено как данные.",
    "Отсутствует проверка длины буфера, что создаёт уязвимость переполнения.",
    "Утечка памяти, если нет вызова free при ошибке.",
    "Нет контроля переполнения буфера, поэтому длинная строка перезапишет стек.",
    "Нет защиты от утечки: если malloc вернёт NULL, поток не закрывается.",
    "Замените sprintf на безопасный snprintf, иначе при длинном адресе буфер переполнится.",
    "Риск утечки: отсутствует pclose на пути ошибки, поэтому дескриптор останется открытым.",
    "Проблема в том, что нет проверки ввода, и при буквах значение останется мусором.",
    "Функция не является потокобезопасной, что приводит к ошибке при вызове из двух потоков.",
    "Ошибка чтения не обнаруживается до записи в файл, поэтому пользователь получит мусор."
]


def _load_fixture(name):
    with open(os.path.join(HERE, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _contract_violations(data):
    """Контрольный ответ пишется во временный answer.json, verifier читает его штатным
    путём. Возвращает упавшие fail_to_pass-проверки."""
    failed = []
    original = tv.ANSWER
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "answer.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        tv.ANSWER = path
        try:
            for name in sorted(dir(tv)):
                if not name.startswith("test_") or name in _P2P:
                    continue
                try:
                    getattr(tv, name)()
                except AssertionError as exc:
                    failed.append(f"{name}: {exc}")
                except Exception as exc:  # битый ответ — тоже провал проверки
                    failed.append(f"{name}: {type(exc).__name__}: {exc}")
        finally:
            tv.ANSWER = original
    return failed


@pytest.mark.parametrize("name", POSITIVE)
def test_e2e_correct_review_gets_reward_1(name):
    failed = _contract_violations(_load_fixture(name))
    assert not failed, failed


@pytest.mark.parametrize("name", NEGATIVE)
def test_e2e_wrong_review_gets_reward_0(name):
    assert _contract_violations(_load_fixture(name)), f"{name} прошёл все проверки"


def test_denial_is_recognised_within_one_phrase():
    for text in SOFT_AND_NAMED_DENIALS:
        assert tv._is_denial(text), f"отрицание не распознано: {text!r}"


def test_truthful_statements_with_negation_words_are_not_denial():
    for text in TRUTHFUL_WITH_NEGATION_WORDS:
        assert not tv._is_denial(text), f"правда принята за отрицание: {text!r}"


def test_common_connectives_are_causal():
    for text in ("Буфер переполняется, потому что длина не ограничена.",
                 "Данные теряются, так как результат записи не проверяется.",
                 "Процесс падает, поскольку исключение не перехватывается."):
        assert tv._has_causal_link(text, "error_handling"), text


def test_bare_mozhet_is_not_a_causal_marker():
    assert not tv._has_causal_link("Это может привести к ошибке в работе.", "error_handling")


def test_legit_not_applicable_about_dispose_is_allowed():
    record = {"element": "FetchUserData", "category": "resource_leak", "status": "not_applicable",
              "finding": "Утечка HttpClient при исключении",
              "detail": "Объявление using вызывает Dispose при любом выходе, включая исключение."}
    assert tv._denied_real_defect(record) is None


def test_valid_elements_actually_present_in_diff():
    with open(_REPO_DIFF, "r", encoding="utf-8") as f:
        diff = f.read()
    missing = [e for e in tv._SCHEMA["valid_elements"] if e not in diff]
    assert not missing, f"valid_elements содержит элементы, которых нет в diff: {missing}"


def test_element_types_cover_all_valid_elements():
    missing = [e for e in tv._SCHEMA["valid_elements"] if e.lower() not in tv.ELEMENT_TYPES]
    assert not missing, f"Для элементов не задан тип: {missing}"


def test_catalog_elements_are_valid():
    groups = ([e for x in tv.TRUE_FINDINGS for e in x["elements"]]
              + [e for x in tv.FALSE_CLAIMS for e in x["elements"]]
              + [e for x in tv.FALSE_CHANGE_CLAIMS for e in x["elements"]])
    bad = [e for e in groups if e.lower() not in tv.VALID_ELEMENTS]
    assert not bad, f"каталог ссылается на элементы вне valid_elements: {bad}"


def test_catalog_categories_are_valid():
    cats = [c for x in tv.TRUE_FINDINGS + tv.FALSE_CLAIMS for c in x["categories"]]
    bad = [c for c in cats if c not in tv.VALID_CATEGORIES]
    assert not bad, f"каталог ссылается на недопустимые категории: {bad}"
