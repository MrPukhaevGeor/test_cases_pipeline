"""
Верификатор кейса b2c_case_04_47.
Агент пишет answer.json со структурированным анализом git diff (C#).

Схема, допустимые элементы/категории/типы/статусы, соответствие элемента и типа,
пороги объёма, маркеры причинности и отрицания, обязательные и альтернативные
findings загружаются ЕДИНОЖДЫ из неизменяемой фикстуры
/tests/fixtures/answer_schema.json (DRY — единственный источник правды, никаких
дублирующих констант в Python).

Контракт после раундов ревью:

1. Наличие проблемы фиксируется ОТДЕЛЬНЫМ СТРУКТУРИРОВАННЫМ ПОЛЕМ `status`
   (confirmed | not_applicable), а не выводится из текста. К контракту
   засчитываются только записи со `status = confirmed`, текст которых
   действительно утверждает наличие дефекта.

2. Обязательными являются только те findings, которые ОДНОЗНАЧНО следуют из кода
   diff: отсутствие проверки статуса HTTP-ответа в FetchUserData и необработанное
   исключение int.Parse в Main.

   Убраны из обязательных (см. notes_on_dropped_findings в фикстуре):
     - SSRF: ApiBaseUrl фиксирован, userId имеет тип int;
     - «using не освобождает HttpClient при исключении»: технически неверно —
       объявление using освобождает ресурс через finally при любом выходе;
     - готовый Path Traversal: call site строит имя из userId (int).

3. Семантически неверный разбор больше не проходит:
     - поле file обязано называть реально анализируемый файл (csharp.cs);
     - тип элемента сверяется с тем, чем элемент является в коде (метод нельзя
       объявить variable, пространство имён — function);
     - запись со `status = confirmed`, текст которой отрицает дефект, отклоняется;
     - субъективные оценки («код плохого качества», «написано наспех») не
       принимаются: контракт требует технических фактов;
     - перечисление терминов без причинно-следственного объяснения контракт не
       закрывает;
     - в записях запрещены посторонние ключи;
     - совпадения расходуются один к одному: одна запись закрывает не более одной
       спецификации.

4. Правила полноты и дедупликации не скрытые: пороги, допустимые ключи, правило
   уникальности и допустимая привязка причины перечислены в видимом агенту
   system_prompt.txt, а test_visible_contract_matches_fixture проверяет, что
   видимый контракт и исполняемые проверки описывают одно и то же. Дедупликация
   ослаблена до тройки (element, category, finding): две содержательно разные
   проблемы одного метода в одной категории — законный ответ.

5. Технически корректные АЛЬТЕРНАТИВНЫЕ рецензии получают reward=1: помимо двух
   обязательных findings достаточно закрыть минимум один пункт из пула
   alternative_findings.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "3d9dc033d339ac54d1015f37af9a1ed3d03f3df7016b79ab738fc352d95eeeba"
PROMPT_SHA256 = "43f022e8bc4c61cf84c5a24a11b133f932a6ef4078bd98cb1b58c4f776246b98"
SCHEMA_SHA256 = "412bae1c11984d13963fd310bd474e024cbdd76002354d3f57ad9f9ff53f8920"

# Явный деньлист типовых заглушек/филлера — ловит самые дешёвые попытки
# сгенерировать формально проходящий, но бессодержательный текст. Это
# эвристика, а не полноценная проверка связности: не гарантирует смысл,
# но закрывает самый дешёвый обход. Основная защита от «keyword-soup» —
# отсутствие спойлерных формулировок в diff.txt плюс AND-группы keywords
# и обязательная причинно-следственная связка.
_FILLER_DENYLIST = (
    "лорем", "ипсум", "lorem", "ipsum", "asdf", "qwerty",
    "todo", "n/a", "placeholder", "тест тест", "xxx", "ффф", "ггг", "ддд",
)


def _norm(s):
    return (s or "").strip().lower()


def _looks_like_filler(text):
    t = _norm(text)
    if any(bad in t for bad in _FILLER_DENYLIST):
        return True
    words = re.findall(r"\w+", t)
    if not words:
        return True
    # Repetition-ratio check имеет смысл только на достаточно длинном
    # тексте (detail, description) — на коротких заголовках (finding,
    # 2-4 слова) он статистически всегда даёт высокое отношение и ложно
    # бракует легитимные короткие названия.
    if len(words) < 6:
        return False
    from collections import Counter
    counts = Counter(words)
    most_common_ratio = counts.most_common(1)[0][1] / len(words)
    return most_common_ratio > 0.4


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
ANALYZED_FILE = _SCHEMA["analyzed_file"]
ANALYZED_FILE_PATH = _SCHEMA["analyzed_file_path"]
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
VALID_STATUSES = set(_SCHEMA["valid_statuses"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]
ALTERNATIVE_FINDINGS = _SCHEMA["alternative_findings"]
ALL_SPECS = {s["id"]: s for s in REQUIRED_FINDINGS + ALTERNATIVE_FINDINGS}
ELEMENT_TYPES = {k.lower(): {t.lower() for t in v} for k, v in _SCHEMA["element_types"].items()}
ALLOWED_CHANGE_KEYS = set(_SCHEMA["allowed_change_keys"])
ALLOWED_FINDING_KEYS = set(_SCHEMA["allowed_finding_keys"])
CAUSAL_MARKERS = tuple(_SCHEMA["causal_markers"])
MIN_CHANGES = _SCHEMA["min_changes"]
MIN_CONFIRMED_FINDINGS = _SCHEMA["min_confirmed_findings"]
MIN_ALTERNATIVE_FINDINGS = _SCHEMA["min_alternative_findings"]

# Английские связки проверяются по границам слова: подстрочное совпадение дало бы
# ложные срабатывания («if» внутри «notification»).
_EN_CAUSAL_RE = re.compile(
    r"(?<![a-z])(?:" + "|".join(re.escape(m) for m in _SCHEMA["causal_markers_en"]) + r")(?![a-z])"
)
_DENIAL_RES = tuple(re.compile(p) for p in _SCHEMA["denial_patterns"])
_SUBJECTIVE_RES = tuple(re.compile(p) for p in _SCHEMA["subjective_patterns"])


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _finding_text(f):
    return _norm(f.get("finding", "") + " " + f.get("detail", ""))


def _is_confirmed(f):
    return _norm(f.get("status", "")) == "confirmed"


def _is_denial(text):
    """Текст утверждает ОТСУТСТВИЕ дефекта («уязвимость отсутствует», «проверка
    не требуется», «вызов безопасен», «не подтверждается»).

    Отрицание ловится шаблонами, а не одиночными словами: «небезопасный»,
    «некорректный» содержат подстроки «безопасн»/«корректн» и отрицанием дефекта
    не являются. Формулировка «проверка статуса отсутствует» тоже не является
    отрицанием — отрицается проверка, а не дефект, поэтому шаблоны привязаны к
    словам «дефект/проблема/уязвимость/утечка/риск», а не к «проверке»."""
    return any(rx.search(_norm(text)) for rx in _DENIAL_RES)


def _is_subjective(text):
    """Субъективная оценка качества вместо технического факта."""
    return any(rx.search(_norm(text)) for rx in _SUBJECTIVE_RES)


def _has_causal_link(text, category):
    """Объяснение содержит причинно-следственную связку: при каком условии дефект
    срабатывает и к чему приводит.

    Для code_quality не требуется: структурные замечания (публичное изменяемое
    поле конфигурации и т.п.) по своей природе не имеют сценария срабатывания.

    Принимается и русская, и английская связка — язык связки скрытым требованием
    не является. Одиночное «может» маркером НЕ считается: общая фраза «может
    привести к ошибке» причинной связкой не является."""
    if category == "code_quality":
        return True
    t = _norm(text)
    if any(m in t for m in CAUSAL_MARKERS):
        return True
    return bool(_EN_CAUSAL_RE.search(t))


def _spec_elements(spec):
    """Допустимая привязка причины: метод, в котором дефект находится, ИЛИ
    конкретный вызов/переменная этого места. Обе формы правдивы."""
    return {e.lower() for e in spec.get("accepted_elements", [spec["element"]])}


def _record_matches_spec(record, spec):
    """Запись закрывает спецификацию, если она подтверждена (status=confirmed),
    привязана к допустимому элементу и категории, её текст содержит ВСЕ ключевые
    слова хотя бы одной группы (AND внутри группы, OR между группами), содержит
    причинную связку (кроме code_quality), не отрицает дефект и не является
    субъективной оценкой."""
    if not _is_confirmed(record):
        return False
    if _norm(record.get("element", "")) not in _spec_elements(spec):
        return False
    cat = _norm(record.get("category", ""))
    if cat != _norm(spec["category"]):
        return False
    text = _finding_text(record)
    if not any(all(kw in text for kw in group) for group in spec["keyword_groups"]):
        return False
    if _is_denial(text) or _is_subjective(text):
        return False
    return _has_causal_link(record.get("detail", ""), cat)


def _assignment(data):
    """Сопоставление спецификаций и записей ответа ОДИН К ОДНОМУ: одна запись
    закрывает не более одной спецификации, иначе «сборная» запись закрывала бы
    несколько меток разом.

    Алгоритм Куна: сначала обязательные спецификации, затем альтернативные;
    поиск дополняющих путей уже сопоставленную спецификацию не расцепляет."""
    findings = data["important_findings"]
    owner = {}  # индекс записи -> id спецификации

    def candidates(spec):
        return [i for i, rec in enumerate(findings)
                if isinstance(rec, dict) and _record_matches_spec(rec, spec)]

    def augment(spec, visited):
        for i in candidates(spec):
            if i in visited:
                continue
            visited.add(i)
            held_by = owner.get(i)
            if held_by is None or augment(ALL_SPECS[held_by], visited):
                owner[i] = spec["id"]
                return True
        return False

    for spec in REQUIRED_FINDINGS:
        augment(spec, set())
    matched_alternatives = [spec["id"] for spec in ALTERNATIVE_FINDINGS if augment(spec, set())]
    return {spec_id: idx for idx, spec_id in owner.items()}, matched_alternatives


def _confirmed_findings(data):
    return [f for f in data["important_findings"]
            if isinstance(f, dict) and _is_confirmed(f)]


def _spec_by_id(specs, spec_id):
    for s in specs:
        if s["id"] == spec_id:
            return s
    raise KeyError(spec_id)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


def test_visible_contract_matches_fixture():
    """PASS_TO_PASS: видимое агенту задание и исполняемые проверки описывают одно
    и то же — допустимые элементы, категории, типы, статусы, пороги объёма и
    правило уникальности перечислены в system_prompt.txt. Скрытых правил нет.

    Файл читается только после сверки sha256, поэтому подменить его нельзя."""
    path = os.path.join(APP, "system_prompt.txt")
    assert os.path.isfile(path), "system_prompt.txt отсутствует в /app"
    assert _sha256(path) == PROMPT_SHA256, "system_prompt.txt изменён агентом"
    text = open(path, "r", encoding="utf-8").read()
    low = text.lower()
    for element in _SCHEMA["valid_elements"]:
        assert element.lower() in low, f"элемент '{element}' не перечислен в видимом контракте"
    for category in VALID_CATEGORIES:
        assert category in low, f"категория '{category}' не перечислена в видимом контракте"
    for type_name in VALID_TYPES:
        assert type_name in low, f"тип '{type_name}' не перечислен в видимом контракте"
    for status in VALID_STATUSES:
        assert status in low, f"статус '{status}' не перечислен в видимом контракте"
    assert str(MIN_CHANGES) in text, "порог changes не указан в видимом контракте"
    assert str(MIN_CONFIRMED_FINDINGS) in text, "порог confirmed findings не указан в видимом контракте"
    assert ANALYZED_FILE in text, "имя анализируемого файла не указано в видимом контракте"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json — объект с полями file, changes, important_findings."""
    data = _load()
    assert isinstance(data, dict), "answer.json должен быть объектом, а не списком/строкой"
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"
    assert all(isinstance(c, dict) for c in data["changes"]), "элементы changes должны быть объектами"
    assert all(isinstance(f, dict) for f in data["important_findings"]), \
        "элементы important_findings должны быть объектами"


def test_file_field_names_analyzed_file():
    """FAIL_TO_PASS: поле file называет реально анализируемый файл из diff.
    Разбор, указывающий на другой файл, контракт не выполняет."""
    data = _load()
    value = _norm(data.get("file", "")).replace("\\", "/")
    name = _norm(ANALYZED_FILE)
    full = _norm(ANALYZED_FILE_PATH)
    ok = value in (name, full) or value.endswith("/" + name)
    assert ok, (
        f"Поле file называет '{data.get('file')}', а анализируется '{ANALYZED_FILE}' "
        f"(допустим и полный путь '{ANALYZED_FILE_PATH}')"
    )


def test_records_have_no_foreign_keys():
    """FAIL_TO_PASS: в записях changes и important_findings нет посторонних ключей —
    набор полей задан схемой и перечислен в видимом контракте."""
    data = _load()
    for c in data["changes"]:
        extra = set(c) - ALLOWED_CHANGE_KEYS
        assert not extra, f"В записи changes для '{c.get('element')}' посторонние ключи: {sorted(extra)}"
    for f in data["important_findings"]:
        extra = set(f) - ALLOWED_FINDING_KEYS
        assert not extra, (
            f"В записи important_findings для '{f.get('element')}' посторонние ключи: {sorted(extra)}"
        )


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: объём changes не ниже порога из фикстуры (порог продублирован
    в instruction.md и system_prompt.txt — скрытых порогов в кейсе нет)."""
    data = _load()
    assert len(data["changes"]) >= MIN_CHANGES, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= {MIN_CHANGES}"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (FetchUserData,
    SaveToFile, ApiBaseUrl, Main)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"]
               if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_type_matches_element():
    """FAIL_TO_PASS: заявленный type соответствует тому, чем элемент является в
    коде: метод нельзя объявить variable, пространство имён — function.
    Соответствие задано в фикстуре (element_types) и опубликовано в видимом
    контракте как правило «тип должен соответствовать элементу»."""
    data = _load()
    wrong = []
    for c in data["changes"]:
        el = _norm(c.get("element", ""))
        t = _norm(c.get("type", ""))
        allowed = ELEMENT_TYPES.get(el)
        if allowed and t not in allowed:
            wrong.append(f"{c.get('element')}: type={c.get('type')}, допустимо {sorted(allowed)}")
    assert not wrong, "Тип элемента не соответствует коду: " + "; ".join(wrong)


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


def test_changes_descriptions_not_filler():
    """FAIL_TO_PASS: description в changes не похож на заглушку/lorem-ipsum и не
    является субъективной оценкой качества вместо технического факта."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert not _looks_like_filler(desc), f"description для '{el}' похож на заглушку/филлер"
        assert not _is_subjective(desc), (
            f"description для '{el}' — субъективная оценка качества, а не технический факт"
        )


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_status_field_valid():
    """FAIL_TO_PASS: у каждого finding есть обязательное структурированное поле
    status с допустимым значением. Именно это поле, а не текст, фиксирует факт
    наличия проблемы."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        assert "status" in f, f"У finding для '{el}' отсутствует обязательное поле status"
        st = _norm(f.get("status", ""))
        assert st in VALID_STATUSES, \
            f"Недопустимый status '{f.get('status')}' для '{el}' (допустимо: {sorted(VALID_STATUSES)})"


def test_confirmed_findings_minimum_count():
    """FAIL_TO_PASS: подтверждённых findings не меньше порога из фикстуры.
    Записи со status=not_applicable в этот счётчик не входят."""
    data = _load()
    confirmed = _confirmed_findings(data)
    assert len(confirmed) >= MIN_CONFIRMED_FINDINGS, \
        (f"findings со status=confirmed: {len(confirmed)}, "
         f"нужно >= {MIN_CONFIRMED_FINDINGS}")


def test_confirmed_findings_assert_presence():
    """FAIL_TO_PASS: текст записи со status=confirmed утверждает наличие дефекта,
    а не его отсутствие. Ответы вида «уязвимость отсутствует» / «проверка не
    требуется», помеченные как confirmed, отклоняются: для отсутствующей проблемы
    есть отдельное значение status=not_applicable."""
    data = _load()
    for f in _confirmed_findings(data):
        text = _finding_text(f)
        assert not _is_denial(text), (
            f"finding для '{f.get('element')}' помечен status=confirmed, но текст "
            f"отрицает наличие проблемы. Для отсутствующей проблемы используйте "
            f"status=not_applicable"
        )


def test_findings_are_technical_not_subjective():
    """FAIL_TO_PASS: замечания сформулированы как технические факты, а не как
    оценки качества кода («код плохого качества», «написано наспех»)."""
    data = _load()
    for f in data["important_findings"]:
        assert not _is_subjective(_finding_text(f)), (
            f"finding для '{f.get('element')}' — субъективная оценка качества, "
            f"а не технический факт"
        )


def test_confirmed_findings_explain_cause():
    """FAIL_TO_PASS: подтверждённое замечание объясняет механику дефекта — при
    каком условии он проявляется и к чему приводит. Перечисление терминов без
    причинно-следственной связки замечанием не является.

    Для code_quality связка не требуется: структурное замечание сценария
    срабатывания не имеет."""
    data = _load()
    for f in _confirmed_findings(data):
        cat = _norm(f.get("category", ""))
        assert _has_causal_link(f.get("detail", ""), cat), (
            f"detail записи для '{f.get('element')}' не содержит причинно-следственного "
            f"объяснения (при каком условии дефект проявляется и к чему приводит)"
        )


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding, не филлер/заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"
        assert not _looks_like_filler(detail), f"detail для '{el}' похож на заглушку/филлер"


def test_findings_finding_field_present():
    """FAIL_TO_PASS: поле finding в каждом important_finding непустое и
    содержательное (не заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        finding = (f.get("finding") or "").strip()
        assert len(finding) >= 8, f"finding для '{el}' пустой или слишком короткий"
        assert not _looks_like_filler(finding), f"finding для '{el}' похож на заглушку/филлер"


def test_findings_no_duplicate_records():
    """FAIL_TO_PASS: нет дублирующих находок (element, category, finding).

    Уникальность проверяется по тройке, а не по паре: две содержательно разные
    проблемы одного метода в одной категории — законный разбор, и правило в
    таком виде опубликовано в видимом контракте."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")), _norm(f.get("finding", "")))
        assert key not in seen, f"Дублирующая находка (element, category, finding): {key}"
        seen.add(key)


def test_confirmed_findings_have_distinct_explanations():
    """FAIL_TO_PASS: одно и то же generic-объяснение не может закрывать несколько
    разных findings — detail подтверждённых записей должны различаться."""
    data = _load()
    seen = {}
    for f in _confirmed_findings(data):
        key = _norm(f.get("detail", ""))
        assert key not in seen, (
            f"detail записи для '{f.get('element')}' дословно повторяет detail "
            f"записи для '{seen[key]}' — generic-объяснение скопировано между findings"
        )
        seen[key] = f.get("element")


# ── fail_to_pass: обязательные findings по контракту (данные из fixture) ──────

def test_finding_no_status_check_present():
    """FAIL_TO_PASS: тело ответа читается без проверки статуса HTTP-ответа.
    Привязка — FetchUserData либо конкретный вызов (GetAsync, ReadAsStringAsync,
    response)."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "no_status_check")
    assert "no_status_check" in _assignment(data)[0], (
        f"Нет отдельной подтверждённой записи: {'/'.join(spec['accepted_elements'])} / "
        f"{spec['category']} — отсутствие проверки статуса HTTP-ответа перед чтением тела"
    )


def test_finding_int_parse_unhandled_present():
    """FAIL_TO_PASS: необработанное исключение int.Parse на нечисловом вводе.
    Привязка — Main либо конкретный вызов (int.Parse, Console.ReadLine, input)."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "int_parse_unhandled")
    assert "int_parse_unhandled" in _assignment(data)[0], (
        f"Нет отдельной подтверждённой записи: {'/'.join(spec['accepted_elements'])} / "
        f"{spec['category']} — необработанное исключение при преобразовании ввода в число"
    )


def test_at_least_one_alternative_finding_present():
    """FAIL_TO_PASS: помимо двух обязательных findings ответ закрывает минимум
    MIN_ALTERNATIVE_FINDINGS пунктов из пула технически корректных альтернатив
    ОТДЕЛЬНЫМИ записями. Пул задан в фикстуре (alternative_findings) — это то,
    что позволяет правдоподобной альтернативной рецензии получить reward=1,
    не угадывая единственную «правильную» формулировку."""
    data = _load()
    _, matched = _assignment(data)
    assert len(matched) >= MIN_ALTERNATIVE_FINDINGS, (
        f"Закрыто альтернативных findings отдельными записями: {len(matched)} ({matched}), "
        f"нужно >= {MIN_ALTERNATIVE_FINDINGS}. Допустимые варианты: "
        f"{[s['id'] for s in ALTERNATIVE_FINDINGS]}"
    )
