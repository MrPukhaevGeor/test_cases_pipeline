"""
Верификатор кейса b2c_case_04_47.
Агент пишет answer.json со структурированным анализом git diff (C#).
Схема, допустимые элементы/категории/типы и обязательные findings загружаются
ЕДИНОЖДЫ из неизменяемой фикстуры /tests/fixtures/answer_schema.json (DRY —
единственный источник правды, никаких дублирующих констант в Python).
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "238a2ec575b1eab19273e4dcc2abf706d3fc4d8f446ba0cca69a965d70ca9771"
PROMPT_SHA256 = "20420e16ed6d4aa26da1136b333ed5eb41406866505bfa778fc08c78f754aef3"
SCHEMA_SHA256 = "102cc94b98ef69f0bdb9c9397bbbfe30c6b6288f504308ad7d197f7d57f6853d"


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _norm(s):
    return (s or "").strip().lower()


def _match_required(data, req):
    """Проверить что answer.json содержит finding, соответствующий требованию req
    из fixture: (element, category) совпадают, И текст (finding+detail) содержит
    ВСЕ ключевые слова хотя бы одной из групп keyword_groups (AND внутри группы,
    OR между группами). Это исключает ложные срабатывания на одиночных
    общеупотребительных словах вроде 'using' или 'путь', встреченных не по теме."""
    el = _norm(req["element"])
    cat = req["category"]
    groups = req["keyword_groups"]
    for f in data["important_findings"]:
        if _norm(f.get("element", "")) == el and _norm(f.get("category", "")) == cat:
            text = _norm(f.get("detail", "") + " " + f.get("finding", ""))
            if any(all(kw in text for kw in group) for group in groups):
                return f
    return None


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_cs():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла (C#)."""
    data = _load()
    fv = _norm(data.get("file", ""))
    assert "cs" in fv or "csharp" in fv, \
        f"Поле file не содержит имя C#-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: в changes минимум 4 элемента."""
    data = _load()
    assert len(data["changes"]) >= 4, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= 4"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (FetchUserData,
    SaveToFile, ApiBaseUrl, Main)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"] if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: в important_findings минимум 5 findings."""
    data = _load()
    assert len(data["important_findings"]) >= 5, \
        f"important_findings содержит {len(data['important_findings'])} элементов, нужно >= 5"


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих пар (element, category) в important_findings."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")))
        assert key not in seen, f"Дублирующая пара (element, category): {key}"
        seen.add(key)


# ── fail_to_pass: обязательные findings по контракту (данные из fixture) ──────

def test_finding_ssrf_present():
    """FAIL_TO_PASS: finding security/SSRF привязан к FetchUserData."""
    data = _load()
    req = REQUIRED_FINDINGS[0]
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / SSRF"


def test_finding_httpclient_leak_present():
    """FAIL_TO_PASS: finding resource_leak про HttpClient привязан к FetchUserData."""
    data = _load()
    req = REQUIRED_FINDINGS[1]
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / утечка HttpClient"


def test_finding_no_status_check_present():
    """FAIL_TO_PASS: finding error_handling про отсутствие проверки статуса ответа
    привязан к FetchUserData."""
    data = _load()
    req = REQUIRED_FINDINGS[2]
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / отсутствие проверки статуса"


def test_finding_path_traversal_present():
    """FAIL_TO_PASS: finding security/Path Traversal привязан к SaveToFile."""
    data = _load()
    req = REQUIRED_FINDINGS[3]
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / Path Traversal"


def test_finding_int_parse_present():
    """FAIL_TO_PASS: finding error_handling про необработанное исключение int.Parse
    привязан к Main."""
    data = _load()
    req = REQUIRED_FINDINGS[4]
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / int.Parse исключение"
