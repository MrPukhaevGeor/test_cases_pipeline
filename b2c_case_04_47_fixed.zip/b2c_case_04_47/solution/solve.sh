#!/bin/sh
cat > /app/answer.json << 'JSON'
{
  "file": "csharp.cs",
  "changes": [
    {
      "element": "ApiBaseUrl",
      "type": "variable",
      "description": "Определено публичное статическое поле типа string, хранящее базовый URL внешнего API. Используется в FetchUserData для формирования адреса запроса."
    },
    {
      "element": "FetchUserData",
      "type": "function",
      "description": "Асинхронный метод принимает userId типа int, формирует URL через интерполяцию строки, создаёт HttpClient и выполняет GetAsync, возвращает тело ответа как строку через ReadAsStringAsync."
    },
    {
      "element": "SaveToFile",
      "type": "function",
      "description": "Метод принимает data и filename типа string, записывает данные в файл через File.WriteAllText. Имя файла передаётся напрямую без валидации содержимого."
    },
    {
      "element": "Main",
      "type": "function",
      "description": "Асинхронная точка входа программы: считывает пользовательский ввод через Console.ReadLine, преобразует строку в int через int.Parse, последовательно вызывает FetchUserData и SaveToFile."
    },
    {
      "element": "HttpClient",
      "type": "statement",
      "description": "Экземпляр HttpClient создаётся внутри блока using на каждый вызов метода вместо переиспользования одного общего экземпляра для всего приложения."
    }
  ],
  "important_findings": [
    {
      "element": "FetchUserData",
      "category": "security",
      "finding": "SSRF (Server-Side Request Forgery)",
      "detail": "Значение userId подставляется в URL запроса напрямую через интерполяцию строки без валидации. Если базовый адрес или параметр могут быть изменены внешним образом, возможна отправка запросов на произвольные внутренние адреса сети."
    },
    {
      "element": "FetchUserData",
      "category": "resource_leak",
      "finding": "Утечка HttpClient при исключении внутри using",
      "detail": "Объект HttpClient создан внутри блока using, но если внутри метода возникнет необработанное исключение до завершения using, объект может не освободить сетевые ресурсы корректно, а многократное создание HttpClient на каждый вызов истощает пул сокетов."
    },
    {
      "element": "FetchUserData",
      "category": "error_handling",
      "finding": "Отсутствие проверки статуса HTTP-ответа",
      "detail": "Перед чтением тела ответа через ReadAsStringAsync не проверяется response.IsSuccessStatusCode. При ошибочном статусе ответа тело всё равно читается и возвращается вызывающему коду как будто это успешный результат."
    },
    {
      "element": "SaveToFile",
      "category": "security",
      "finding": "Path Traversal",
      "detail": "Имя файла формируется через интерполяцию строки из пользовательского ввода userId без санитизации. Передача значения, содержащего последовательности вида '../', позволяет записать файл в произвольное место файловой системы."
    },
    {
      "element": "Main",
      "category": "error_handling",
      "finding": "Необработанное исключение при вызове int.Parse",
      "detail": "Метод int.Parse выбрасывает FormatException при некорректном вводе, но исключение нигде не перехватывается. Рекомендуется использовать int.TryParse для безопасного преобразования без риска аварийного завершения программы."
    }
  ]
}
JSON
