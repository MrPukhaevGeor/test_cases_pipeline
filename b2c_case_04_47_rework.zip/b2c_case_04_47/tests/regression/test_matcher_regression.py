"""
Regression-тесты самого verifier'а кейса b2c_case_04_47 (не часть reward-контракта агента).

Проверяют matcher на фиксированных контрольных ответах, а не на живом ответе агента:

  1. negative_negation.json — ответ, где element/category/ключевые слова верные и
     status=confirmed, но текст утверждает ОТСУТСТВИЕ проблемы («SSRF отсутствует»,
     «Path Traversal отсутствует», «проблема не подтверждается»). Это ровно тот
     класс ответа, который в прошлом раунде проходил все проверки и получал
     reward=1. Matcher обязан не засчитать обязательные findings.

  2. negative_generic_keywords.json — формальное упоминание проблемы без механики
     дефекта («может привести к ошибке»). Matcher обязан не засчитать обязательные
     findings.

  3. positive_alt_savetofile.json / positive_alt_endpoint.json — технически
     корректные альтернативные рецензии, сформулированные другими словами и
     закрывающие РАЗНЫЕ пункты пула альтернатив. Обе обязаны закрывать контракт
     полностью, иначе verifier даёт ложноотрицательный результат.

Дополнительно проверяется, что список valid_elements фикстуры не разъезжается с
фактическим diff.txt.

Запускать вручную при любом изменении _match_spec / keyword_groups /
negation_patterns, до сдачи кейса. Не входит в tests/test.sh и на reward не влияет —
это проверка качества самого verifier'а, а не агента.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
sys.path.insert(0, TESTS_DIR)

import test_verifier as tv  # noqa: E402

# diff.txt лежит в пакете рядом с tests/, а в рантайме (tests примонтированы
# как /tests) — в /app. Проверяем обе раскладки, иначе тест падает с
# FileNotFoundError при запуске из собранного окружения.
_DIFF_CANDIDATES = (
    os.path.join(os.path.dirname(TESTS_DIR), "environment", "repo", "diff.txt"),
    os.path.join(tv.APP, "diff.txt"),
)
_REPO_DIFF = next(
    (p for p in _DIFF_CANDIDATES if os.path.isfile(p)), _DIFF_CANDIDATES[0]
)


def _load_fixture(name):
    with open(os.path.join(HERE, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _unmatched(data, specs):
    return [s["id"] for s in specs if tv._match_spec(data, s) is None]


def _matched(data, specs):
    return [s["id"] for s in specs if tv._match_spec(data, s) is not None]


# ── 1. отрицание не должно закрывать контракт ────────────────────────────────

def test_negation_answer_does_not_satisfy_required_findings():
    data = _load_fixture("negative_negation.json")
    unmatched = _unmatched(data, tv.REQUIRED_FINDINGS)
    assert len(unmatched) == len(tv.REQUIRED_FINDINGS), (
        "Matcher засчитал ответ-отрицание как подтверждение проблемы: "
        f"закрытыми оказались {_matched(data, tv.REQUIRED_FINDINGS)}"
    )


def test_negation_answer_does_not_satisfy_alternatives():
    data = _load_fixture("negative_negation.json")
    assert not _matched(data, tv.ALTERNATIVE_FINDINGS), (
        "Matcher засчитал отрицание как альтернативный finding: "
        f"{_matched(data, tv.ALTERNATIVE_FINDINGS)}"
    )


def test_negation_detected_by_presence_check():
    """Каждая запись контрольного ответа помечена confirmed, но текстом отрицает
    проблему — проверка наличия обязана это увидеть."""
    data = _load_fixture("negative_negation.json")
    offenders = [
        f["element"] for f in data["important_findings"]
        if tv._is_confirmed(f) and not tv._asserts_presence(tv._finding_text(f))
    ]
    assert len(offenders) == len(data["important_findings"]), (
        "Не все отрицающие записи распознаны как отрицание; распознаны: "
        f"{offenders}"
    )


# ── 2. формальное упоминание без механики не должно закрывать контракт ───────

def test_generic_keywords_answer_does_not_satisfy_required_findings():
    data = _load_fixture("negative_generic_keywords.json")
    unmatched = _unmatched(data, tv.REQUIRED_FINDINGS)
    assert len(unmatched) == len(tv.REQUIRED_FINDINGS), (
        "Matcher засчитал generic-объяснение без механики дефекта: "
        f"закрытыми оказались {_matched(data, tv.REQUIRED_FINDINGS)}"
    )


def test_generic_keywords_answer_does_not_satisfy_alternatives():
    data = _load_fixture("negative_generic_keywords.json")
    assert not _matched(data, tv.ALTERNATIVE_FINDINGS), (
        "Matcher засчитал generic-объяснение как альтернативный finding: "
        f"{_matched(data, tv.ALTERNATIVE_FINDINGS)}"
    )


# ── 3. корректные альтернативные рецензии обязаны проходить ──────────────────

def test_alternative_reviews_satisfy_full_contract():
    for name in ("positive_alt_savetofile.json", "positive_alt_endpoint.json"):
        data = _load_fixture(name)

        unmatched = _unmatched(data, tv.REQUIRED_FINDINGS)
        assert not unmatched, (
            f"{name}: verifier не засчитал обязательные findings, "
            f"сформулированные синонимично: {unmatched}"
        )

        matched_alt = _matched(data, tv.ALTERNATIVE_FINDINGS)
        assert len(matched_alt) >= tv.MIN_ALTERNATIVE_FINDINGS, (
            f"{name}: закрыто альтернативных findings {len(matched_alt)} "
            f"({matched_alt}), нужно >= {tv.MIN_ALTERNATIVE_FINDINGS}"
        )

        confirmed = tv._confirmed_findings(data)
        assert len(confirmed) >= tv.MIN_CONFIRMED_FINDINGS, (
            f"{name}: подтверждённых findings {len(confirmed)}, "
            f"нужно >= {tv.MIN_CONFIRMED_FINDINGS}"
        )


def test_alternative_reviews_cover_different_alternatives():
    """Две контрольные рецензии закрывают РАЗНЫЕ пункты пула — иначе пул
    альтернатив фактически не проверен."""
    a = set(_matched(_load_fixture("positive_alt_savetofile.json"), tv.ALTERNATIVE_FINDINGS))
    b = set(_matched(_load_fixture("positive_alt_endpoint.json"), tv.ALTERNATIVE_FINDINGS))
    assert a and b and a != b, (
        f"Контрольные рецензии закрывают один и тот же набор альтернатив: {a} / {b}"
    )


# ── 4. фикстура не разъезжается с diff ───────────────────────────────────────

def test_valid_elements_actually_present_in_diff():
    """Каждый элемент из valid_elements реально встречается в diff.txt —
    список элементов и типов синхронизирован с фактическим кодом."""
    with open(_REPO_DIFF, "r", encoding="utf-8") as f:
        diff = f.read()
    missing = [e for e in tv._SCHEMA["valid_elements"] if e not in diff]
    assert not missing, f"valid_elements содержит элементы, которых нет в diff: {missing}"


def test_required_and_alternative_elements_are_valid():
    """Элементы всех спецификаций входят в valid_elements (нет опечаток)."""
    valid = tv.VALID_ELEMENTS
    bad = [
        s["id"] for s in (tv.REQUIRED_FINDINGS + tv.ALTERNATIVE_FINDINGS)
        if s["element"].lower() not in valid
    ]
    assert not bad, f"Спецификации ссылаются на элементы вне valid_elements: {bad}"
