"""
Верификатор кейса b2c_case_04_47.
Агент пишет answer.json со структурированным анализом git diff (C#).

Схема, допустимые элементы/категории/типы/статусы, пороги объёма, обязательные и
альтернативные findings загружаются ЕДИНОЖДЫ из неизменяемой фикстуры
/tests/fixtures/answer_schema.json (DRY — единственный источник правды, никаких
дублирующих констант в Python).

Контракт после раунда ревью:

1. Наличие проблемы фиксируется ОТДЕЛЬНЫМ СТРУКТУРИРОВАННЫМ ПОЛЕМ `status`
   (confirmed | not_applicable), а не выводится из текста. К контракту
   засчитываются только записи со `status = confirmed`, текст которых
   действительно утверждает наличие дефекта (проверка отрицаний). Это закрывает
   дыру, из-за которой ответы вида «SSRF отсутствует» проходили keyword-matcher.

2. Обязательными являются только те findings, которые ОДНОЗНАЧНО следуют из кода
   diff: отсутствие проверки статуса HTTP-ответа в FetchUserData и необработанное
   исключение int.Parse в Main.

   Убраны из обязательных (см. notes_on_dropped_findings в фикстуре):
     - SSRF: ApiBaseUrl фиксирован, userId имеет тип int — хост/схему пользователь
       не контролирует;
     - «using не освобождает HttpClient при исключении»: технически неверно;
     - готовый Path Traversal: единственный call site строит имя из userId (int).

3. Технически корректные АЛЬТЕРНАТИВНЫЕ рецензии получают reward=1: помимо двух
   обязательных findings достаточно закрыть минимум один пункт из заранее
   определённого пула alternative_findings (утечка сокетов на HttpClient,
   небезопасный sink SaveToFile, изменяемое глобальное ApiBaseUrl как проблема
   качества либо как подмена адреса запроса).

4. Количественные пороги (min_changes / min_confirmed_findings) больше не
   скрытые: они лежат в фикстуре и продублированы в instruction.md и
   system_prompt.txt как часть формата ответа.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "3d9dc033d339ac54d1015f37af9a1ed3d03f3df7016b79ab738fc352d95eeeba"
PROMPT_SHA256 = "1f4fc3d6ec89ee6cae10c41cab5117b44b0fbb6e60fb9334c048e6771c05e09b"
SCHEMA_SHA256 = "60c721863a7f10774fd512b435eadc13e0e7b2cedb7fc09c2fe0429b06c7f0fa"

# Явный деньлист типовых заглушек/филлера — ловит самые дешёвые попытки
# сгенерировать формально проходящий, но бессодержательный текст. Это
# эвристика, а не полноценная проверка связности: не гарантирует смысл,
# но закрывает самый дешёвый обход. Основная защита от «keyword-soup» —
# отсутствие спойлерных формулировок в diff.txt плюс AND-группы keywords.
_FILLER_DENYLIST = (
    "лорем", "ипсум", "lorem", "ipsum", "asdf", "qwerty",
    "todo", "n/a", "placeholder", "тест тест", "xxx", "ффф", "ггг", "ддд",
)


def _norm(s):
    return (s or "").strip().lower()


def _looks_like_filler(text):
    t = _norm(text)
    if any(bad in t for bad in _FILLER_DENYLIST):
        return True
    words = re.findall(r"\w+", t)
    if not words:
        return True
    # Repetition-ratio check имеет смысл только на достаточно длинном
    # тексте (detail, description) — на коротких заголовках (finding,
    # 2-4 слова) он статистически всегда даёт высокое отношение и ложно
    # бракует легитимные короткие названия вроде "Path Traversal".
    if len(words) < 6:
        return False
    from collections import Counter
    counts = Counter(words)
    most_common_ratio = counts.most_common(1)[0][1] / len(words)
    return most_common_ratio > 0.4


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
VALID_STATUSES = set(_SCHEMA["valid_statuses"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]
ALTERNATIVE_FINDINGS = _SCHEMA["alternative_findings"]
NEGATION_PATTERNS = tuple(_SCHEMA["negation_patterns"])
MIN_CHANGES = _SCHEMA["min_changes"]
MIN_CONFIRMED_FINDINGS = _SCHEMA["min_confirmed_findings"]
MIN_ALTERNATIVE_FINDINGS = _SCHEMA["min_alternative_findings"]


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _finding_text(f):
    return _norm(f.get("finding", "") + " " + f.get("detail", ""))


def _is_confirmed(f):
    return _norm(f.get("status", "")) == "confirmed"


def _asserts_presence(text):
    """Текст действительно утверждает наличие дефекта, а не его отсутствие.

    Паттерны подобраны так, чтобы НЕ ловить легитимные формулировки вида
    «проверка статуса отсутствует» (отрицание относится к проверке, то есть
    к утверждению о дефекте), но ловить «уязвимость отсутствует»,
    «SSRF отсутствует», «не подтверждается», «недостижим» и т.п.
    """
    return not any(p in text for p in NEGATION_PATTERNS)


def _confirmed_findings(data):
    return [f for f in data["important_findings"] if _is_confirmed(f)]


def _match_spec(data, spec):
    """Спецификация из фикстуры засчитана, если найдена запись с совпадающими
    element и category, со status=confirmed, чей текст утверждает наличие
    проблемы И содержит ВСЕ ключевые слова хотя бы одной из групп
    keyword_groups (AND внутри группы, OR между группами)."""
    el = _norm(spec["element"])
    cat = spec["category"]
    for f in data["important_findings"]:
        if not _is_confirmed(f):
            continue
        if _norm(f.get("element", "")) != el or _norm(f.get("category", "")) != cat:
            continue
        text = _finding_text(f)
        if not _asserts_presence(text):
            continue
        if any(all(kw in text for kw in group) for group in spec["keyword_groups"]):
            return f
    return None


def _spec_by_id(specs, spec_id):
    for s in specs:
        if s["id"] == spec_id:
            return s
    raise KeyError(spec_id)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_cs():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла (C#)."""
    data = _load()
    fv = _norm(data.get("file", ""))
    assert "cs" in fv or "csharp" in fv, \
        f"Поле file не содержит имя C#-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: объём changes не ниже порога из фикстуры (порог продублирован
    в instruction.md и system_prompt.txt — скрытых порогов в кейсе нет)."""
    data = _load()
    assert len(data["changes"]) >= MIN_CHANGES, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= {MIN_CHANGES}"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (FetchUserData,
    SaveToFile, ApiBaseUrl, Main)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман).
    Список элементов синхронизирован с фактическим diff и включает класс
    CSharpWithErrors, локальные переменные (url, client, response, data, filename,
    input, userId, args) и вызовы (File.WriteAllText, int.Parse и др.)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"]
               if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых
    значений (включая class, добавленный по факту наличия класса в diff)."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


def test_changes_descriptions_not_filler():
    """FAIL_TO_PASS: description в changes не похож на заглушку/lorem-ipsum."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert not _looks_like_filler(desc), f"description для '{el}' похож на заглушку/филлер"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_status_field_valid():
    """FAIL_TO_PASS: у каждого finding есть обязательное структурированное поле
    status с допустимым значением. Именно это поле, а не текст, фиксирует факт
    наличия проблемы."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        assert "status" in f, f"У finding для '{el}' отсутствует обязательное поле status"
        st = _norm(f.get("status", ""))
        assert st in VALID_STATUSES, \
            f"Недопустимый status '{f.get('status')}' для '{el}' (допустимо: {sorted(VALID_STATUSES)})"


def test_confirmed_findings_minimum_count():
    """FAIL_TO_PASS: подтверждённых findings не меньше порога из фикстуры.
    Записи со status=not_applicable в этот счётчик не входят."""
    data = _load()
    confirmed = _confirmed_findings(data)
    assert len(confirmed) >= MIN_CONFIRMED_FINDINGS, \
        (f"findings со status=confirmed: {len(confirmed)}, "
         f"нужно >= {MIN_CONFIRMED_FINDINGS}")


def test_confirmed_findings_assert_presence():
    """FAIL_TO_PASS: текст записи со status=confirmed утверждает наличие дефекта,
    а не его отсутствие. Ответы вида «SSRF отсутствует» / «Path Traversal не
    обнаружен», помеченные как confirmed, отклоняются: для отрицания есть
    отдельное значение status=not_applicable."""
    data = _load()
    for f in _confirmed_findings(data):
        text = _finding_text(f)
        hit = [p for p in NEGATION_PATTERNS if p in text]
        assert not hit, (
            f"finding для '{f.get('element')}' помечен status=confirmed, но текст "
            f"отрицает наличие проблемы (совпадение: {hit}). Для отсутствующей "
            f"проблемы используйте status=not_applicable"
        )


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding, не филлер/заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"
        assert not _looks_like_filler(detail), f"detail для '{el}' похож на заглушку/филлер"


def test_findings_finding_field_present():
    """FAIL_TO_PASS: поле finding в каждом important_finding непустое и
    содержательное (не заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        finding = (f.get("finding") or "").strip()
        assert len(finding) >= 8, f"finding для '{el}' пустой или слишком короткий"
        assert not _looks_like_filler(finding), f"finding для '{el}' похож на заглушку/филлер"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих пар (element, category) в important_findings."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")))
        assert key not in seen, f"Дублирующая пара (element, category): {key}"
        seen.add(key)


def test_confirmed_findings_have_distinct_explanations():
    """FAIL_TO_PASS: одно и то же generic-объяснение не может закрывать несколько
    разных findings — detail подтверждённых записей должны различаться."""
    data = _load()
    seen = {}
    for f in _confirmed_findings(data):
        key = _norm(f.get("detail", ""))
        assert key not in seen, (
            f"detail записи для '{f.get('element')}' дословно повторяет detail "
            f"записи для '{seen[key]}' — generic-объяснение скопировано между findings"
        )
        seen[key] = f.get("element")


# ── fail_to_pass: обязательные findings по контракту (данные из fixture) ──────

def test_finding_no_status_check_present():
    """FAIL_TO_PASS: FetchUserData / error_handling — тело ответа читается без
    проверки статуса HTTP-ответа. Следует непосредственно из diff."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "no_status_check")
    assert _match_spec(data, spec), (
        f"Нет подтверждённого finding: {spec['element']} / {spec['category']} — "
        f"отсутствие проверки статуса HTTP-ответа перед чтением тела"
    )


def test_finding_int_parse_unhandled_present():
    """FAIL_TO_PASS: Main / error_handling — необработанное исключение int.Parse
    на нечисловом вводе. Следует непосредственно из diff."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "int_parse_unhandled")
    assert _match_spec(data, spec), (
        f"Нет подтверждённого finding: {spec['element']} / {spec['category']} — "
        f"необработанное исключение при преобразовании ввода в число"
    )


def test_at_least_one_alternative_finding_present():
    """FAIL_TO_PASS: помимо двух обязательных findings ответ закрывает минимум
    MIN_ALTERNATIVE_FINDINGS пунктов из пула технически корректных альтернатив.
    Пул задан в фикстуре (alternative_findings) — это то, что позволяет
    правдоподобной альтернативной рецензии получить reward=1, не угадывая
    единственную «правильную» формулировку."""
    data = _load()
    matched = [spec["id"] for spec in ALTERNATIVE_FINDINGS if _match_spec(data, spec)]
    assert len(matched) >= MIN_ALTERNATIVE_FINDINGS, (
        f"Закрыто альтернативных findings: {len(matched)} ({matched}), "
        f"нужно >= {MIN_ALTERNATIVE_FINDINGS}. Допустимые варианты: "
        f"{[s['id'] for s in ALTERNATIVE_FINDINGS]}"
    )
