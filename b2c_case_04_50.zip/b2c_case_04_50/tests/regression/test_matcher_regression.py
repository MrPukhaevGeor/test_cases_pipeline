"""
Regression-тесты самого verifier'а кейса b2c_case_04_50 (не часть reward-контракта агента).

Проверяют matcher на фиксированных контрольных ответах, а не на живом ответе агента:

  1. negative_keyword_soup.json — все нужные слова присутствуют, но detail это
     скопированный лейбл без причинно-следственного объяснения. Обязательный
     контракт закрываться не должен.

  2. negative_generic_and_repeated.json — общие объяснения вида «может привести к
     ошибке», часть из которых ещё и дословно повторяется между записями. Ни один
     обязательный или альтернативный finding засчитан быть не должен, а
     повторяющийся detail обязан детектироваться.

  3. positive_synonymous.json — технически корректный ответ другими словами:
     обязан закрывать весь контракт.

  4. positive_leak_paraphrase.json — прицельно на замечание ревью: корректное
     описание утечки ресурса БЕЗ слов pipe, popen, malloc, NULL и «закры».
     Обязан закрывать весь контракт, иначе matcher слишком строг к формулировке.

Плюс регрессы на замечания последнего раунда:
  - отрицание дефекта («проверка не нужна», «утечки нет», «вызов безопасен») не
    закрывает контракт, при этом отрицательные формы («небезопасный»,
    «некорректный») отрицанием не считаются;
  - совпадения расходуются один к одному: «сборная» запись закрывает не больше
    одной спецификации;
  - привязка к месту вызова (fread, scanf, popen) принимается наравне с
    привязкой к охватывающей функции.

Дополнительно проверяется, что фикстура не разъезжается с фактическим diff.txt.

Запускать вручную при любом изменении matcher'а / keyword_groups / causal_markers /
denial_patterns, до сдачи кейса. Не входит в tests/test.sh и на reward не влияет —
это проверка качества самого verifier'а, а не агента.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
sys.path.insert(0, TESTS_DIR)

import test_verifier as tv  # noqa: E402

# diff.txt лежит в пакете рядом с tests/, а в рантайме (tests примонтированы
# как /tests) — в /app. Проверяем обе раскладки, иначе тест падает с
# FileNotFoundError при запуске из собранного окружения.
_DIFF_CANDIDATES = (
    os.path.join(os.path.dirname(TESTS_DIR), "environment", "repo", "diff.txt"),
    os.path.join(tv.APP, "diff.txt"),
)
_REPO_DIFF = next(
    (p for p in _DIFF_CANDIDATES if os.path.isfile(p)), _DIFF_CANDIDATES[0]
)

_FORBIDDEN_IN_PARAPHRASE = ("pipe", "popen", "malloc", "null", "закры")


def _load_fixture(name):
    with open(os.path.join(HERE, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _matched_required(data):
    assigned, _ = tv._assignment(data)
    return [s["id"] for s in tv.REQUIRED_FINDINGS if s["id"] in assigned]


def _matched_alternatives(data):
    _, alternatives = tv._assignment(data)
    return alternatives


# ── 1. копипаст лейбла без объяснения ────────────────────────────────────────

def test_keyword_soup_does_not_satisfy_required_findings():
    data = _load_fixture("negative_keyword_soup.json")
    matched = _matched_required(data)
    assert not matched, (
        f"Matcher засчитал скопированные лейблы без причинного объяснения: {matched}"
    )


def test_keyword_soup_does_not_satisfy_alternatives():
    data = _load_fixture("negative_keyword_soup.json")
    matched = _matched_alternatives(data)
    assert not matched, f"Matcher засчитал копипаст как альтернативный finding: {matched}"


# ── 2. общие и повторяющиеся объяснения ──────────────────────────────────────

def test_generic_explanations_do_not_satisfy_contract():
    data = _load_fixture("negative_generic_and_repeated.json")
    matched = _matched_required(data) + _matched_alternatives(data)
    assert not matched, (
        f"Matcher засчитал общее объяснение вида «может привести к ошибке»: {matched}"
    )


def test_bare_mozhet_is_not_a_causal_marker():
    """Регресс на конкретную дыру: одиночное «может» не должно считаться
    причинно-следственной связкой."""
    assert not tv._has_causal_link(
        "Здесь есть недостаток, который может привести к ошибке в работе.", "security"
    ), "«может привести к ошибке» ошибочно принято за причинную связку"


def test_repeated_detail_is_detectable():
    """В контрольном ответе есть две записи с дословно одинаковым detail —
    проверка уникальности объяснений обязана это увидеть."""
    data = _load_fixture("negative_generic_and_repeated.json")
    details = [tv._norm(f.get("detail", "")) for f in data["important_findings"]]
    assert len(details) != len(set(details)), (
        "Контрольная фикстура потеряла дублирующий detail — сценарий "
        "повторяющегося объяснения больше не проверяется"
    )


# ── 3-4. корректные рецензии обязаны проходить ───────────────────────────────

def test_synonymous_answer_satisfies_full_contract():
    for name in ("positive_synonymous.json", "positive_leak_paraphrase.json"):
        data = _load_fixture(name)

        matched_req = _matched_required(data)
        missing = [s["id"] for s in tv.REQUIRED_FINDINGS if s["id"] not in matched_req]
        assert not missing, (
            f"{name}: verifier не засчитал корректные findings, сформулированные "
            f"синонимично: {missing}. Matcher слишком строг к формулировке."
        )

        matched_alt = _matched_alternatives(data)
        assert len(matched_alt) >= tv.MIN_ALTERNATIVE_FINDINGS, (
            f"{name}: закрыто альтернативных findings {len(matched_alt)} "
            f"({matched_alt}), нужно >= {tv.MIN_ALTERNATIVE_FINDINGS}"
        )

        assert len(tv._substantive_findings(data)) >= tv.MIN_FINDINGS, (
            f"{name}: findings {len(data['important_findings'])}, "
            f"нужно >= {tv.MIN_FINDINGS}"
        )


def test_leak_paraphrase_avoids_reference_keywords():
    """Контрольная парафраза действительно не содержит ни одного слова, к которым
    matcher был привязан раньше — иначе тест ничего не доказывает."""
    data = _load_fixture("positive_leak_paraphrase.json")
    leak = [f for f in data["important_findings"] if f["category"] == "resource_leak"]
    assert leak, "В фикстуре нет записи с категорией resource_leak"
    text = tv._norm(leak[0]["finding"] + " " + leak[0]["detail"])
    hits = [w for w in _FORBIDDEN_IN_PARAPHRASE if w in text]
    assert not hits, (
        f"Парафраза содержит опорные слова {hits} — фикстура не проверяет "
        f"независимость matcher'а от конкретного набора keywords"
    )


# ── 5. отрицание дефекта (замечание F001) ────────────────────────────────────

def test_denial_is_detected():
    """Разбор, который отрицает дефект, распознаётся как отрицание."""
    denials = (
        "Результат fread здесь не имеет значения, поэтому отдельная проверка не нужна.",
        "Поток закрывается штатно, утечки нет ни в одной ветке функции.",
        "Вызов popen безопасен, потому что команда фиксирована.",
        "К этому месту замечаний нет: конфигурация не меняется между стендами.",
    )
    for text in denials:
        assert tv._is_denial(text), f"Отрицание не распознано: {text!r}"


def test_negative_word_forms_are_not_denial():
    """Отрицательные формы описывают дефект, а не его отсутствие: «небезопасный
    приёмник» и «некорректный ввод» отрицанием считаться не должны."""
    affirmations = (
        "Функция остаётся небезопасным приёмником данных, если имя придёт извне.",
        "При некорректном вводе переменная user_id остаётся неинициализированной.",
        "sprintf небезопасен как API: объём записи размером приёмника не ограничен.",
    )
    for text in affirmations:
        assert not tv._is_denial(text), f"Утверждение о дефекте принято за отрицание: {text!r}"


def test_denying_record_does_not_close_contract():
    """Запись с нужными ключевыми словами, но отрицающая дефект, спецификацию не
    закрывает."""
    spec = tv._spec_by_id(tv.REQUIRED_FINDINGS, "pipe_leak_on_malloc_fail")
    record = {
        "element": "fetch_user_data",
        "category": "resource_leak",
        "finding": "Поток pipe закрывается корректно",
        "detail": ("Указатель pipe освобождается вызовом pclose в конце функции, "
                   "поэтому утечки нет: поток не закрывается только в теории."),
    }
    assert not tv._record_matches_spec(record, spec), \
        "Отрицающая запись закрыла обязательный finding"


# ── 6. один к одному (замечание F001) ────────────────────────────────────────

def test_merged_record_closes_only_one_spec():
    """«Сборная» запись, где перечислено сразу два дефекта, закрывает ровно одну
    спецификацию — совпадения расходуются один к одному."""
    merged = {
        "element": "fetch_user_data",
        "category": "error_handling",
        "finding": "Чтение из потока и запуск команды",
        "detail": ("Вызов fread не сохраняет результат чтения, поэтому хвост буфера "
                   "остаётся неинициализированным; кроме того popen отдаёт url "
                   "системной оболочке вместо сетевого клиента."),
    }
    data = {"file": "cpp.c", "changes": [], "important_findings": [merged]}
    assigned, alternatives = tv._assignment(data)
    assert len(assigned) == 1, (
        f"Одна запись закрыла несколько спецификаций: {sorted(assigned)}"
    )
    assert not (("fread_unchecked" in assigned) and alternatives), (
        "Обязательный и альтернативный finding закрыты одной и той же записью"
    )


# ── 7. привязка к месту вызова (замечание F003) ──────────────────────────────

def test_call_site_binding_is_accepted():
    """Привязка проблемы к конкретному вызову принимается наравне с привязкой к
    охватывающей функции."""
    cases = (
        ("fread_unchecked", "fread", "error_handling",
         "Вызов fread не сохраняет количество прочитанных байт, поэтому при коротком "
         "ответе хвост буфера остаётся неинициализированным."),
        ("scanf_unchecked", "scanf", "error_handling",
         "Результат scanf нигде не проверяется, поэтому при нечисловом вводе "
         "переменная user_id остаётся неинициализированной."),
        ("pipe_leak_on_malloc_fail", "pipe", "resource_leak",
         "Если malloc вернёт NULL, поток pipe остаётся открытым: pclose в этой ветке "
         "не вызывается, дочерний процесс продолжает висеть."),
    )
    for spec_id, element, category, detail in cases:
        spec = tv._spec_by_id(tv.REQUIRED_FINDINGS, spec_id)
        record = {"element": element, "category": category,
                  "finding": "Замечание к вызову", "detail": detail}
        assert tv._record_matches_spec(record, spec), (
            f"Привязка к месту вызова '{element}' не принята для {spec_id}"
        )


# ── 8. фикстура не разъезжается с diff и с видимым контрактом ────────────────

def test_valid_elements_actually_present_in_diff():
    with open(_REPO_DIFF, "r", encoding="utf-8") as f:
        diff = f.read()
    missing = [e for e in tv._SCHEMA["valid_elements"] if e not in diff]
    assert not missing, f"valid_elements содержит элементы, которых нет в diff: {missing}"


def test_spec_elements_and_categories_are_valid():
    specs = tv.REQUIRED_FINDINGS + tv.ALTERNATIVE_FINDINGS
    bad_el = [
        s["id"] for s in specs
        if not tv._spec_elements(s) <= tv.VALID_ELEMENTS
    ]
    assert not bad_el, f"Спецификации ссылаются на элементы вне valid_elements: {bad_el}"

    bad_cat = [
        s["id"] for s in specs
        if not tv._spec_categories(s) <= {c.lower() for c in tv.VALID_CATEGORIES}
    ]
    assert not bad_cat, f"Спецификации ссылаются на категории вне valid_categories: {bad_cat}"


NEGATIVE_FIXTURES = ["negative_keyword_soup.json", "negative_generic_and_repeated.json"]
POSITIVE_FIXTURES = ["positive_synonymous.json", "positive_leak_paraphrase.json"]
SOFT_AND_NAMED_DENIALS = [
    "SSRF отсутствует: адрес формируется из константы.",
    "Path Traversal отсутствует, потому что идентификатор имеет тип int.",
    "Уязвимость не подтверждается, так как вход числовой.",
    "Переполнение буфера невозможно, так как длина адреса фиксирована.",
    "Это не проблема, поэтому менять ничего не нужно.",
    "Это нормально для учебного кода, поэтому оставить как есть.",
    "Утечки здесь нет, ресурс освобождается сам.",
    "Проверка здесь не нужна.",
    "Вызов безопасен при любом вводе.",
    "No SSRF here because the base URL is constant."
]
TRUTHFUL_WITH_NEGATION_WORDS = [
    "Нет проверки кода ответа, это риск: если сервер вернёт 404, тело ошибки будет сохранено как данные.",
    "Отсутствует проверка длины буфера, что создаёт уязвимость переполнения.",
    "Утечка памяти, если нет вызова free при ошибке.",
    "Нет контроля переполнения буфера, поэтому длинная строка перезапишет стек.",
    "Нет защиты от утечки: если malloc вернёт NULL, поток не закрывается.",
    "Замените sprintf на безопасный snprintf, иначе при длинном адресе буфер переполнится.",
    "Риск утечки: отсутствует pclose на пути ошибки, поэтому дескриптор останется открытым.",
    "Проблема в том, что нет проверки ввода, и при буквах значение останется мусором.",
    "Функция не является потокобезопасной, что приводит к ошибке при вызове из двух потоков.",
    "Ошибка чтения не обнаруживается до записи в файл, поэтому пользователь получит мусор."
]


# ── Правка 28.09: сквозной прогон всех проверок на контрольных ответах ────────
#
# Контрольный ответ прогоняется через ВСЕ fail_to_pass-проверки verifier'а, как
# будто это answer.json агента. Негативный ответ обязан уронить хотя бы одну,
# позитивный — ни одной. Это end-to-end, а не проверка отдельной функции.

import tempfile as _tempfile  # noqa: E402

_P2P = {"test_inputs_present_and_untouched", "test_fixture_schema_intact",
        "test_visible_contract_matches_fixture"}


def _contract_violations(data):
    """Контрольный ответ пишется во временный answer.json, verifier читает его
    штатным путём — без подмены функций. Возвращает упавшие fail_to_pass-проверки."""
    failed = []
    original = tv.ANSWER
    with _tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "answer.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        tv.ANSWER = path
        try:
            for name in sorted(dir(tv)):
                if not name.startswith("test_") or name in _P2P:
                    continue
                try:
                    getattr(tv, name)()
                except AssertionError as exc:
                    failed.append(f"{name}: {exc}")
                except Exception as exc:  # битый ответ — тоже провал проверки
                    failed.append(f"{name}: {type(exc).__name__}: {exc}")
        finally:
            tv.ANSWER = original
    return failed


def test_e2e_soft_denial_gets_reward_0():
    """Дефект назван, но объявлен неважным («это не проблема, менять ничего не нужно»)."""
    failed = _contract_violations(_load_fixture("negative_soft_denial.json"))
    assert failed, "мягкое отрицание прошло все проверки"


def test_e2e_truthful_negation_words_get_reward_1():
    """Правда со словами «нет», «отсутствует», «риск» рядом со словами-дефектами."""
    failed = _contract_violations(_load_fixture("positive_negation_words.json"))
    assert not failed, failed


def test_e2e_correct_finding_outside_pool_gets_reward_1():
    """Верная дополнительная находка, которой нет в пуле alternative_findings.
    Агент не обязан угадывать внутренний перечень альтернатив."""
    data = _load_fixture("positive_out_of_pool.json")
    _, matched_alt = tv._assignment(data)
    assert not matched_alt, "фикстура должна быть вне пула альтернатив"
    failed = _contract_violations(data)
    assert not failed, failed


def test_e2e_existing_negative_fixtures_get_reward_0():
    for name in NEGATIVE_FIXTURES:
        assert _contract_violations(_load_fixture(name)), f"{name} прошёл все проверки"


def test_e2e_existing_positive_fixtures_get_reward_1():
    for name in POSITIVE_FIXTURES:
        failed = _contract_violations(_load_fixture(name))
        assert not failed, f"{name}: {failed}"


def test_denial_is_recognised_within_one_phrase():
    for text in SOFT_AND_NAMED_DENIALS:
        assert tv._is_denial(text), f"отрицание не распознано: {text!r}"


def test_truthful_statements_with_negation_words_are_not_denial():
    for text in TRUTHFUL_WITH_NEGATION_WORDS:
        assert not tv._is_denial(text), f"правда принята за отрицание: {text!r}"


def test_common_connectives_are_causal():
    for text in ("Буфер переполняется, потому что длина не ограничена.",
                 "Данные теряются, так как результат записи не проверяется.",
                 "Процесс падает, поскольку исключение не перехватывается."):
        assert tv._has_causal_link(text, "error_handling"), text
