#!/bin/sh
# Verifier кейса b2c_case_04_50.
#
# Контракт логов:
#   /logs/verifier/reward.txt   — РОВНО одна строка: 0 или 1;
#   /logs/verifier/pytest.log   — полный вывод pytest;
#   /logs/verifier/verifier.log — диагностика verifier (почему именно такой reward).
#
# Итоговый reward записывается ПОСЛЕ прогона проверок, поэтому значение,
# записанное агентом в reward.txt во время работы, перетирается.
set -u

LOG_DIR="${VERIFIER_LOG_DIR:-/logs/verifier}"
mkdir -p "$LOG_DIR"

REWARD_FILE="$LOG_DIR/reward.txt"
PYTEST_LOG="$LOG_DIR/pytest.log"
DIAG_LOG="$LOG_DIR/verifier.log"

# Полное число объявленных проверок (fail_to_pass + pass_to_pass в task.toml).
EXPECTED_TESTS=25

: > "$PYTEST_LOG"
: > "$DIAG_LOG"
printf '0\n' > "$REWARD_FILE"

log() { printf '%s\n' "$*" >> "$DIAG_LOG"; }

unset PYTHONPATH
unset PYTHONHOME

# Интерпретатор выбирается по факту работоспособности, а не по одному лишь
# наличию в PATH: подходит первый, который реально запускается и импортирует pytest.
PY=""
for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c "import pytest" >/dev/null 2>&1; then
        PY="$candidate"
        break
    fi
done

if [ -z "$PY" ]; then
    log "[verifier] FATAL: рабочий python с установленным pytest не найден"
    log "[verifier] outcome=environment_error reward=0"
    exit 0
fi

log "[verifier] runner: $("$PY" -V 2>&1), pytest $("$PY" -m pytest --version 2>&1 | head -1)"

# -P не добавляет каталог решения в sys.path: верификатор изолирован от /app.
"$PY" -P -m pytest /tests/test_verifier.py -v --tb=short -p no:cacheprovider \
    > "$PYTEST_LOG" 2>&1
PYTEST_CODE=$?

log "[verifier] pytest exit code: $PYTEST_CODE"

RESULT=0
case "$PYTEST_CODE" in
    0)
        PASSED_COUNT="$(grep -oE '[0-9]+ passed' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        SKIPPED_COUNT="$(grep -oE '[0-9]+ skipped' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        DESELECTED_COUNT="$(grep -oE '[0-9]+ deselected' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        : "${PASSED_COUNT:=0}"; : "${SKIPPED_COUNT:=0}"; : "${DESELECTED_COUNT:=0}"
        log "[verifier] passed=$PASSED_COUNT skipped=$SKIPPED_COUNT deselected=$DESELECTED_COUNT (ожидается passed=$EXPECTED_TESTS, skipped=0)"
        if [ "$SKIPPED_COUNT" -ne 0 ] || [ "$DESELECTED_COUNT" -ne 0 ]; then
            log "[verifier] outcome=checks_skipped reward=0 (обязательные проверки не выполнены)"
        elif [ "$PASSED_COUNT" -ne "$EXPECTED_TESTS" ]; then
            log "[verifier] outcome=unexpected_test_count reward=0 (пройдено $PASSED_COUNT из $EXPECTED_TESTS)"
        else
            RESULT=1
            log "[verifier] outcome=all_checks_passed reward=1"
        fi
        ;;
    1) log "[verifier] outcome=checks_failed reward=0 (штатное падение проверок)" ;;
    2) log "[verifier] outcome=pytest_interrupted reward=0 (ВНУТРЕННЯЯ ошибка)" ;;
    3) log "[verifier] outcome=pytest_internal_error reward=0 (ВНУТРЕННЯЯ ошибка pytest)" ;;
    4) log "[verifier] outcome=pytest_usage_error reward=0 (ВНУТРЕННЯЯ ошибка аргументов)" ;;
    5) log "[verifier] outcome=no_tests_collected reward=0 (тесты не собраны)" ;;
    *) log "[verifier] outcome=unexpected_exit_code_${PYTEST_CODE} reward=0" ;;
esac

# Итоговая запись — ПОСЛЕ прогона проверок.
printf '%s\n' "$RESULT" > "$REWARD_FILE"
log "[verifier] final reward=$RESULT"

exit 0
