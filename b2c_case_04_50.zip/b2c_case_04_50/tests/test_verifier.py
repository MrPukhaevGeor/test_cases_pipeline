"""
Верификатор кейса b2c_case_04_50.
Агент пишет answer.json со структурированным анализом git diff (C).

Схема, допустимые элементы/категории/типы, пороги объёма, маркеры причинности и отрицания,
каталог дефектов кода и ложных утверждений загружаются ЕДИНОЖДЫ из неизменяемой фикстуры
/tests/fixtures/answer_schema.json.

Контракт (по техническому отчёту УМР, видимое задание без изменений):

1. Засчитывается любой набор не менее пяти независимых реальных дефектов показанного кода
   с обоснованной категорией. Скрытого обязательного состава нет. Правило «одна запись —
   один дефект»: повтор одного дефекта в нескольких записях считается один раз.
   Каталог реальных дефектов — true_findings в фикстуре (fread: результат и усечение,
   утечка потока при отказе malloc, статус pclose, scanf, URL в popen как команда оболочки,
   ошибки fopen/fprintf/fclose, изменяемый глобальный массив адреса, молчаливый выход).
   Конфигурируемость адреса требованием не является: hardcoded-адрес не обязателен.

2. Причинная связка — условие и последствие, а не закрытый список слов: принимается и
   «при коротком чтении или сбое». Отрицание распознаётся в пределах утверждения:
   «утечка при отказе malloc — отсутствует pclose» отрицанием не является.

3. Утверждение, которое из кода не следует, обнуляет результат: недостижимое переполнение,
   инъекция, SSRF, внешний filename, «popen выполняет HTTP-запрос», stderr в данных канала,
   «return освобождает канал», «адрес берётся из настроек», «результат malloc не проверяется».
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "a0a4d533e43e7d5d5e4765b58fbc305e8298e5b1d9fb569bd696aca74291c66a"
PROMPT_SHA256 = "b155362a7268681dd6bbb20ccaabde26527217c0e165afde5b735fe81f975615"
SCHEMA_SHA256 = "eac3c596da146785fd0b1cd0d768c26e0c166f61f6bf715102cfd82d6297804e"

# Явный деньлист типовых заглушек/филлера — ловит самые дешёвые попытки
# сгенерировать формально проходящий, но бессодержательный текст. Эвристика,
# не полноценная проверка связности: основная защита от keyword-soup —
# отсутствие спойлерных формулировок в diff.txt плюс AND-группы + причинность.
_FILLER_DENYLIST = (
    "лорем", "ипсум", "lorem", "ipsum", "asdf", "qwerty",
    "todo", "n/a", "placeholder", "тест тест", "xxx", "ффф", "ггг", "ддд",
)


def _norm(s):
    return (s or "").strip().lower()


def _looks_like_filler(text):
    t = _norm(text)
    if any(bad in t for bad in _FILLER_DENYLIST):
        return True
    words = re.findall(r"\w+", t)
    if not words:
        return True
    if len(words) < 6:
        return False
    from collections import Counter
    counts = Counter(words)
    most_common_ratio = counts.most_common(1)[0][1] / len(words)
    return most_common_ratio > 0.4


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
ANALYZED_FILE = _SCHEMA["analyzed_file"]
ANALYZED_FILE_PATH = _SCHEMA["analyzed_file_path"]
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
CAUSAL_MARKERS = tuple(_SCHEMA["causal_markers"])
MIN_CHANGES = _SCHEMA["min_changes"]
MIN_FINDINGS = _SCHEMA["min_findings"]

# Английские связки проверяются по границам слова: подстрочное совпадение дало бы
# ложные срабатывания («if» внутри «notification»).
_EN_CAUSAL_RE = re.compile(
    r"(?<![a-z])(?:" + "|".join(re.escape(m) for m in _SCHEMA["causal_markers_en"]) + r")(?![a-z])"
)
_DENIAL_RES = tuple(re.compile(p) for p in _SCHEMA["denial_patterns"])
_CAUSAL_RES = tuple(re.compile(p) for p in _SCHEMA["causal_patterns"])
TRUE_FINDINGS = _SCHEMA["true_findings"]
FALSE_CLAIMS = _SCHEMA["false_claims"]


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _is_denial(text):
    """Текст утверждает ОТСУТСТВИЕ дефекта («утечки нет», «проверка не нужна»,
    «вызов безопасен»). Такая запись не является находкой: она не закрывает
    контракт и не засчитывается в объём important_findings.

    Отрицание намеренно ловится отдельными шаблонами, а не одиночными словами:
    «небезопасный», «некорректный» и подобные отрицательные формы содержат
    подстроки «безопасн»/«корректн» и отрицанием дефекта не являются."""
    t = _norm(text)
    return any(rx.search(t) for rx in _DENIAL_RES)


def _has_causal_link(text, category):
    """Объяснение содержит причинно-следственную связку: при каком условии дефект
    срабатывает и к чему приводит.

    Для code_quality не требуется: структурные замечания (магическая строка
    конфигурации и т.п.) по своей природе не имеют сценария срабатывания.

    Принимается и русская, и английская связка — язык связки не является
    скрытым требованием. Одиночное «может» намеренно НЕ является маркером:
    общая фраза «может привести к ошибке» причинной связкой не является."""
    if category == "code_quality":
        return True
    t = _norm(text)
    if any(m in t for m in CAUSAL_MARKERS):
        return True
    if any(rx.search(t) for rx in _CAUSAL_RES):
        return True
    return bool(_EN_CAUSAL_RE.search(t))



def _substantive_findings(data):
    """Записи, которые действительно сообщают о дефекте. Запись, утверждающая
    отсутствие проблемы, в объём important_findings не засчитывается —
    это правило продублировано в видимом контракте."""
    out = []
    for f in data["important_findings"]:
        if not isinstance(f, dict):
            continue
        if _is_denial(_norm(f.get("detail", "") + " " + f.get("finding", ""))):
            continue
        out.append(f)
    return out


def _hit_any(patterns, text):
    return any(re.search(p, text) for p in patterns)


def _in_slot(record, entry):
    return (_norm(record.get("element", "")) in {e.lower() for e in entry["elements"]}
            and _norm(record.get("category", "")) in set(entry["categories"]))


def _finding_text(f):
    return _norm(str(f.get("finding", "")) + " " + str(f.get("detail", "")))


def _false_claim(record):
    """Утверждение, которое из показанного кода не следует; None, если такого нет."""
    text = _finding_text(record)
    el = _norm(record.get("element", ""))
    cat = _norm(record.get("category", ""))
    for c in FALSE_CLAIMS:
        if c["elements"] and el not in {e.lower() for e in c["elements"]}:
            continue
        if c["categories"] and cat not in set(c["categories"]):
            continue
        if c["any"] and not _hit_any(c["any"], text):
            continue
        if c["all"] and not all(re.search(p, text) for p in c["all"]):
            continue
        return c["why"]
    return None


def _candidates(record):
    text = _finding_text(record)
    return [e["id"] for e in TRUE_FINDINGS if _in_slot(record, e) and any(t in text for t in e["topic"])]


def _real_defects(data):
    """Независимые реальные дефекты, покрытые записями ответа: сопоставление один к одному
    (алгоритм Куна), одна запись — один дефект, повтор дефекта считается один раз."""
    recs = [f for f in _substantive_findings(data)
            if not _false_claim(f)
            and _has_causal_link(f.get("detail", ""), _norm(f.get("category", "")))]
    cands = [_candidates(f) for f in recs]
    owner = {}

    def augment(i, seen):
        for d in cands[i]:
            if d in seen:
                continue
            seen.add(d)
            if d not in owner or augment(owner[d], seen):
                owner[d] = i
                return True
        return False

    for i in range(len(recs)):
        augment(i, set())
    return sorted(owner)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


def test_visible_contract_matches_fixture():
    """PASS_TO_PASS: видимое агенту задание и исполняемые проверки описывают одно
    и то же — допустимые элементы, категории, типы и пороги объёма из фикстуры
    перечислены в system_prompt.txt. Скрытых правил в кейсе нет.

    Файл читается только после сверки sha256, поэтому подменить его нельзя."""
    path = os.path.join(APP, "system_prompt.txt")
    assert os.path.isfile(path), "system_prompt.txt отсутствует в /app"
    assert _sha256(path) == PROMPT_SHA256, "system_prompt.txt изменён агентом"
    text = open(path, "r", encoding="utf-8").read()
    low = text.lower()
    for element in _SCHEMA["valid_elements"]:
        assert element.lower() in low, f"элемент '{element}' не перечислен в видимом контракте"
    for category in VALID_CATEGORIES:
        assert category in low, f"категория '{category}' не перечислена в видимом контракте"
    for type_name in VALID_TYPES:
        assert type_name in low, f"тип '{type_name}' не перечислен в видимом контракте"
    assert str(MIN_CHANGES) in text, "порог changes не указан в видимом контракте"
    assert str(MIN_FINDINGS) in text, "порог important_findings не указан в видимом контракте"
    assert ANALYZED_FILE in text, "имя анализируемого файла не указано в видимом контракте"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json — объект с полями file, changes, important_findings."""
    data = _load()
    assert isinstance(data, dict), "answer.json должен быть объектом, а не списком/строкой"
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"
    assert all(isinstance(c, dict) for c in data["changes"]), "элементы changes должны быть объектами"
    assert all(isinstance(f, dict) for f in data["important_findings"]), \
        "элементы important_findings должны быть объектами"


def test_file_field_names_analyzed_file():
    """FAIL_TO_PASS: поле file называет реально анализируемый файл из diff.

    Разбор, указывающий на выдуманный файл, контракт не выполняет, даже если
    остальные поля формально заполнены."""
    data = _load()
    value = _norm(data.get("file", "")).replace("\\", "/")
    name = _norm(ANALYZED_FILE)
    full = _norm(ANALYZED_FILE_PATH)
    ok = value in (name, full) or value.endswith("/" + name)
    assert ok, (
        f"Поле file называет '{data.get('file')}', а анализируется '{ANALYZED_FILE}' "
        f"(допустим и полный путь '{ANALYZED_FILE_PATH}')"
    )


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: объём changes не ниже порога из фикстуры (порог продублирован
    в instruction.md и system_prompt.txt — скрытых порогов в кейсе нет)."""
    data = _load()
    assert len(data["changes"]) >= MIN_CHANGES, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= {MIN_CHANGES}"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (fetch_user_data,
    save_to_file, main, API_BASE_URL)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"]
               if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


def test_changes_descriptions_not_filler():
    """FAIL_TO_PASS: description в changes не похож на заглушку/lorem-ipsum."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert not _looks_like_filler(desc), f"description для '{el}' похож на заглушку/филлер"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: объём important_findings не ниже порога из фикстуры.

    Считаются записи, которые сообщают о дефекте: запись вида «здесь проблемы
    нет» находкой не является (правило продублировано в видимом контракте)."""
    data = _load()
    substantive = _substantive_findings(data)
    assert len(substantive) >= MIN_FINDINGS, (
        f"important_findings содержит {len(substantive)} записей о дефектах "
        f"(всего записей {len(data['important_findings'])}), нужно >= {MIN_FINDINGS}"
    )


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding, не филлер/заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"
        assert not _looks_like_filler(detail), f"detail для '{el}' похож на заглушку/филлер"


def test_findings_finding_field_present():
    """FAIL_TO_PASS: поле finding в каждом important_finding непустое и
    содержательное (не заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        finding = (f.get("finding") or "").strip()
        assert len(finding) >= 8, f"finding для '{el}' пустой или слишком короткий"
        assert not _looks_like_filler(finding), f"finding для '{el}' похож на заглушку/филлер"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих находок (element, category, finding).
    Для fetch_user_data допустимо несколько записей с одной категорией (разные
    проблемы), поэтому уникальность проверяется по всей тройке."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")), _norm(f.get("finding", "")))
        assert key not in seen, f"Дублирующая находка: {key}"
        seen.add(key)


def test_findings_have_distinct_details():
    """FAIL_TO_PASS: одно и то же объяснение не может закрывать несколько разных
    findings — повторяющийся detail означает generic-текст, скопированный между
    записями, а не разбор конкретных дефектов."""
    data = _load()
    seen = {}
    for f in data["important_findings"]:
        key = _norm(f.get("detail", ""))
        assert key not in seen, (
            f"detail записи для '{f.get('element')}' дословно повторяет detail "
            f"записи для '{seen[key]}' — одно объяснение скопировано между findings"
        )
        seen[key] = f.get("element")


# ── fail_to_pass: записи следуют из показанного кода ──────────────────────────

def test_findings_follow_from_diff():
    """FAIL_TO_PASS: запись о дефекте не утверждает того, что из показанного кода не
    следует (недостижимое переполнение, инъекция, SSRF, внешний filename, неверная
    механика popen/pclose/fread, «адрес берётся из настроек»)."""
    data = _load()
    bad = []
    for f in _substantive_findings(data):
        why = _false_claim(f)
        if why:
            bad.append(f"{f.get('element')}/{f.get('category')}: {why}")
    assert not bad, "Утверждение не следует из diff: " + "; ".join(bad)


def test_findings_cover_independent_real_defects():
    """FAIL_TO_PASS: ответ покрывает не менее MIN_FINDINGS независимых реальных дефектов
    показанного кода; одна запись — один дефект, повтор считается один раз. Состав
    дефектов и формулировки — на выбор решателя."""
    data = _load()
    found = _real_defects(data)
    assert len(found) >= MIN_FINDINGS, (
        f"независимых реальных дефектов: {len(found)} ({found}), нужно >= {MIN_FINDINGS}"
    )
