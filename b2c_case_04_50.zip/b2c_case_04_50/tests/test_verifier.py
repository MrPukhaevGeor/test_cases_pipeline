"""
Верификатор кейса b2c_case_04_50.
Агент пишет answer.json со структурированным анализом git diff (C).

Схема, допустимые элементы/категории/типы, пороги объёма, маркеры причинности,
маркеры отрицания, обязательные и альтернативные findings загружаются ЕДИНОЖДЫ из
неизменяемой фикстуры /tests/fixtures/answer_schema.json (DRY — единственный
источник правды, никаких дублирующих констант в Python).

Контракт после раундов ревью:

1. Обязательными оставлены только те findings, которые ОДНОЗНАЧНО следуют из кода
   diff: непроверенный результат fread, утечка pipe при отказе malloc,
   непроверенный результат scanf и захардкоженный адрес сервиса.

   Убраны из обязательных (обоснование — notes_on_dropped_findings в фикстуре):
     - buffer overflow: длина итоговой строки детерминирована и в char[512] влезает;
     - SSRF: HTTP-запроса в коде нет вообще, url уходит в popen();
     - command injection / RCE: user_id имеет тип int, shell-метасимволы
       через scanf("%d") не проходят.

2. Заведомо ложный разбор больше не проходит:
     - поле file обязано называть реально анализируемый файл (cpp.c), а не
       выдуманный;
     - запись, которая ОТРИЦАЕТ дефект («проверка не нужна», «утечки нет»,
       «вызов безопасен»), не закрывает контракт и не идёт в зачёт объёма;
     - совпадения расходуются один к одному: одна запись ответа закрывает не
       более одной спецификации, поэтому «сборная» запись, перечисляющая сразу
       несколько дефектов, больше не закрывает несколько меток.

3. Скрытых правил не осталось: список допустимых элементов, пороги объёма, язык
   ответа и допустимая привязка причины перечислены в видимом агенту
   system_prompt.txt, а тест test_visible_contract_matches_fixture проверяет,
   что видимый контракт и исполняемые проверки описывают одно и то же.
   Проблему можно привязать как к охватывающей функции, так и к конкретному
   вызову или переменной места дефекта (accepted_elements в фикстуре).

4. Технически корректная парафраза не отклоняется: группы ключевых слов
   расширены синонимичными формулировками, причинная связка принимается и в
   русской, и в английской форме, а сверх обязательных findings достаточно
   закрыть минимум один пункт из пула alternative_findings.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "a0a4d533e43e7d5d5e4765b58fbc305e8298e5b1d9fb569bd696aca74291c66a"
PROMPT_SHA256 = "b155362a7268681dd6bbb20ccaabde26527217c0e165afde5b735fe81f975615"
SCHEMA_SHA256 = "29367366320477d2dc0633399c1bc1aaba20c4b4680199b7e610479ad040b9d1"

# Явный деньлист типовых заглушек/филлера — ловит самые дешёвые попытки
# сгенерировать формально проходящий, но бессодержательный текст. Эвристика,
# не полноценная проверка связности: основная защита от keyword-soup —
# отсутствие спойлерных формулировок в diff.txt плюс AND-группы + причинность.
_FILLER_DENYLIST = (
    "лорем", "ипсум", "lorem", "ipsum", "asdf", "qwerty",
    "todo", "n/a", "placeholder", "тест тест", "xxx", "ффф", "ггг", "ддд",
)


def _norm(s):
    return (s or "").strip().lower()


def _looks_like_filler(text):
    t = _norm(text)
    if any(bad in t for bad in _FILLER_DENYLIST):
        return True
    words = re.findall(r"\w+", t)
    if not words:
        return True
    if len(words) < 6:
        return False
    from collections import Counter
    counts = Counter(words)
    most_common_ratio = counts.most_common(1)[0][1] / len(words)
    return most_common_ratio > 0.4


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
ANALYZED_FILE = _SCHEMA["analyzed_file"]
ANALYZED_FILE_PATH = _SCHEMA["analyzed_file_path"]
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]
ALTERNATIVE_FINDINGS = _SCHEMA["alternative_findings"]
ALL_SPECS = {s["id"]: s for s in REQUIRED_FINDINGS + ALTERNATIVE_FINDINGS}
CAUSAL_MARKERS = tuple(_SCHEMA["causal_markers"])
MIN_CHANGES = _SCHEMA["min_changes"]
MIN_FINDINGS = _SCHEMA["min_findings"]
MIN_ALTERNATIVE_FINDINGS = _SCHEMA["min_alternative_findings"]

# Английские связки проверяются по границам слова: подстрочное совпадение дало бы
# ложные срабатывания («if» внутри «notification»).
_EN_CAUSAL_RE = re.compile(
    r"(?<![a-z])(?:" + "|".join(re.escape(m) for m in _SCHEMA["causal_markers_en"]) + r")(?![a-z])"
)
_DENIAL_RES = tuple(re.compile(p) for p in _SCHEMA["denial_patterns"])


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _is_denial(text):
    """Текст утверждает ОТСУТСТВИЕ дефекта («утечки нет», «проверка не нужна»,
    «вызов безопасен»). Такая запись не является находкой: она не закрывает
    контракт и не засчитывается в объём important_findings.

    Отрицание намеренно ловится отдельными шаблонами, а не одиночными словами:
    «небезопасный», «некорректный» и подобные отрицательные формы содержат
    подстроки «безопасн»/«корректн» и отрицанием дефекта не являются."""
    t = _norm(text)
    return any(rx.search(t) for rx in _DENIAL_RES)


def _has_causal_link(text, category):
    """Объяснение содержит причинно-следственную связку: при каком условии дефект
    срабатывает и к чему приводит.

    Для code_quality не требуется: структурные замечания (магическая строка
    конфигурации и т.п.) по своей природе не имеют сценария срабатывания.

    Принимается и русская, и английская связка — язык связки не является
    скрытым требованием. Одиночное «может» намеренно НЕ является маркером:
    общая фраза «может привести к ошибке» причинной связкой не является."""
    if category == "code_quality":
        return True
    t = _norm(text)
    if any(m in t for m in CAUSAL_MARKERS):
        return True
    return bool(_EN_CAUSAL_RE.search(t))


def _spec_categories(spec):
    """Спецификация задаёт либо одну категорию, либо набор допустимых:
    для части замечаний таксономия объективно неоднозначна (например,
    выполнение url через оболочку можно отнести и к security, и к
    code_quality), и агент не обязан угадывать единственный вариант."""
    if "categories" in spec:
        return {c.lower() for c in spec["categories"]}
    return {spec["category"].lower()}


def _spec_elements(spec):
    """Допустимая привязка причины: охватывающая функция ИЛИ конкретный вызов /
    переменная, где дефект физически находится. Обе формы правдивы, поэтому
    верификатор принимает любую из перечисленных в accepted_elements."""
    return {e.lower() for e in spec.get("accepted_elements", [spec["element"]])}


def _record_matches_spec(record, spec):
    """Запись закрывает спецификацию, если она привязана к допустимому элементу и
    категории, её текст (finding + detail) содержит ВСЕ ключевые слова хотя бы
    одной группы (AND внутри группы, OR между группами), содержит причинную
    связку (кроме code_quality) и НЕ отрицает сам дефект."""
    if _norm(record.get("element", "")) not in _spec_elements(spec):
        return False
    cat = _norm(record.get("category", ""))
    if cat not in _spec_categories(spec):
        return False
    text = _norm(record.get("detail", "") + " " + record.get("finding", ""))
    if not any(all(kw in text for kw in group) for group in spec["keyword_groups"]):
        return False
    if _is_denial(text):
        return False
    return _has_causal_link(record.get("detail", ""), cat)


def _assignment(data):
    """Сопоставление спецификаций и записей ответа ОДИН К ОДНОМУ: одна запись
    закрывает не более одной спецификации. Иначе «сборная» запись, в которой
    перечислено сразу несколько дефектов, закрывала бы несколько меток разом.

    Алгоритм Куна: сначала обязательные спецификации, затем альтернативные;
    поиск дополняющих путей уже сопоставленную спецификацию не расцепляет.
    """
    findings = data["important_findings"]
    owner = {}  # индекс записи -> id спецификации

    def candidates(spec):
        return [i for i, rec in enumerate(findings)
                if isinstance(rec, dict) and _record_matches_spec(rec, spec)]

    def augment(spec, visited):
        for i in candidates(spec):
            if i in visited:
                continue
            visited.add(i)
            held_by = owner.get(i)
            if held_by is None or augment(ALL_SPECS[held_by], visited):
                owner[i] = spec["id"]
                return True
        return False

    for spec in REQUIRED_FINDINGS:
        augment(spec, set())
    matched_alternatives = [spec["id"] for spec in ALTERNATIVE_FINDINGS if augment(spec, set())]
    return {spec_id: idx for idx, spec_id in owner.items()}, matched_alternatives


def _matched_ids(data):
    return _assignment(data)[0]


def _substantive_findings(data):
    """Записи, которые действительно сообщают о дефекте. Запись, утверждающая
    отсутствие проблемы, в объём important_findings не засчитывается —
    это правило продублировано в видимом контракте."""
    out = []
    for f in data["important_findings"]:
        if not isinstance(f, dict):
            continue
        if _is_denial(_norm(f.get("detail", "") + " " + f.get("finding", ""))):
            continue
        out.append(f)
    return out


def _spec_by_id(specs, spec_id):
    for s in specs:
        if s["id"] == spec_id:
            return s
    raise KeyError(spec_id)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


def test_visible_contract_matches_fixture():
    """PASS_TO_PASS: видимое агенту задание и исполняемые проверки описывают одно
    и то же — допустимые элементы, категории, типы и пороги объёма из фикстуры
    перечислены в system_prompt.txt. Скрытых правил в кейсе нет.

    Файл читается только после сверки sha256, поэтому подменить его нельзя."""
    path = os.path.join(APP, "system_prompt.txt")
    assert os.path.isfile(path), "system_prompt.txt отсутствует в /app"
    assert _sha256(path) == PROMPT_SHA256, "system_prompt.txt изменён агентом"
    text = open(path, "r", encoding="utf-8").read()
    low = text.lower()
    for element in _SCHEMA["valid_elements"]:
        assert element.lower() in low, f"элемент '{element}' не перечислен в видимом контракте"
    for category in VALID_CATEGORIES:
        assert category in low, f"категория '{category}' не перечислена в видимом контракте"
    for type_name in VALID_TYPES:
        assert type_name in low, f"тип '{type_name}' не перечислен в видимом контракте"
    assert str(MIN_CHANGES) in text, "порог changes не указан в видимом контракте"
    assert str(MIN_FINDINGS) in text, "порог important_findings не указан в видимом контракте"
    assert ANALYZED_FILE in text, "имя анализируемого файла не указано в видимом контракте"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json — объект с полями file, changes, important_findings."""
    data = _load()
    assert isinstance(data, dict), "answer.json должен быть объектом, а не списком/строкой"
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"
    assert all(isinstance(c, dict) for c in data["changes"]), "элементы changes должны быть объектами"
    assert all(isinstance(f, dict) for f in data["important_findings"]), \
        "элементы important_findings должны быть объектами"


def test_file_field_names_analyzed_file():
    """FAIL_TO_PASS: поле file называет реально анализируемый файл из diff.

    Разбор, указывающий на выдуманный файл, контракт не выполняет, даже если
    остальные поля формально заполнены."""
    data = _load()
    value = _norm(data.get("file", "")).replace("\\", "/")
    name = _norm(ANALYZED_FILE)
    full = _norm(ANALYZED_FILE_PATH)
    ok = value in (name, full) or value.endswith("/" + name)
    assert ok, (
        f"Поле file называет '{data.get('file')}', а анализируется '{ANALYZED_FILE}' "
        f"(допустим и полный путь '{ANALYZED_FILE_PATH}')"
    )


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: объём changes не ниже порога из фикстуры (порог продублирован
    в instruction.md и system_prompt.txt — скрытых порогов в кейсе нет)."""
    data = _load()
    assert len(data["changes"]) >= MIN_CHANGES, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= {MIN_CHANGES}"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (fetch_user_data,
    save_to_file, main, API_BASE_URL)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"]
               if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


def test_changes_descriptions_not_filler():
    """FAIL_TO_PASS: description в changes не похож на заглушку/lorem-ipsum."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert not _looks_like_filler(desc), f"description для '{el}' похож на заглушку/филлер"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: объём important_findings не ниже порога из фикстуры.

    Считаются записи, которые сообщают о дефекте: запись вида «здесь проблемы
    нет» находкой не является (правило продублировано в видимом контракте)."""
    data = _load()
    substantive = _substantive_findings(data)
    assert len(substantive) >= MIN_FINDINGS, (
        f"important_findings содержит {len(substantive)} записей о дефектах "
        f"(всего записей {len(data['important_findings'])}), нужно >= {MIN_FINDINGS}"
    )


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding, не филлер/заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"
        assert not _looks_like_filler(detail), f"detail для '{el}' похож на заглушку/филлер"


def test_findings_finding_field_present():
    """FAIL_TO_PASS: поле finding в каждом important_finding непустое и
    содержательное (не заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        finding = (f.get("finding") or "").strip()
        assert len(finding) >= 8, f"finding для '{el}' пустой или слишком короткий"
        assert not _looks_like_filler(finding), f"finding для '{el}' похож на заглушку/филлер"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих находок (element, category, finding).
    Для fetch_user_data допустимо несколько записей с одной категорией (разные
    проблемы), поэтому уникальность проверяется по всей тройке."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")), _norm(f.get("finding", "")))
        assert key not in seen, f"Дублирующая находка: {key}"
        seen.add(key)


def test_findings_have_distinct_details():
    """FAIL_TO_PASS: одно и то же объяснение не может закрывать несколько разных
    findings — повторяющийся detail означает generic-текст, скопированный между
    записями, а не разбор конкретных дефектов."""
    data = _load()
    seen = {}
    for f in data["important_findings"]:
        key = _norm(f.get("detail", ""))
        assert key not in seen, (
            f"detail записи для '{f.get('element')}' дословно повторяет detail "
            f"записи для '{seen[key]}' — одно объяснение скопировано между findings"
        )
        seen[key] = f.get("element")


# ── fail_to_pass: обязательные findings по контракту (данные из fixture) ──────

def test_finding_fread_unchecked_present():
    """FAIL_TO_PASS: результат fread не проверяется, хвост буфера остаётся
    неинициализированным. Привязка — fetch_user_data либо сам вызов fread."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "fread_unchecked")
    assert "fread_unchecked" in _matched_ids(data), \
        f"Нет отдельной записи: {'/'.join(spec['accepted_elements'])} / {spec['category']} / непроверенный результат чтения"


def test_finding_pipe_leak_on_malloc_fail_present():
    """FAIL_TO_PASS: после успешного popen() отказ malloc() приводит к возврату
    без закрытия потока. Привязка — fetch_user_data, pipe, popen либо malloc."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "pipe_leak_on_malloc_fail")
    assert "pipe_leak_on_malloc_fail" in _matched_ids(data), \
        f"Нет отдельной записи: {'/'.join(spec['accepted_elements'])} / {spec['category']} / утечка потока при отказе выделения памяти"


def test_finding_scanf_unchecked_present():
    """FAIL_TO_PASS: результат scanf не проверяется. Привязка — main, scanf либо user_id."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "scanf_unchecked")
    assert "scanf_unchecked" in _matched_ids(data), \
        f"Нет отдельной записи: {'/'.join(spec['accepted_elements'])} / {spec['category']} / непроверенный результат считывания ввода"


def test_finding_api_base_url_hardcoded_present():
    """FAIL_TO_PASS: адрес сервиса зашит в код. Привязка — API_BASE_URL либо url."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "api_base_url_hardcoded")
    assert "api_base_url_hardcoded" in _matched_ids(data), \
        f"Нет отдельной записи: {'/'.join(spec['accepted_elements'])} / {spec['category']} / адрес сервиса зашит в исходный код"


def test_at_least_one_alternative_finding_present():
    """FAIL_TO_PASS: помимо обязательных findings ответ закрывает минимум
    MIN_ALTERNATIVE_FINDINGS пунктов из пула технически корректных альтернатив
    (выполнение url через оболочку в popen, небезопасный sink save_to_file,
    неограниченный sprintf) ОТДЕЛЬНЫМИ записями. Пул — это то, что позволяет
    правдоподобной альтернативной рецензии получить reward=1."""
    data = _load()
    _, matched = _assignment(data)
    assert len(matched) >= MIN_ALTERNATIVE_FINDINGS, (
        f"Закрыто альтернативных findings отдельными записями: {len(matched)} ({matched}), "
        f"нужно >= {MIN_ALTERNATIVE_FINDINGS}. Допустимые варианты: "
        f"{[s['id'] for s in ALTERNATIVE_FINDINGS]}"
    )
