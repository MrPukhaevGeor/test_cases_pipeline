"""
Regression-тест самого verifier'а (не часть reward-контракта агента).

Проверяет две вещи на фиксированных фикстурах, а не на живом ответе агента:
  1. negative_keyword_soup.json — ответ, где все нужные слова присутствуют,
     но finding/detail — это скопированные лейблы без причинного объяснения.
     Matcher обязан НЕ засчитать хотя бы часть обязательных findings.
  2. positive_synonymous.json — технически корректный ответ, сформулированный
     другими словами (без точных keyword'ов из фикстуры). Matcher обязан
     засчитать ВСЕ обязательные findings.

Запускать вручную при любом изменении _match_required / keyword_groups /
_has_causal_link, до сдачи кейса. Не входит в tests/test.sh и не влияет
на reward — это проверка качества самого verifier'а, а не агента.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
sys.path.insert(0, TESTS_DIR)

import test_verifier as tv  # noqa: E402


def _load_fixture(name):
    with open(os.path.join(HERE, name), "r", encoding="utf-8") as f:
        return json.load(f)


def test_negative_keyword_soup_does_not_satisfy_all_required_findings():
    """Keyword-soup без причинного объяснения не должен закрывать весь контракт —
    хотя бы часть обязательных findings обязана остаться непойманной."""
    data = _load_fixture("negative_keyword_soup.json")
    unmatched = [
        req["finding_label"] for req in tv.REQUIRED_FINDINGS
        if tv._match_required(data, req) is None
    ]
    assert unmatched, (
        "Verifier засчитал keyword-soup как валидный ответ по всем "
        "обязательным findings — matcher не защищает от копипаста лейблов."
    )


def test_positive_synonymous_answer_satisfies_all_required_findings():
    """Технически корректный, но иначе сформулированный ответ обязан закрыть
    весь контракт — иначе verifier даёт ложноотрицательный результат."""
    data = _load_fixture("positive_synonymous.json")
    unmatched = [
        req["finding_label"] for req in tv.REQUIRED_FINDINGS
        if tv._match_required(data, req) is None
    ]
    assert not unmatched, (
        f"Verifier не засчитал корректные findings, сформулированные "
        f"синонимично: {unmatched}. Matcher слишком строг к формулировке."
    )
