"""
Верификатор кейса b2c_case_04_50.
Агент пишет answer.json со структурированным анализом git diff (C).
Схема, допустимые элементы/категории/типы и обязательные findings загружаются
ЕДИНОЖДЫ из неизменяемой фикстуры /tests/fixtures/answer_schema.json (DRY —
единственный источник правды, никаких дублирующих констант в Python).

Сопоставление findings — по AND-группам ключевых слов (совпадение = все слова
одной группы присутствуют в тексте finding+detail). Это исключает ложные
срабатывания на одиночных общеупотребительных словах, встреченных не по теме
(например, слово "using" в контексте импортов вместо реальной утечки ресурса).
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "a0a4d533e43e7d5d5e4765b58fbc305e8298e5b1d9fb569bd696aca74291c66a"
PROMPT_SHA256 = "f3c43ce9e794bd7394dc7c8979e105803e1e834cbababd57001a339fa9243d15"
SCHEMA_SHA256 = "ae3efcb01fc59035c682b7abad1ac1f0290edc00c1e9e852d4d17f518bd6bd36"

# Явный деньлист типовых заглушек/филлера — ловит самые дешёвые попытки
# сгенерировать формально проходящий, но бессодержательный текст. Эвристика,
# не полноценная проверка связности: основная защита от keyword-soup —
# отсутствие спойлерных формулировок в diff.txt.
_FILLER_DENYLIST = (
    "лорем", "ипсум", "lorem", "ipsum", "asdf", "qwerty",
    "todo", "n/a", "placeholder", "тест тест", "xxx", "ффф", "ггг", "ддд",
)

# Маркеры причинно-следственной связи: "что вызывает проблему и при каком
# сценарии она проявляется" — это то, что реально отличает keyword-soup
# копипаст лейбла от содержательного технического объяснения. Копипаст
# спойлерного комментария вида "Уязвимость: X" почти никогда не содержит
# условной/причинной конструкции; настоящее объяснение — почти всегда.
# Для code_quality не требуется: структурные проблемы (магические строки
# и т.п.) по своей природе не имеют сценария срабатывания.
_CAUSAL_MARKERS = (
    "если", "привод", "позвол", "вследствие", "в результате",
    "из-за", "создаёт риск", "создает риск", "может",
)


def _has_causal_link(text, category):
    if category == "code_quality":
        return True
    t = _norm(text)
    return any(m in t for m in _CAUSAL_MARKERS)


def _looks_like_filler(text):
    t = _norm(text)
    if any(bad in t for bad in _FILLER_DENYLIST):
        return True
    words = re.findall(r"\w+", t)
    if not words:
        return True
    if len(words) < 6:
        return False
    from collections import Counter
    counts = Counter(words)
    most_common_ratio = counts.most_common(1)[0][1] / len(words)
    return most_common_ratio > 0.4


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _norm(s):
    return (s or "").strip().lower()


def _match_required(data, req):
    """Проверить что answer.json содержит finding, соответствующий требованию req
    из fixture: (element, category) совпадают, текст (finding+detail) содержит
    ВСЕ ключевые слова хотя бы одной из групп keyword_groups (AND внутри группы,
    OR между группами), И (кроме code_quality) detail содержит причинно-следственную
    связку — иначе это просто скопированный лейбл без объяснения."""
    el = _norm(req["element"])
    cat = req["category"]
    groups = req["keyword_groups"]
    for f in data["important_findings"]:
        if _norm(f.get("element", "")) == el and _norm(f.get("category", "")) == cat:
            text = _norm(f.get("detail", "") + " " + f.get("finding", ""))
            if any(all(kw in text for kw in group) for group in groups):
                if _has_causal_link(f.get("detail", ""), cat):
                    return f
    return None


def _req_by_label(label):
    for r in REQUIRED_FINDINGS:
        if r["finding_label"] == label:
            return r
    raise KeyError(label)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_c():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла (C)."""
    data = _load()
    fv = _norm(data.get("file", ""))
    assert "cpp" in fv or fv.endswith(".c") or "cpp.c" in fv, \
        f"Поле file не содержит имя C-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: в changes минимум 4 элемента."""
    data = _load()
    assert len(data["changes"]) >= 4, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= 4"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (fetch_user_data,
    save_to_file, main, API_BASE_URL)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"] if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: в important_findings минимум 8 findings."""
    data = _load()
    assert len(data["important_findings"]) >= 8, \
        f"important_findings содержит {len(data['important_findings'])} элементов, нужно >= 8"


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding, не филлер/заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"
        assert not _looks_like_filler(detail), f"detail для '{el}' похож на заглушку/филлер"


def test_findings_finding_field_present():
    """FAIL_TO_PASS: поле finding в каждом important_finding непустое,
    содержательное (не заглушка) и отличается от detail."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        finding = (f.get("finding") or "").strip()
        assert len(finding) >= 8, f"finding для '{el}' пустой или слишком короткий"
        assert not _looks_like_filler(finding), f"finding для '{el}' похож на заглушку/филлер"


def test_changes_descriptions_not_filler():
    """FAIL_TO_PASS: description в changes не похож на заглушку/lorem-ipsum."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert not _looks_like_filler(desc), f"description для '{el}' похож на заглушку/филлер"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих пар (element, category, finding) в important_findings.
    Для fetch_user_data допустимо несколько findings с category=security (SSRF, buffer
    overflow, popen — разные проблемы), поэтому уникальность проверяется по всей тройке."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")), _norm(f.get("finding", "")))
        assert key not in seen, f"Дублирующая находка: {key}"
        seen.add(key)


# ── fail_to_pass: обязательные findings по контракту (данные из fixture) ──────

def test_finding_buffer_overflow_present():
    """FAIL_TO_PASS: finding security про переполнение буфера в sprintf привязан
    к fetch_user_data."""
    data = _load()
    req = _req_by_label("buffer_overflow")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / переполнение буфера"


def test_finding_ssrf_present():
    """FAIL_TO_PASS: finding security/SSRF привязан к fetch_user_data."""
    data = _load()
    req = _req_by_label("ssrf")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / SSRF"


def test_finding_popen_unsafe_present():
    """FAIL_TO_PASS: finding security про небезопасный popen (риск RCE) привязан
    к fetch_user_data."""
    data = _load()
    req = _req_by_label("popen_unsafe")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / небезопасный popen"


def test_finding_fread_unchecked_present():
    """FAIL_TO_PASS: finding error_handling про непроверенный результат fread
    привязан к fetch_user_data."""
    data = _load()
    req = _req_by_label("fread_unchecked")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / непроверенный fread"


def test_finding_path_traversal_present():
    """FAIL_TO_PASS: finding security/Path Traversal привязан к save_to_file."""
    data = _load()
    req = _req_by_label("path_traversal")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / Path Traversal"


def test_finding_magic_config_string_present():
    """FAIL_TO_PASS: finding code_quality про магическую строку конфигурации
    привязан к API_BASE_URL."""
    data = _load()
    req = _req_by_label("magic_config_string")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / магическая строка конфигурации"


def test_finding_no_input_validation_present():
    """FAIL_TO_PASS: finding error_handling про отсутствие проверки ввода user_id
    привязан к main."""
    data = _load()
    req = _req_by_label("no_input_validation")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / отсутствие проверки ввода"


def test_finding_resource_leak_present():
    """FAIL_TO_PASS: finding resource_leak про утечку pipe при ошибке malloc
    привязан к fetch_user_data (popen() успешен, malloc() возвращает NULL,
    функция выходит без pclose(pipe))."""
    data = _load()
    req = _req_by_label("pipe_leak_on_malloc_fail")
    assert _match_required(data, req), \
        f"Нет finding: {req['element']} / {req['category']} / утечка pipe при ошибке malloc"
