"""
Regression-тесты самого verifier'а кейса b2c_case_04_50 (не часть reward-контракта агента).

Проверяют matcher на фиксированных контрольных ответах, а не на живом ответе агента:

  1. negative_keyword_soup.json — все нужные слова присутствуют, но detail это
     скопированный лейбл без причинно-следственного объяснения. Обязательный
     контракт закрываться не должен.

  2. negative_generic_and_repeated.json — общие объяснения вида «может привести к
     ошибке», часть из которых ещё и дословно повторяется между записями. Ни один
     обязательный или альтернативный finding засчитан быть не должен, а
     повторяющийся detail обязан детектироваться.

  3. positive_synonymous.json — технически корректный ответ другими словами:
     обязан закрывать весь контракт.

  4. positive_leak_paraphrase.json — прицельно на замечание ревью: корректное
     описание утечки ресурса БЕЗ слов pipe, popen, malloc, NULL и «закры».
     Обязан закрывать весь контракт, иначе matcher слишком строг к формулировке.

Дополнительно проверяется, что фикстура не разъезжается с фактическим diff.txt.

Запускать вручную при любом изменении _match_required / keyword_groups /
causal_markers, до сдачи кейса. Не входит в tests/test.sh и на reward не влияет —
это проверка качества самого verifier'а, а не агента.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
sys.path.insert(0, TESTS_DIR)

import test_verifier as tv  # noqa: E402

# diff.txt лежит в пакете рядом с tests/, а в рантайме (tests примонтированы
# как /tests) — в /app. Проверяем обе раскладки, иначе тест падает с
# FileNotFoundError при запуске из собранного окружения.
_DIFF_CANDIDATES = (
    os.path.join(os.path.dirname(TESTS_DIR), "environment", "repo", "diff.txt"),
    os.path.join(tv.APP, "diff.txt"),
)
_REPO_DIFF = next(
    (p for p in _DIFF_CANDIDATES if os.path.isfile(p)), _DIFF_CANDIDATES[0]
)

_FORBIDDEN_IN_PARAPHRASE = ("pipe", "popen", "malloc", "null", "закры")


def _load_fixture(name):
    with open(os.path.join(HERE, name), "r", encoding="utf-8") as f:
        return json.load(f)


def _matched(data, specs):
    return [s["id"] for s in specs if tv._match_required(data, s) is not None]


# ── 1. копипаст лейбла без объяснения ────────────────────────────────────────

def test_keyword_soup_does_not_satisfy_required_findings():
    data = _load_fixture("negative_keyword_soup.json")
    matched = _matched(data, tv.REQUIRED_FINDINGS)
    assert not matched, (
        f"Matcher засчитал скопированные лейблы без причинного объяснения: {matched}"
    )


def test_keyword_soup_does_not_satisfy_alternatives():
    data = _load_fixture("negative_keyword_soup.json")
    matched = _matched(data, tv.ALTERNATIVE_FINDINGS)
    assert not matched, f"Matcher засчитал копипаст как альтернативный finding: {matched}"


# ── 2. общие и повторяющиеся объяснения ──────────────────────────────────────

def test_generic_explanations_do_not_satisfy_contract():
    data = _load_fixture("negative_generic_and_repeated.json")
    matched = _matched(data, tv.REQUIRED_FINDINGS) + _matched(data, tv.ALTERNATIVE_FINDINGS)
    assert not matched, (
        f"Matcher засчитал общее объяснение вида «может привести к ошибке»: {matched}"
    )


def test_bare_mozhet_is_not_a_causal_marker():
    """Регресс на конкретную дыру: одиночное «может» не должно считаться
    причинно-следственной связкой."""
    assert not tv._has_causal_link(
        "Здесь есть недостаток, который может привести к ошибке в работе.", "security"
    ), "«может привести к ошибке» ошибочно принято за причинную связку"


def test_repeated_detail_is_detectable():
    """В контрольном ответе есть две записи с дословно одинаковым detail —
    проверка уникальности объяснений обязана это увидеть."""
    data = _load_fixture("negative_generic_and_repeated.json")
    details = [tv._norm(f.get("detail", "")) for f in data["important_findings"]]
    assert len(details) != len(set(details)), (
        "Контрольная фикстура потеряла дублирующий detail — сценарий "
        "повторяющегося объяснения больше не проверяется"
    )


# ── 3-4. корректные рецензии обязаны проходить ───────────────────────────────

def test_synonymous_answer_satisfies_full_contract():
    for name in ("positive_synonymous.json", "positive_leak_paraphrase.json"):
        data = _load_fixture(name)

        matched_req = _matched(data, tv.REQUIRED_FINDINGS)
        missing = [s["id"] for s in tv.REQUIRED_FINDINGS if s["id"] not in matched_req]
        assert not missing, (
            f"{name}: verifier не засчитал корректные findings, сформулированные "
            f"синонимично: {missing}. Matcher слишком строг к формулировке."
        )

        matched_alt = _matched(data, tv.ALTERNATIVE_FINDINGS)
        assert len(matched_alt) >= tv.MIN_ALTERNATIVE_FINDINGS, (
            f"{name}: закрыто альтернативных findings {len(matched_alt)} "
            f"({matched_alt}), нужно >= {tv.MIN_ALTERNATIVE_FINDINGS}"
        )

        assert len(data["important_findings"]) >= tv.MIN_FINDINGS, (
            f"{name}: findings {len(data['important_findings'])}, "
            f"нужно >= {tv.MIN_FINDINGS}"
        )


def test_leak_paraphrase_avoids_reference_keywords():
    """Контрольная парафраза действительно не содержит ни одного слова, к которым
    matcher был привязан раньше — иначе тест ничего не доказывает."""
    data = _load_fixture("positive_leak_paraphrase.json")
    leak = [f for f in data["important_findings"] if f["category"] == "resource_leak"]
    assert leak, "В фикстуре нет записи с категорией resource_leak"
    text = tv._norm(leak[0]["finding"] + " " + leak[0]["detail"])
    hits = [w for w in _FORBIDDEN_IN_PARAPHRASE if w in text]
    assert not hits, (
        f"Парафраза содержит опорные слова {hits} — фикстура не проверяет "
        f"независимость matcher'а от конкретного набора keywords"
    )


# ── 5. фикстура не разъезжается с diff ───────────────────────────────────────

def test_valid_elements_actually_present_in_diff():
    with open(_REPO_DIFF, "r", encoding="utf-8") as f:
        diff = f.read()
    missing = [e for e in tv._SCHEMA["valid_elements"] if e not in diff]
    assert not missing, f"valid_elements содержит элементы, которых нет в diff: {missing}"


def test_spec_elements_and_categories_are_valid():
    bad_el = [
        s["id"] for s in (tv.REQUIRED_FINDINGS + tv.ALTERNATIVE_FINDINGS)
        if s["element"].lower() not in tv.VALID_ELEMENTS
    ]
    assert not bad_el, f"Спецификации ссылаются на элементы вне valid_elements: {bad_el}"

    bad_cat = [
        s["id"] for s in (tv.REQUIRED_FINDINGS + tv.ALTERNATIVE_FINDINGS)
        if not tv._spec_categories(s) <= {c.lower() for c in tv.VALID_CATEGORIES}
    ]
    assert not bad_cat, f"Спецификации ссылаются на категории вне valid_categories: {bad_cat}"
