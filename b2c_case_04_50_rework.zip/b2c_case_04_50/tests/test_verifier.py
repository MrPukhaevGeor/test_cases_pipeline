"""
Верификатор кейса b2c_case_04_50.
Агент пишет answer.json со структурированным анализом git diff (C).

Схема, допустимые элементы/категории/типы, пороги объёма, маркеры причинности,
обязательные и альтернативные findings загружаются ЕДИНОЖДЫ из неизменяемой
фикстуры /tests/fixtures/answer_schema.json (DRY — единственный источник правды,
никаких дублирующих констант в Python).

Контракт после раунда ревью:

1. Обязательными оставлены только те findings, которые ОДНОЗНАЧНО следуют из кода
   diff: непроверенный результат fread, утечка pipe при отказе malloc,
   непроверенный результат scanf и захардкоженный адрес сервиса.

   Убраны из обязательных (обоснование — notes_on_dropped_findings в фикстуре):
     - buffer overflow: длина итоговой строки детерминирована и в char[512] влезает;
     - SSRF: HTTP-запроса в коде нет вообще, url уходит в popen();
     - command injection / RCE: user_id имеет тип int, shell-метасимволы
       через scanf("%d") не проходят.

2. Формальное упоминание проблемы больше не закрывает контракт. Совпадение
   требует AND-группы ключевых слов, описывающей конкретную операцию и механику
   дефекта, И причинно-следственной связки из фиксированного списка маркеров.
   Из маркеров убрано одиночное «может»: именно оно пропускало общую фразу
   «может привести к ошибке». Дополнительно запрещено закрывать несколько разных
   findings одним и тем же скопированным объяснением.

3. Технически корректная парафраза больше не отклоняется. Группы ключевых слов
   расширены синонимичными формулировками (в частности для утечки ресурса:
   «поток остаётся открытым», «дескриптор не освобождается», «досрочный возврат»
   и т.п.), а сверх обязательных findings достаточно закрыть минимум один пункт
   из пула alternative_findings — правдоподобная альтернативная рецензия
   получает reward=1, не угадывая единственную «правильную» формулировку.
"""
import hashlib
import json
import os
import re

import pytest

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

DIFF_SHA256 = "a0a4d533e43e7d5d5e4765b58fbc305e8298e5b1d9fb569bd696aca74291c66a"
PROMPT_SHA256 = "5cd9dc460bdbefce709082f0e8e54196cc726c0f85cfff93b617878ac60d7c45"
SCHEMA_SHA256 = "345d349677e7e65d9ff3450915dad69159f3d5abe62f126e1d5fae0e7631ca48"

# Явный деньлист типовых заглушек/филлера — ловит самые дешёвые попытки
# сгенерировать формально проходящий, но бессодержательный текст. Эвристика,
# не полноценная проверка связности: основная защита от keyword-soup —
# отсутствие спойлерных формулировок в diff.txt плюс AND-группы + причинность.
_FILLER_DENYLIST = (
    "лорем", "ипсум", "lorem", "ipsum", "asdf", "qwerty",
    "todo", "n/a", "placeholder", "тест тест", "xxx", "ффф", "ггг", "ддд",
)


def _norm(s):
    return (s or "").strip().lower()


def _looks_like_filler(text):
    t = _norm(text)
    if any(bad in t for bad in _FILLER_DENYLIST):
        return True
    words = re.findall(r"\w+", t)
    if not words:
        return True
    if len(words) < 6:
        return False
    from collections import Counter
    counts = Counter(words)
    most_common_ratio = counts.most_common(1)[0][1] / len(words)
    return most_common_ratio > 0.4


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_schema():
    with open(FIXTURE, "r", encoding="utf-8") as f:
        return json.load(f)


_SCHEMA = _load_schema()
VALID_ELEMENTS = {e.lower() for e in _SCHEMA["valid_elements"]}
VALID_CATEGORIES = set(_SCHEMA["valid_categories"])
VALID_TYPES = set(_SCHEMA["valid_types"])
REQUIRED_IN_CHANGES = {e.lower() for e in _SCHEMA["required_elements_in_changes"]}
REQUIRED_FINDINGS = _SCHEMA["required_findings"]
ALTERNATIVE_FINDINGS = _SCHEMA["alternative_findings"]
CAUSAL_MARKERS = tuple(_SCHEMA["causal_markers"])
MIN_CHANGES = _SCHEMA["min_changes"]
MIN_FINDINGS = _SCHEMA["min_findings"]
MIN_ALTERNATIVE_FINDINGS = _SCHEMA["min_alternative_findings"]


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _has_causal_link(text, category):
    """Объяснение содержит причинно-следственную связку: при каком условии дефект
    срабатывает и к чему приводит.

    Для code_quality не требуется: структурные замечания (магическая строка
    конфигурации и т.п.) по своей природе не имеют сценария срабатывания.

    Одиночное «может» намеренно НЕ является маркером — общая фраза
    «может привести к ошибке» причинной связкой не является и контракт
    закрывать не должна.
    """
    if category == "code_quality":
        return True
    t = _norm(text)
    return any(m in t for m in CAUSAL_MARKERS)


def _spec_categories(spec):
    """Спецификация задаёт либо одну категорию, либо набор допустимых:
    для части замечаний таксономия объективно неоднозначна (например,
    выполнение url через оболочку можно отнести и к security, и к
    code_quality), и агент не обязан угадывать единственный вариант."""
    if "categories" in spec:
        return {c.lower() for c in spec["categories"]}
    return {spec["category"].lower()}


def _match_required(data, spec):
    """Спецификация засчитана, если найдена запись с совпадающим element и
    категорией из допустимого набора, чей текст (finding + detail) содержит ВСЕ
    ключевые слова хотя бы одной из групп keyword_groups (AND внутри группы,
    OR между группами) И (кроме code_quality) содержит причинно-следственную
    связку — иначе это скопированный лейбл без объяснения."""
    el = _norm(spec["element"])
    cats = _spec_categories(spec)
    groups = spec["keyword_groups"]
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        if _norm(f.get("element", "")) != el or cat not in cats:
            continue
        text = _norm(f.get("detail", "") + " " + f.get("finding", ""))
        if any(all(kw in text for kw in group) for group in groups):
            if _has_causal_link(f.get("detail", ""), cat):
                return f
    return None


def _spec_by_id(specs, spec_id):
    for s in specs:
        if s["id"] == spec_id:
            return s
    raise KeyError(spec_id)


# ── pass_to_pass ──────────────────────────────────────────────────────────────

def test_inputs_present_and_untouched():
    """PASS_TO_PASS: входные файлы существуют и не изменены агентом."""
    for fname, expected in (("diff.txt", DIFF_SHA256), ("system_prompt.txt", PROMPT_SHA256)):
        path = os.path.join(APP, fname)
        assert os.path.isfile(path), f"{fname} отсутствует в /app"
        assert _sha256(path) == expected, f"{fname} изменён агентом"


def test_fixture_schema_intact():
    """PASS_TO_PASS: фикстура схемы не изменена — хеш совпадает с ожидаемым."""
    assert os.path.isfile(FIXTURE), "Fixture схема не найдена в /tests/fixtures"
    assert _sha256(FIXTURE) == SCHEMA_SHA256, "Fixture схема изменена"


# ── fail_to_pass: базовая структура ──────────────────────────────────────────

def test_answer_file_exists():
    """FAIL_TO_PASS: answer.json создан."""
    assert os.path.isfile(ANSWER), "answer.json не найден в /app"


def test_answer_is_valid_json():
    """FAIL_TO_PASS: answer.json — валидный JSON."""
    try:
        _load()
    except json.JSONDecodeError as e:
        pytest.fail(f"answer.json содержит невалидный JSON: {e}")


def test_answer_has_required_fields():
    """FAIL_TO_PASS: answer.json содержит поля file, changes, important_findings."""
    data = _load()
    for field in ("file", "changes", "important_findings"):
        assert field in data, f"Отсутствует обязательное поле: {field}"
    assert isinstance(data["changes"], list), "changes должен быть массивом"
    assert isinstance(data["important_findings"], list), "important_findings должен быть массивом"


def test_file_field_mentions_c():
    """FAIL_TO_PASS: поле file содержит имя анализируемого файла (C)."""
    data = _load()
    fv = _norm(data.get("file", ""))
    assert "cpp" in fv or fv.endswith(".c") or "cpp.c" in fv, \
        f"Поле file не содержит имя C-файла: {data.get('file')}"


# ── fail_to_pass: секция changes ─────────────────────────────────────────────

def test_changes_minimum_count():
    """FAIL_TO_PASS: объём changes не ниже порога из фикстуры (порог продублирован
    в instruction.md и system_prompt.txt — скрытых порогов в кейсе нет)."""
    data = _load()
    assert len(data["changes"]) >= MIN_CHANGES, \
        f"changes содержит {len(data['changes'])} элементов, нужно >= {MIN_CHANGES}"


def test_changes_required_elements_present():
    """FAIL_TO_PASS: в changes упомянуты обязательные элементы (fetch_user_data,
    save_to_file, main, API_BASE_URL)."""
    data = _load()
    found = {_norm(c.get("element", "")) for c in data["changes"]}
    missing = REQUIRED_IN_CHANGES - found
    assert not missing, f"В changes отсутствуют обязательные элементы: {missing}"


def test_changes_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в changes реально существует в diff (не выдуман)."""
    data = _load()
    invalid = [c.get("element") for c in data["changes"]
               if _norm(c.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В changes есть элементы, отсутствующие в diff: {invalid}"


def test_changes_descriptions_substantive():
    """FAIL_TO_PASS: каждый description в changes содержателен (>30 символов,
    не копипаст имени элемента, минимум 4 уникальных слова)."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert len(desc) >= 30, f"description для '{el}' слишком короткий: {len(desc)} символов"
        assert _norm(desc) != _norm(el), f"description для '{el}' — копипаст имени элемента"
        words = re.findall(r"\w+", desc.lower())
        assert len(set(words)) >= 4, f"description для '{el}' содержит слишком мало уникальных слов"


def test_changes_type_field_valid():
    """FAIL_TO_PASS: поле type в каждом элементе changes — одно из допустимых значений."""
    data = _load()
    for c in data["changes"]:
        t = _norm(c.get("type", ""))
        assert t in VALID_TYPES, f"Недопустимый type '{c.get('type')}' для '{c.get('element')}'"


def test_changes_descriptions_not_filler():
    """FAIL_TO_PASS: description в changes не похож на заглушку/lorem-ipsum."""
    data = _load()
    for c in data["changes"]:
        el = c.get("element", "")
        desc = (c.get("description") or "").strip()
        assert not _looks_like_filler(desc), f"description для '{el}' похож на заглушку/филлер"


# ── fail_to_pass: секция important_findings ───────────────────────────────────

def test_findings_minimum_count():
    """FAIL_TO_PASS: объём important_findings не ниже порога из фикстуры."""
    data = _load()
    assert len(data["important_findings"]) >= MIN_FINDINGS, \
        f"important_findings содержит {len(data['important_findings'])} элементов, нужно >= {MIN_FINDINGS}"


def test_findings_categories_valid():
    """FAIL_TO_PASS: category в каждом finding — одно из допустимых значений."""
    data = _load()
    for f in data["important_findings"]:
        cat = _norm(f.get("category", ""))
        assert cat in VALID_CATEGORIES, \
            f"Недопустимая category '{f.get('category')}' для '{f.get('element')}'"


def test_findings_elements_exist_in_diff():
    """FAIL_TO_PASS: каждый element в important_findings существует в diff."""
    data = _load()
    invalid = [f.get("element") for f in data["important_findings"]
               if _norm(f.get("element", "")) not in VALID_ELEMENTS]
    assert not invalid, f"В important_findings есть несуществующие в diff элементы: {invalid}"


def test_findings_details_substantive():
    """FAIL_TO_PASS: каждый detail в findings содержателен (>40 символов,
    минимум 5 уникальных слов, не копипаст поля finding, не филлер/заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        detail = (f.get("detail") or "").strip()
        finding = (f.get("finding") or "").strip()
        assert len(detail) >= 40, f"detail для '{el}' слишком короткий: {len(detail)} символов"
        words = re.findall(r"\w+", detail.lower())
        assert len(set(words)) >= 5, f"detail для '{el}' содержит слишком мало уникальных слов"
        assert _norm(detail) != _norm(finding), f"detail для '{el}' — копипаст поля finding"
        assert not _looks_like_filler(detail), f"detail для '{el}' похож на заглушку/филлер"


def test_findings_finding_field_present():
    """FAIL_TO_PASS: поле finding в каждом important_finding непустое и
    содержательное (не заглушка)."""
    data = _load()
    for f in data["important_findings"]:
        el = f.get("element", "")
        finding = (f.get("finding") or "").strip()
        assert len(finding) >= 8, f"finding для '{el}' пустой или слишком короткий"
        assert not _looks_like_filler(finding), f"finding для '{el}' похож на заглушку/филлер"


def test_findings_no_duplicate_categories_per_element():
    """FAIL_TO_PASS: нет дублирующих находок (element, category, finding).
    Для fetch_user_data допустимо несколько записей с одной категорией (разные
    проблемы), поэтому уникальность проверяется по всей тройке."""
    data = _load()
    seen = set()
    for f in data["important_findings"]:
        key = (_norm(f.get("element", "")), _norm(f.get("category", "")), _norm(f.get("finding", "")))
        assert key not in seen, f"Дублирующая находка: {key}"
        seen.add(key)


def test_findings_have_distinct_details():
    """FAIL_TO_PASS: одно и то же объяснение не может закрывать несколько разных
    findings — повторяющийся detail означает generic-текст, скопированный между
    записями, а не разбор конкретных дефектов."""
    data = _load()
    seen = {}
    for f in data["important_findings"]:
        key = _norm(f.get("detail", ""))
        assert key not in seen, (
            f"detail записи для '{f.get('element')}' дословно повторяет detail "
            f"записи для '{seen[key]}' — одно объяснение скопировано между findings"
        )
        seen[key] = f.get("element")


# ── fail_to_pass: обязательные findings по контракту (данные из fixture) ──────

def test_finding_fread_unchecked_present():
    """FAIL_TO_PASS: fetch_user_data / error_handling — результат fread не
    проверяется, хвост буфера остаётся неинициализированным."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "fread_unchecked")
    assert _match_required(data, spec), \
        f"Нет finding: {spec['element']} / {spec['category']} / непроверенный результат чтения"


def test_finding_pipe_leak_on_malloc_fail_present():
    """FAIL_TO_PASS: fetch_user_data / resource_leak — после успешного popen()
    отказ malloc() приводит к возврату без закрытия потока."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "pipe_leak_on_malloc_fail")
    assert _match_required(data, spec), \
        f"Нет finding: {spec['element']} / {spec['category']} / утечка потока при отказе выделения памяти"


def test_finding_scanf_unchecked_present():
    """FAIL_TO_PASS: main / error_handling — результат scanf не проверяется."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "scanf_unchecked")
    assert _match_required(data, spec), \
        f"Нет finding: {spec['element']} / {spec['category']} / непроверенный результат считывания ввода"


def test_finding_api_base_url_hardcoded_present():
    """FAIL_TO_PASS: API_BASE_URL / code_quality — адрес сервиса зашит в код."""
    data = _load()
    spec = _spec_by_id(REQUIRED_FINDINGS, "api_base_url_hardcoded")
    assert _match_required(data, spec), \
        f"Нет finding: {spec['element']} / {spec['category']} / адрес сервиса зашит в исходный код"


def test_at_least_one_alternative_finding_present():
    """FAIL_TO_PASS: помимо обязательных findings ответ закрывает минимум
    MIN_ALTERNATIVE_FINDINGS пунктов из пула технически корректных альтернатив
    (выполнение url через оболочку в popen, небезопасный sink save_to_file,
    неограниченный sprintf). Пул — это то, что позволяет правдоподобной
    альтернативной рецензии получить reward=1."""
    data = _load()
    matched = [spec["id"] for spec in ALTERNATIVE_FINDINGS if _match_required(data, spec)]
    assert len(matched) >= MIN_ALTERNATIVE_FINDINGS, (
        f"Закрыто альтернативных findings: {len(matched)} ({matched}), "
        f"нужно >= {MIN_ALTERNATIVE_FINDINGS}. Допустимые варианты: "
        f"{[s['id'] for s in ALTERNATIVE_FINDINGS]}"
    )
