#!/bin/sh
set -e

cat > /app/answer.json << 'EOF'
{
  "file": "java.java",
  "changes": [
    {
      "element": "API_BASE_URL",
      "type": "variable",
      "description": "Публичное статическое поле, задающее базовый адрес сервиса, к которому обращаются методы класса при формировании сетевых запросов."
    },
    {
      "element": "fetchUserData",
      "type": "function",
      "description": "Функция получает данные пользователя по идентификатору: открывает сетевое соединение по URL и построчно считывает ответ сервера в строку."
    },
    {
      "element": "saveToFile",
      "type": "function",
      "description": "Функция записывает переданные данные в файл, имя которого формируется на основе входного параметра filename."
    },
    {
      "element": "main",
      "type": "function",
      "description": "Точка входа программы: считывает идентификатор пользователя с консоли, вызывает fetchUserData и передаёт результат в saveToFile."
    }
  ],
  "important_findings": [
    {
      "element": "fetchUserData",
      "category": "resource_leak",
      "finding": "Незакрытый поток чтения",
      "detail": "Открытый inputStream и связанный с ним Scanner не закрываются после использования, что приводит к утечке ресурсов при частых вызовах функции."
    },
    {
      "element": "fetchUserData",
      "category": "security",
      "finding": "SSRF через подстановку userId в URL",
      "detail": "Значение userId напрямую подставляется в формируемый URL без какой-либо проверки, что позволяет влиять на адрес запроса и организовать SSRF-атаку."
    },
    {
      "element": "saveToFile",
      "category": "security",
      "finding": "Path traversal при записи файла",
      "detail": "Имя файла строится из пользовательских данных без санитизации, поэтому специально подобранное значение позволяет выполнить path traversal и записать файл вне ожидаемой директории."
    },
    {
      "element": "API_BASE_URL",
      "category": "code_quality",
      "finding": "Нарушение инкапсуляции",
      "detail": "Поле объявлено как public static и может быть изменено из любого места программы, что нарушает инкапсуляцию и усложняет управление конфигурацией."
    },
    {
      "element": "main",
      "category": "error_handling",
      "finding": "Необработанное исключение при вводе",
      "detail": "Вызов nextInt() не обёрнут в try/catch, поэтому нечисловой ввод пользователя приведёт к необработанному исключению и аварийному завершению программы."
    }
  ]
}
EOF
