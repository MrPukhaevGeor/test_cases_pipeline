#!/bin/sh
set -e
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /tests
if python -P -m pytest /tests/test_verifier.py -p no:cacheprovider -q \
        > /logs/verifier/test.log 2>&1; then
    echo 1 > /logs/verifier/reward.txt
fi
