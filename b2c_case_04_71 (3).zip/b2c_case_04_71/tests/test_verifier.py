"""
Verifier for b2c_case_04_71 (error-analysis / code-review, structured output).

All checkable content (valid elements/categories/types, required findings,
keyword groups, length thresholds) is loaded from
/tests/fixtures/answer_schema.json — the single source of truth. Nothing here
is duplicated in Python, per onboarding §5.3 (DRY).

Only two constants live in this file: the expected sha256 hashes of the
immutable inputs (environment/repo/diff.txt, environment/repo/system_prompt.txt)
and of the fixture itself. These are pass_to_pass canaries, not part of the
task logic, so they are not schema data.
"""
import hashlib
import json
import os

import pytest

APP_DIR = "/app"
FIXTURES_DIR = "/tests/fixtures"
ANSWER_PATH = os.path.join(APP_DIR, "answer.json")
SCHEMA_PATH = os.path.join(FIXTURES_DIR, "answer_schema.json")

# sha256 of environment/repo/diff.txt, environment/repo/system_prompt.txt,
# and tests/fixtures/answer_schema.json. Computed and pinned as the LAST step
# of building this case, once file contents were final (§9 of onboarding doc).
EXPECTED_SHA256 = {
    "diff.txt": "a1cd35fe58a618c7ae7d2eebf208eadaade73a88a7eb01b75ec8c08187c21e6a",
    "system_prompt.txt": "bc343183cd1b16803354c8412af955665cbca0c7996a2ef214f24d14d74fb665",
    "answer_schema.json": "b4bd73256aa3d5982695d707767279e1c130fb45ecca19ea1857bc88aa145bec",
}


def _sha256(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def _load_schema():
    with open(SCHEMA_PATH, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _load_answer():
    """Returns (answer_or_None, error_or_None). Never raises."""
    if not os.path.exists(ANSWER_PATH):
        return None, "answer.json does not exist"
    try:
        with open(ANSWER_PATH, "r", encoding="utf-8") as fh:
            raw = fh.read()
    except OSError as exc:
        return None, f"could not read answer.json: {exc}"
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        return None, f"answer.json is not valid JSON: {exc}"
    return data, None


SCHEMA = _load_schema()
ANSWER, LOAD_ERROR = _load_answer()

# Element/category comparisons are case-insensitive: the verifier cares about
# semantic correctness, not exact capitalization. Sets below are the
# lowercased lookup tables; SCHEMA itself keeps its original casing for
# error messages and for display.
_VALID_ELEMENTS_LOWER = {e.lower() for e in SCHEMA["valid_elements"]}
_VALID_CATEGORIES_LOWER = {c.lower() for c in SCHEMA["valid_categories"]}
_VALID_TYPES_LOWER = {t.lower() for t in SCHEMA["valid_types"]}
_REQUIRED_ELEMENTS_LOWER = {e.lower() for e in SCHEMA["required_elements_in_changes"]}


def _norm(value):
    return value.strip().lower() if isinstance(value, str) else value


# ---------------------------------------------------------------------------
# pass_to_pass: inputs must not be tampered with by the agent
# ---------------------------------------------------------------------------

def test_diff_input_not_modified():
    path = os.path.join(APP_DIR, "diff.txt")
    assert os.path.exists(path), "diff.txt missing from /app"
    assert _sha256(path) == EXPECTED_SHA256["diff.txt"], \
        "diff.txt was modified — it must be used as-is, not edited"


def test_system_prompt_input_not_modified():
    path = os.path.join(APP_DIR, "system_prompt.txt")
    assert os.path.exists(path), "system_prompt.txt missing from /app"
    assert _sha256(path) == EXPECTED_SHA256["system_prompt.txt"], \
        "system_prompt.txt was modified — it must be used as-is, not edited"


def test_fixture_schema_not_modified():
    assert _sha256(SCHEMA_PATH) == EXPECTED_SHA256["answer_schema.json"], \
        "answer_schema.json fixture does not match the expected reference " \
        "(unreachable to the agent — this guards environment integrity)"


# ---------------------------------------------------------------------------
# fail_to_pass: the actual answer must be correct
# ---------------------------------------------------------------------------

def test_answer_json_present_and_parses():
    assert LOAD_ERROR is None, LOAD_ERROR


def test_answer_is_object_with_required_top_level_keys():
    assert LOAD_ERROR is None, LOAD_ERROR
    assert isinstance(ANSWER, dict), "answer.json must be a JSON object, not a list/scalar"
    for key in ("file", "changes", "important_findings"):
        assert key in ANSWER, f"answer.json missing required key '{key}'"
    assert isinstance(ANSWER["changes"], list), "'changes' must be a list"
    assert isinstance(ANSWER["important_findings"], list), "'important_findings' must be a list"


def _stripped_content_len(text, element):
    """Length of text after removing the element name and normalizing.
    Used to reject descriptions/details that are just the element name
    repeated to pad out the character-count minimum."""
    if not isinstance(text, str):
        return 0
    lowered = text.lower()
    for variant in {element.lower(), element.lower().replace("_", " ")}:
        lowered = lowered.replace(variant, "")
    return len(lowered.strip())


def _is_placeholder(text):
    if not isinstance(text, str):
        return True
    norm = text.strip().lower()
    if norm in SCHEMA["placeholder_blacklist"]:
        return True
    if " " not in norm.strip():
        return True
    if len(set(norm.replace(" ", ""))) < 3:
        return True
    return False


def test_changes_section_valid():
    assert LOAD_ERROR is None, LOAD_ERROR
    changes = ANSWER.get("changes", [])
    assert len(changes) > 0, "'changes' must not be empty"

    seen_elements = set()
    for entry in changes:
        assert isinstance(entry, dict), "each 'changes' entry must be an object"
        for key in ("element", "type", "description"):
            assert key in entry, f"changes entry missing '{key}'"

        element = entry["element"]
        assert isinstance(element, str), f"changes entry 'element' must be a string, got {element!r}"
        assert _norm(element) in _VALID_ELEMENTS_LOWER, \
            f"changes references unknown element '{element}' (not present in the diff)"
        assert isinstance(entry["type"], str) and _norm(entry["type"]) in _VALID_TYPES_LOWER, \
            f"invalid type '{entry['type']}' for element '{element}'"

        description = entry["description"]
        assert isinstance(description, str) and len(description) >= SCHEMA["min_description_len"], \
            f"description for '{element}' is too short"
        assert not _is_placeholder(description), \
            f"description for '{element}' looks like a placeholder"
        assert _stripped_content_len(description, element) >= SCHEMA["min_description_len"] - 10, \
            f"description for '{element}' is mostly just the element name repeated"

        seen_elements.add(_norm(element))

    missing = _REQUIRED_ELEMENTS_LOWER - seen_elements
    assert not missing, f"changes is missing required elements: {sorted(missing)}"


def test_important_findings_valid_and_not_padded():
    assert LOAD_ERROR is None, LOAD_ERROR
    findings = ANSWER.get("important_findings", [])
    assert len(findings) > 0, "'important_findings' must not be empty"

    seen_pairs = []
    for entry in findings:
        assert isinstance(entry, dict), "each finding must be an object"
        for key in ("element", "category", "finding", "detail"):
            assert key in entry, f"finding missing '{key}'"

        element = entry["element"]
        category = entry["category"]
        assert isinstance(element, str), f"finding 'element' must be a string, got {element!r}"
        assert _norm(element) in _VALID_ELEMENTS_LOWER, \
            f"finding references unknown element '{element}'"
        assert isinstance(category, str) and _norm(category) in _VALID_CATEGORIES_LOWER, \
            f"invalid category '{category}' for element '{element}'"

        finding_label = entry["finding"]
        detail = entry["detail"]
        assert not _is_placeholder(finding_label), \
            f"finding label for '{element}' looks like a placeholder"
        assert isinstance(detail, str) and len(detail) >= SCHEMA["min_detail_len"], \
            f"detail for '{element}'/'{category}' is too short"
        assert not _is_placeholder(detail), \
            f"detail for '{element}'/'{category}' looks like a placeholder"
        assert _stripped_content_len(detail, element) >= SCHEMA["min_detail_len"] - 10, \
            f"detail for '{element}' is mostly just the element name repeated"

        # duplicate detection: exact repeats of the same (element, category, detail)
        norm_key = (_norm(element), _norm(category), detail.strip().lower())
        assert norm_key not in seen_pairs, \
            f"duplicate finding for '{element}'/'{category}'"
        seen_pairs.append(norm_key)


def _text_matches_any_group(text, keyword_groups):
    lowered = text.lower()
    for group in keyword_groups:
        if all(word.lower() in lowered for word in group):
            return True
    return False


def test_all_required_findings_are_matched():
    """
    For each required finding in the fixture, at least one entry in
    important_findings must have the correct element AND category AND
    satisfy at least one AND-keyword-group. This rejects:
      - keyword dumps not attached to the right element/category
      - findings attributed to the wrong element
      - missing findings entirely
    while still accepting any phrasing that satisfies a keyword group,
    including alternatives that don't use the literal reference term.
    """
    assert LOAD_ERROR is None, LOAD_ERROR
    findings = ANSWER.get("important_findings", [])
    assert isinstance(findings, list)

    unmatched = []
    for required in SCHEMA["required_findings"]:
        req_element = _norm(required["element"])
        req_category = _norm(required["category"])
        candidates = [
            f for f in findings
            if isinstance(f, dict)
            and _norm(f.get("element")) == req_element
            and _norm(f.get("category")) == req_category
        ]
        matched = any(
            _text_matches_any_group(
                f"{f.get('finding', '')} {f.get('detail', '')}",
                required["keyword_groups"],
            )
            for f in candidates
        )
        if not matched:
            unmatched.append(required["id"])

    assert not unmatched, f"required findings not satisfied: {unmatched}"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-q"]))
