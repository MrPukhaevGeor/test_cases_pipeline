#!/usr/bin/env python3
"""
bkas — конвейер корзин БКАС. Один файл, только стандартная библиотека.

Собран под закрытый контур: нет интернета, нет PyPI, нет Docker Hub, нет прав
ставить пакеты, Python может быть старым. Всё, что требует сети или Docker,
либо берётся из конфига, либо честно отказывается работать — но никогда не
подставляет молча правдоподобный мусор.

Требования: Python 3.8+, стандартная библиотека. pytest нужен только для
прогона верификатора (он и так нужен самим кейсам).

Команды:
    doctor              что доступно в этом окружении
    new                 каркас кейса
    finalize            контракт из схемы, sha256, task.toml
    validate            соответствие стандарту БКАС
    mutate              корпус контрольных ответов
    eval                различает ли кейс верное от неверного
    emulate             прогнать test.sh без Docker: те же флаги, тот же reward
    run                 validate + mutate + eval (+ emulate) одной командой

Настройка окружения: bkas.config.json рядом с этим файлом.
См. `python bkas.py doctor` и `python bkas.py config --example`.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from pathlib import Path

VERSION = "1.0"
HERE = Path(__file__).resolve().parent
# BKAS_CONFIG позволяет прогнать тесты на отдельном конфиге, не трогая рабочий.
CONFIG_PATH = Path(os.environ.get("BKAS_CONFIG") or (HERE / "bkas.config.json"))

# --------------------------------------------------------------------------- #
# Конфигурация окружения
# --------------------------------------------------------------------------- #

DEFAULT_CONFIG = {
    "_comment": [
        "Настройки контура. Без них генератор не подставляет ничего по умолчанию:",
        "образ из публичного реестра внутри Сбера всё равно не разрешится, а тихая",
        "подстановка правдоподобного значения — это то, за что заворачивают.",
        "",
        "base_image обязан быть с дайджестом (@sha256:...). Если его нет, генератор",
        "попробует разрешить тег через docker, а если docker недоступен — откажется.",
    ],
    "registry": "",
    "base_image": "",
    "platform": "linux/amd64",
    "pip_index_url": "",
    "pip_trusted_host": "",
    "team": "b2c-team",
    "docker_binary": "docker",
    "python_in_image": "python3",
}


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.is_file():
        try:
            user = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            cfg.update({k: v for k, v in user.items() if not k.startswith("_")})
        except Exception as exc:  # noqa: BLE001
            print(f"[!] bkas.config.json не читается: {exc}", file=sys.stderr)
    return cfg


# --------------------------------------------------------------------------- #
# Минимальный TOML-ридер
# --------------------------------------------------------------------------- #
# tomllib появился только в 3.11, tomli в контуре может не быть. Нам нужен
# узкий поднабор: секции, строки, числа, булевы, массивы строк. Полный TOML
# здесь не нужен и тащить его неоткуда.

_KV_RE = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
_SECTION_RE = re.compile(r'^\s*\[([A-Za-z_][A-Za-z0-9_.]*)\]\s*$')


def _toml_scalar(raw: str):
    raw = raw.strip()
    if raw.startswith('"') and raw.endswith('"') and len(raw) >= 2:
        return raw[1:-1]
    if raw.startswith("'") and raw.endswith("'") and len(raw) >= 2:
        return raw[1:-1]
    if raw in ("true", "false"):
        return raw == "true"
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    return raw


def parse_toml(text: str) -> dict:
    """Поднабор TOML, достаточный для task.toml. Не полноценный парсер."""
    root: dict = {}
    section = root
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        i += 1
        if not stripped or stripped.startswith("#"):
            continue

        m = _SECTION_RE.match(line)
        if m:
            section = root
            for part in m.group(1).split("."):
                section = section.setdefault(part, {})
            continue

        m = _KV_RE.match(line)
        if not m:
            continue
        key, raw = m.group(1), m.group(2)

        if raw.startswith("["):
            # массив, возможно многострочный
            buf = raw
            while buf.count("[") > buf.count("]") and i < len(lines):
                buf += " " + lines[i].strip()
                i += 1
            inner = buf[buf.index("[") + 1: buf.rindex("]")]
            items = []
            for chunk in re.findall(r'"([^"]*)"|\'([^\']*)\'', inner):
                items.append(chunk[0] or chunk[1])
            if not items:
                items = [_toml_scalar(c) for c in inner.split(",") if c.strip()]
            section[key] = items
        else:
            if raw.startswith("{"):
                continue  # inline-таблицы нам не нужны
            section[key] = _toml_scalar(raw)
    return root


# --------------------------------------------------------------------------- #
# Общее
# --------------------------------------------------------------------------- #

def sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except (OSError, UnicodeError):
        return ""


def find_case_roots(start: Path, max_depth: int = 3) -> list:
    """Каталоги с task.toml на самом мелком уровне, где они есть.

    Архив обычно распаковывается в лишнюю вложенную папку, поэтому ищем вглубь.
    """
    if (start / "task.toml").is_file():
        return [start]
    level = [start] if start.is_dir() else []
    for _ in range(max_depth):
        found, nxt = [], []
        for d in level:
            try:
                children = sorted(c for c in d.iterdir() if c.is_dir())
            except OSError:
                continue
            for child in children:
                (found if (child / "task.toml").is_file() else nxt).append(child)
        if found:
            return found
        level = nxt
    return []


def find_case_root(start: Path) -> Path:
    roots = find_case_roots(start)
    return roots[0] if len(roots) == 1 else start


def import_matcher(case: Path):
    """Матчер вендорится в кейс — берём его оттуда, не из внешнего места."""
    vendored = case / "tests" / "bkas_matcher.py"
    target = vendored if vendored.is_file() else (HERE / "bkas_matcher.py")
    if not target.is_file():
        return None
    import importlib.util
    spec = importlib.util.spec_from_file_location("bkas_matcher", target)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# --------------------------------------------------------------------------- #
# doctor
# --------------------------------------------------------------------------- #

def cmd_doctor(args) -> int:
    cfg = load_config()
    print(f"bkas {VERSION}\n")

    ok = True
    print("окружение")
    v = sys.version_info
    py_ok = v >= (3, 8)
    print(f"  [{'ok' if py_ok else '!!'}] python {v.major}.{v.minor}.{v.micro}"
          f"{'' if py_ok else '  — нужен 3.8+'}")
    ok &= py_ok

    try:
        import pytest  # noqa: F401
        print(f"  [ok] pytest доступен")
        has_pytest = True
    except ImportError:
        print("  [!!] pytest не найден — режим eval --mode fast не поедет")
        has_pytest = False

    docker = shutil.which(cfg["docker_binary"])
    if docker:
        p = subprocess.run([cfg["docker_binary"], "info", "--format", "{{.ServerVersion}}"],
                           capture_output=True, text=True)
        if p.returncode == 0:
            print(f"  [ok] docker работает, сервер {p.stdout.strip()}")
            docker_ok = True
        else:
            print("  [~ ] docker установлен, демон не отвечает — "
                  "eval --mode docker недоступен")
            docker_ok = False
    else:
        print("  [~ ] docker не найден — доступен только режим fast")
        docker_ok = False

    print("\nконфигурация контура")
    if not CONFIG_PATH.is_file():
        print(f"  [~ ] {CONFIG_PATH.name} отсутствует — "
              f"создать: python bkas.py config --example")
    for key, why in (("registry", "внутренний docker-реестр"),
                     ("base_image", "базовый образ с дайджестом"),
                     ("pip_index_url", "внутренний индекс пакетов")):
        val = cfg.get(key, "")
        if val:
            print(f"  [ok] {key} = {val}")
        else:
            print(f"  [~ ] {key} не задан ({why})")

    if cfg.get("base_image") and "@sha256:" not in cfg["base_image"]:
        print("  [!!] base_image без дайджеста — генератор откажется его использовать")
        ok = False

    print("\nмодель (bkas.py draft)")
    llm_ok = False
    try:
        import bkas_llm
        bkas_llm.load_dotenv(HERE / ".env")
        bkas_llm.load_dotenv(Path.cwd() / ".env")
        llm = bkas_llm.resolve_llm(cfg.get("llm") or {}, {})
        has_key = bool(os.environ.get(llm["key_env"]))
        print(f"  [ok] {llm['preset']}: {llm['model']} @ {bkas_llm.host_of(llm['base_url'])}")
        print(f"  [{'ok' if has_key else '~ '}] ключ {llm['key_env']} "
              f"{'задан' if has_key else 'не задан (в .env или окружении)'}")
        if not bkas_llm.is_trusted_host(llm["base_url"]):
            print("  [!!] адрес вне облака Сбера: исходники кейсов уйдут во внешний сервис")
        llm_ok = has_key
    except Exception as exc:  # noqa: BLE001
        print(f"  [!!] модуль bkas_llm не загружается: {exc}")

    print("\nчто можно делать сейчас")
    print(f"  new / finalize   {'да' if ok else 'нет'}")
    print(f"  draft            {'да' if llm_ok else 'нет, нужен ключ модели'}")
    print(f"  validate         да (никогда ничего не требует)")
    print(f"  mutate           да")
    print(f"  eval --mode fast {'да' if has_pytest else 'нет, нужен pytest'}")
    print(f"  eval --mode docker {'да' if docker_ok else 'нет'}")
    return 0


def cmd_config(args) -> int:
    if args.example:
        example = dict(DEFAULT_CONFIG)
        example["registry"] = "docker-registry.internal.example/base"
        example["base_image"] = ("docker-registry.internal.example/base/"
                                 "python:3.11.9-slim@sha256:<подставить>")
        example["pip_index_url"] = "https://nexus.internal.example/repository/pypi/simple"
        example["pip_trusted_host"] = "nexus.internal.example"
        if CONFIG_PATH.exists() and not args.force:
            print(f"{CONFIG_PATH} уже существует (--force чтобы перезаписать)",
                  file=sys.stderr)
            return 2
        CONFIG_PATH.write_text(json.dumps(example, ensure_ascii=False, indent=2),
                               encoding="utf-8")
        print(f"создан {CONFIG_PATH}\nзаполни registry, base_image и pip_index_url "
              f"значениями контура")
        return 0
    print(json.dumps(load_config(), ensure_ascii=False, indent=2))
    return 0


# --------------------------------------------------------------------------- #
# validate
# --------------------------------------------------------------------------- #

BLOCKER, WARN, INFO = "BLOCKER", "WARN", "INFO"

FAMILY = {
    "A": "A · верификатор принимает заведомо неверный ответ",
    "B": "B · верификатор отклоняет корректный по неопубликованным правилам",
    "C": "C · эталон требует недоказанного",
    "D": "D · сборка невоспроизводима",
    "E": "E · метаданные и разделение пакетов",
    "S": "S · структура пакета",
}

PLACEHOLDER_RE = re.compile(
    r"^\s*(todo|tbd|fixme|xxx+|placeholder|none|null|n/?a|nope|заполнить|\?+|-+|\.\.\.)\s*$",
    re.IGNORECASE)

REQUIRED_METADATA = ["task_type", "bank_domain", "language", "build_tool",
                     "difficulty", "source", "team"]

LANGUAGE_HINTS = {
    "c": [".c", ".h"], "cpp": [".cpp", ".cc", ".hpp"], "csharp": [".cs"],
    "c#": [".cs"], "java": [".java"], "javascript": [".js", ".mjs"],
    "typescript": [".ts"], "python": [".py"], "go": [".go"], "rust": [".rs"],
}

EVIDENCE_MARKERS = ["evidence", "reward.txt", "pytest.log", "docker_build.log",
                    "trajectory", "result.json"]

# Служебный мусор: в пакет задачи не входит. Чек-лист УМР требует отсутствия
# логов и cache, а __pycache__ появляется сам после первого же прогона тестов.
JUNK_MARKERS = ["__pycache__", ".pytest_cache", ".ds_store", "thumbs.db",
                ".idea/", ".vscode/", "node_modules/", ".git/"]

NET_AT_VERIFY = re.compile(
    r"\b(curl|wget|pip\s+install|npm\s+install|npm\s+ci|apt-get\s+install|go\s+get|mvn\s+)\b")


class Report:
    def __init__(self, case):
        self.case = case
        self.findings = []

    def add(self, family, level, code, message, where="", basis=""):
        self.findings.append({"family": family, "level": level, "code": code,
                              "message": message, "where": where, "basis": basis})

    @property
    def blockers(self):
        return [f for f in self.findings if f["level"] == BLOCKER]


def _check_structure(root: Path, rep: Report) -> None:
    if not (root / "task.toml").exists() and not any(
            (root / d).is_dir() for d in ("environment", "tests", "solution")):
        rep.add("S", BLOCKER, "S-NOT-A-CASE",
                f"`{root}` не похож на кейс: нет task.toml и стандартных папок "
                f"(искал до 3 уровней вглубь). Проверьте путь.", str(root))
        return
    for rel, what in (("task.toml", "дескриптор кейса"),
                      ("instruction.md", "инструкция агента"),
                      ("environment/Dockerfile", "сборка окружения"),
                      ("solution/solve.sh", "эталонное решение"),
                      ("tests/test.sh", "точка входа верификатора")):
        if not (root / rel).exists():
            rep.add("S", BLOCKER, "S-MISSING", f"нет `{rel}` ({what})", rel)

    for rel in ("tests/test.sh", "solution/solve.sh"):
        p = root / rel
        if p.is_file() and not os.access(p, os.X_OK):
            rep.add("S", WARN, "S-EXEC-BIT",
                    f"`{rel}` без executable bit — при упаковке в ZIP права теряются",
                    rel, "замечания УМР по 04_38, 04_36, 02_14, 02_04, 04_48")

    # CRLF в shell-скрипте: в Linux-контейнере он не запускается вовсе
    # («set: Illegal option -», «Syntax error: word unexpected (expecting "do")»).
    # Появляется сам, если кейс собран или упакован на Windows.
    for p in sorted(root.rglob("*.sh")):
        if p.is_file() and b"\r\n" in p.read_bytes():
            rel = p.relative_to(root).as_posix()
            rep.add("S", BLOCKER, "S-CRLF",
                    f"`{rel}` с переводами строк CRLF: в Linux-контейнере не запустится. "
                    f"Переведите в LF (в VS Code: CRLF справа внизу -> LF).",
                    rel, "найдено при прогоне в Docker")

    for p in root.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        if any(m in rel.lower() for m in JUNK_MARKERS):
            rep.add("S", WARN, "S-JUNK",
                    f"служебный файл `{rel}` в пакете задачи", rel,
                    "чек-лист УМР: без логов, cache и служебных артефактов")
            continue
        if any(m in rel.lower() for m in EVIDENCE_MARKERS):
            rep.add("E", BLOCKER, "E-EVIDENCE-IN-TASK",
                    f"материал прогона `{rel}` внутри пакета задачи", rel,
                    "02_11-F002, BKAS-3-TASK-EVIDENCE-SEPARATION")

    repo = root / "environment" / "repo"
    if repo.is_dir():
        for p in repo.rglob("*"):
            if not p.is_file():
                continue
            n = p.name.lower()
            if "test" in n or n in ("solve.sh", "answer.json", "expected.json"):
                rep.add("S", BLOCKER, "S-LEAK",
                        f"`{p.relative_to(root).as_posix()}` в стартовом коде агента",
                        p.relative_to(root).as_posix())


def _check_metadata(root: Path, rep: Report) -> None:
    tp = root / "task.toml"
    if not tp.is_file():
        return
    try:
        data = parse_toml(read(tp))
    except Exception as exc:  # noqa: BLE001
        rep.add("E", BLOCKER, "E-TOML-PARSE", f"task.toml не разбирается: {exc}",
                "task.toml")
        return

    meta = data.get("metadata", {}) or {}
    for key in REQUIRED_METADATA:
        val = meta.get(key)
        if val is None:
            rep.add("E", BLOCKER, "E-META-MISSING",
                    f"нет обязательного поля `metadata.{key}`", "task.toml",
                    "методичка УМР")
        elif isinstance(val, str) and (not val.strip() or PLACEHOLDER_RE.match(val)):
            rep.add("E", BLOCKER, "E-META-PLACEHOLDER",
                    f"`metadata.{key} = {val!r}` — placeholder, а не значение",
                    "task.toml", "02_11-F003, BKAS-2.3-MANDATORY-BANK-DOMAIN")

    bd = str(meta.get("bank_domain", "")).strip().lower()
    if bd in ("code-review", "codereview", "code_review", "review", "agentic", "backend"):
        rep.add("E", BLOCKER, "E-BANK-DOMAIN-NOT-DOMAIN",
                f"`bank_domain = {meta.get('bank_domain')!r}` — паттерн задачи, "
                f"а не банковский домен", "task.toml", "02_11-F003")

    lang = str(meta.get("language", "")).strip().lower()
    if lang:
        hints = LANGUAGE_HINTS.get(lang)
        if hints is None:
            rep.add("E", WARN, "E-LANG-UNKNOWN",
                    f"`language = {lang!r}` не распознан", "task.toml", "04_50-F007")
        else:
            repo = root / "environment" / "repo"
            files = [p for p in repo.rglob("*") if p.is_file()] if repo.is_dir() else []
            by_name = any(p.name.lower().endswith(tuple(hints)) for p in files)
            by_content = any(
                any(h in read(p).lower() for h in hints) for p in files
                if p.suffix.lower() in (".txt", ".diff", ".patch", ".md", "")
                and p.stat().st_size < 2_000_000)
            if files and not by_name and not by_content:
                rep.add("E", BLOCKER, "E-LANG-MISMATCH",
                        f"`language = {lang!r}`, но в repo нет файлов {hints}",
                        "task.toml", "04_50-F007")

    src = str(meta.get("source", "")).strip()
    stem = root.name.lower().replace("-main", "").replace("_", "")
    if src and stem and stem in src.lower().replace("_", ""):
        rep.add("E", WARN, "E-SOURCE-SELF",
                f"`source = {src!r}` ссылается на сам кейс; ожидается "
                f"internal-jira/XXX или ссылка на PR", "task.toml")

    env = data.get("environment", {}) or {}
    if env.get("allow_internet") is True:
        rep.add("D", BLOCKER, "D-INTERNET-ALLOWED",
                "`allow_internet = true` — для verifier-тестов стандарт требует false",
                "task.toml")
    if "network_mode" in env:
        rep.add("E", WARN, "E-HARBOR-NOTATION",
                "`network_mode` — Harbor-нотация; стандарт БКАС требует allow_internet",
                "task.toml")

    f2p = meta.get("fail_to_pass") or data.get("fail_to_pass") or []
    p2p = meta.get("pass_to_pass") or data.get("pass_to_pass") or []
    if isinstance(f2p, list) and len(f2p) < 8:
        rep.add("B", WARN, "B-TOO-FEW-F2P",
                f"всего {len(f2p)} fail_to_pass; в скоринге УМР было 23 и 26 проверок",
                "task.toml")
    if isinstance(p2p, list) and not p2p:
        rep.add("B", WARN, "B-NO-P2P", "нет pass_to_pass", "task.toml")


def _check_build(root: Path, rep: Report) -> None:
    df = root / "environment" / "Dockerfile"
    if not df.is_file():
        return
    text = read(df)

    for m in re.finditer(r"^\s*FROM\s+((?:--\S+\s+)*)(\S+)", text,
                         re.MULTILINE | re.IGNORECASE):
        image = m.group(2)
        if "@sha256:" not in image:
            rep.add("D", BLOCKER, "D-MUTABLE-BASE",
                    f"базовый образ `{image}` задан изменяемым тегом без дайджеста",
                    "environment/Dockerfile",
                    "04_50-F006, 04_47-F005, 02_11-F004, BKAS-2.2-DEPENDENCY-FIXATION")
        if not re.search(r"--platform", text, re.IGNORECASE):
            rep.add("D", WARN, "D-NO-PLATFORM", "не задана целевая платформа",
                    "environment/Dockerfile", "04_50-F006")
        break

    for m in re.finditer(r"apt-get\s+install[^\n]*", text, re.IGNORECASE):
        if "=" not in m.group(0):
            rep.add("D", BLOCKER, "D-APT-UNPINNED",
                    "`apt-get install` без фиксации версий", "environment/Dockerfile",
                    "04_47-F005")
            break

    if re.search(r"pip\s+install", text, re.IGNORECASE):
        closure = bool(re.search(r"--no-deps", text, re.IGNORECASE))
        hashes = bool(re.search(r"--require-hashes", text, re.IGNORECASE))
        from_file = bool(re.search(r"-r\s+\S+", text))
        if not (closure and from_file):
            rep.add("D", BLOCKER, "D-PIP-UNPINNED",
                    "pip фиксирует только прямые зависимости; нужен файл с полным "
                    "транзитивным замыканием и --no-deps", "environment/Dockerfile",
                    "04_50-F006")
        elif not hashes:
            rep.add("D", INFO, "D-PIP-NO-HASHES", "нет --require-hashes",
                    "environment/Dockerfile")

    if re.search(r"npm\s+install", text, re.IGNORECASE):
        rep.add("D", BLOCKER, "D-NPM-INSTALL",
                "`npm install` вместо `npm ci` — состав пакетов не воспроизводится",
                "environment/Dockerfile", "замечание УМР по 02_14 п.4")

    ts = root / "tests" / "test.sh"
    if ts.is_file():
        m = NET_AT_VERIFY.search(read(ts))
        if m:
            rep.add("D", BLOCKER, "D-NET-AT-VERIFY",
                    f"`tests/test.sh` вызывает `{m.group(0).strip()}` — установка "
                    f"зависимостей на этапе проверки запрещена", "tests/test.sh",
                    "04_50-F006")


def _verifier_sources(root: Path):
    tests = root / "tests"
    if not tests.is_dir():
        return []
    return [p for p in tests.rglob("*")
            if p.is_file() and p.suffix in (".py", ".js", ".java", ".ts")
            and p.name != "bkas_matcher.py"]


def _check_verifier(root: Path, rep: Report) -> None:
    srcs = _verifier_sources(root)
    if not srcs:
        return
    joined = {p: read(p) for p in srcs}
    all_text = "\n".join(joined.values())
    rel = lambda p: p.relative_to(root).as_posix()  # noqa: E731

    # Матчер вынесен в библиотеку — семейство A закрыто по построению.
    if (root / "tests" / "bkas_matcher.py").is_file() and "bkas_matcher" in all_text:
        return

    matching = bool(
        re.search(r"answer\.(json|txt)", all_text + read(root / "instruction.md"))
        and re.search(r"(keyword|ключев|finding|required_|обязательн)", all_text, re.I))

    if matching:
        substring = bool(re.search(r"\bin\s+(desc|description|detail|text|answer|expl)",
                                   all_text)
                         or re.search(r"\.(includes|indexOf|contains)\s*\(", all_text))
        polarity = any(m in all_text.lower() for m in
                       ("не может", "нет утечки", "отрицан", "безопасен", "denial",
                        "polarity", "не нужн"))
        if substring and not polarity:
            rep.add("A", BLOCKER, "A-NO-POLARITY",
                    "сопоставление по вхождению подстроки без проверки полярности: "
                    "отрицание «не может» содержит «может»",
                    ", ".join(rel(p) for p in srcs),
                    "04_50-F001, 04_47-F002, BKAS-2.5-VERIFIER-CORRECTNESS")

        if not any(m in all_text.lower() for m in
                   ("pop(", "remove(", "discard(", "consumed", "owner", "assignment",
                    "один к одному", "one-to-one")):
            rep.add("A", BLOCKER, "A-NO-ONE-TO-ONE",
                    "совпадения не расходуются один к одному: сборная запись закроет "
                    "несколько обязательных меток",
                    ", ".join(rel(p) for p in srcs), "04_50-F001")

        if re.search(r"[\"']file[\"']", all_text) and not (
                re.search(r"[\"']file[\"']\s*\]?\s*==", all_text)
                or re.search(r"\bvalue\s+in\s*\(", all_text)
                or re.search(r"ANALYZED_FILE", all_text)):
            rep.add("A", BLOCKER, "A-FILE-NOT-VERIFIED",
                    "поле `file` не сверяется с анализируемым файлом",
                    ", ".join(rel(p) for p in srcs), "04_50-F001")

        if (re.search(r"len\s*\(\s*\w*(desc|detail|text|expl)\w*\s*\)\s*[<>]=?\s*\d+",
                      all_text)
                or re.search(r"\.split\(\s*\)\s*\)?\s*[<>]=?\s*\d+", all_text)):
            rep.add("A", WARN, "A-LENGTH-AS-QUALITY",
                    "содержательность описания оценивается длиной или числом слов — "
                    "осмысленности это не проверяет",
                    ", ".join(rel(p) for p in srcs), "04_47-F002")

    for p, t in joined.items():
        if re.search(r"\b(Math\.random|random\.(random|randint|choice)|uuid4)\b", t):
            rep.add("A", BLOCKER, "A-NONDETERMINISTIC",
                    "верификатор использует случайность", rel(p),
                    "замечание УМР по 02_14 п.1")
            break


def _check_hidden_rules(root: Path, rep: Report) -> None:
    visible = (read(root / "instruction.md") + "\n").lower()
    for cand in (root / "environment" / "repo" / "system_prompt.txt",
                 root / "tests" / "fixtures" / "system_prompt.txt"):
        if cand.is_file():
            visible += read(cand).lower()
    if not visible.strip():
        return

    COLLECTION = (r"(?:findings|changes|records|items|entries|results|issues|"
                  r"remarks|elements|answers|list|arr|rows)")
    spelled = {2: "дв", 3: "тр", 4: "четыр", 5: "пят", 6: "шест", 7: "сем",
               8: "восем", 9: "девят", 10: "десят"}

    for p in _verifier_sources(root):
        text = read(p)
        thresholds = set()
        for m in re.finditer(
                r"len\s*\(\s*[\w.\[\]\"']*" + COLLECTION + r"[\w.\[\]\"']*\s*\)"
                r"\s*(?:>=|>|==)\s*(\d+)|"
                r"[\w.]*" + COLLECTION + r"[\w.]*\.length\s*(?:>=|>|==)\s*(\d+)",
                text, re.IGNORECASE):
            num = next((g for g in m.groups() if g and g.isdigit()), None)
            if num and int(num) > 1:
                thresholds.add(int(num))
        for n in sorted(thresholds):
            words = [str(n)] + ([spelled[n]] if n in spelled else [])
            if not any(w in visible for w in words):
                rep.add("B", BLOCKER, "B-HIDDEN-THRESHOLD",
                        f"верификатор требует порог {n}, не объявленный в видимом "
                        f"контракте", p.relative_to(root).as_posix(),
                        "04_50-F003, 04_47-F003")


def _check_corpus(root: Path, rep: Report) -> None:
    if not any(list(root.rglob(pat)) for pat in
               ("*mutant*", "*cheat*", "*control*", "*paraphrase*", "eval/corpus")):
        rep.add("A", WARN, "A-NO-CONTROL-CORPUS",
                "нет корпуса контрольных ответов — семантическая корректность "
                "верификатора не проверяется ничем, кроме nop/oracle",
                basis="04_50-F001 «как будет проверено»")


def validate(path: Path) -> Report:
    roots = find_case_roots(path)
    if len(roots) > 1:
        # Угадывать нельзя: проверили бы случайный кейс и выдали его за результат.
        rep = Report(path.name)
        names = ", ".join(r.name for r in roots[:4]) + (" ..." if len(roots) > 4 else "")
        rep.add("S", BLOCKER, "S-AMBIGUOUS",
                f"по этому пути найдено кейсов: {len(roots)} ({names}). Укажите один.",
                str(path))
        return rep
    root = roots[0] if roots else path
    rep = Report(root.name)
    _check_structure(root, rep)
    if rep.findings and rep.findings[0]["code"] == "S-NOT-A-CASE":
        return rep
    _check_metadata(root, rep)
    _check_build(root, rep)
    _check_verifier(root, rep)
    _check_hidden_rules(root, rep)
    _check_corpus(root, rep)
    return rep


def render_report(rep: Report) -> str:
    L = ["=" * 78, f"КЕЙС: {rep.case}", "=" * 78]
    if not rep.findings:
        L.append("нарушений не найдено")
        return "\n".join(L)
    order = {BLOCKER: 0, WARN: 1, INFO: 2}
    by_fam = {}
    for f in rep.findings:
        by_fam.setdefault(f["family"], []).append(f)
    for fam in sorted(by_fam, key=lambda k: list(FAMILY).index(k) if k in FAMILY else 99):
        L.append("\n" + FAMILY.get(fam, fam))
        for f in sorted(by_fam[fam], key=lambda x: order[x["level"]]):
            L.append(f"  [{f['level']:7}] {f['code']}")
            L.append(f"            {f['message']}")
            if f["where"]:
                L.append(f"            где: {f['where']}")
            if f["basis"]:
                L.append(f"            основание: {f['basis']}")
    nb = len(rep.blockers)
    nw = sum(1 for f in rep.findings if f["level"] == WARN)
    ni = sum(1 for f in rep.findings if f["level"] == INFO)
    L.append(f"\nИТОГО: {nb} BLOCKER, {nw} WARN, {ni} INFO")
    return "\n".join(L)


def cmd_validate(args) -> int:
    reports = [validate(p) for p in args.paths]
    if args.json:
        print(json.dumps([{"case": r.case, "findings": r.findings} for r in reports],
                         ensure_ascii=False, indent=2))
    else:
        for r in reports:
            print(render_report(r))
    return 1 if any(r.blockers for r in reports) else 0


# --------------------------------------------------------------------------- #
# mutate / eval — вынесены в отдельные модули, здесь только вызов
# --------------------------------------------------------------------------- #

def _delegate(module_name: str, argv: list) -> int:
    mod_path = HERE / (module_name + ".py")
    if not mod_path.is_file():
        print(f"нет модуля {mod_path}", file=sys.stderr)
        return 2
    # Без сброса буфера при перенаправлении вывода (| tee, > файл) заголовки
    # родителя попадают в лог после вывода дочернего процесса.
    sys.stdout.flush()
    proc = subprocess.run([sys.executable, str(mod_path)] + argv)
    return proc.returncode


def cmd_mutate(args) -> int:
    argv = [str(args.case)]
    if args.oracle:
        argv += ["--oracle", str(args.oracle)]
    return _delegate("bkas_mutate", argv)


def cmd_emulate(args) -> int:
    argv = [str(args.case)]
    if args.answer:
        argv += ["--answer", str(args.answer)]
    return _delegate("bkas_emulate", argv)


def cmd_eval(args) -> int:
    return _delegate("bkas_eval", [str(args.case), "--mode", args.mode])


def cmd_run(args) -> int:
    case = find_case_root(args.case)
    print("### 1. соответствие стандарту")
    rc = cmd_validate(argparse.Namespace(paths=[case], json=False))
    print("\n### 2. корпус контролей")
    _delegate("bkas_mutate", [str(case)])
    print("\n### 3. различимость")
    rc2 = _delegate("bkas_eval", [str(case), "--mode", args.mode])
    rc3 = 0
    if args.mode == "fast":
        # Быстрый эвал запускает pytest в своей обвязке и не видит дефектов самого
        # test.sh (флаги, изоляция путей, подсчёт reward). Их ловит только эмуляция.
        print("")
        print("### 4. эмуляция test.sh")
        rc3 = _delegate("bkas_emulate", [str(case)])
    return rc or rc2 or rc3


# --------------------------------------------------------------------------- #
# new / finalize — делегируем, чтобы не дублировать шаблоны
# --------------------------------------------------------------------------- #

def cmd_new(args) -> int:
    cfg = load_config()
    argv = ["init", "--from", str(args.source), "--name", args.name,
            "--out", str(args.out), "--language", args.language,
            "--bank-domain", args.bank_domain, "--source-ref", args.source_ref,
            "--team", args.team or cfg["team"], "--platform", cfg["platform"]]
    for key in ("registry", "pip_index_url", "pip_trusted_host"):
        val = str(cfg.get(key) or "")
        if "<" in val or ".example" in val:
            print(f"ОТКАЗ: в конфиге {key} = {val!r} похоже на незаполненный шаблон.", file=sys.stderr)
            print("Впишите реальное значение контура или очистите ключ (для локального", file=sys.stderr)
            print("теста он не нужен). Иначе адрес из шаблона попадёт в Dockerfile.", file=sys.stderr)
            return 3
    base = args.base_image or cfg.get("base_image") or ""
    if not base:
        print("ОТКАЗ: базовый образ не задан.\n\n"
              "В закрытом контуре образ из публичного реестра не разрешится.\n"
              "Пропиши его в bkas.config.json (ключ base_image) с дайджестом,\n"
              "либо передай --base-image.\n\n"
              "  python bkas.py config --example", file=sys.stderr)
        return 3
    argv += ["--base-image", base]
    if cfg.get("pip_index_url"):
        argv += ["--pip-index-url", cfg["pip_index_url"]]
    if cfg.get("pip_trusted_host"):
        argv += ["--pip-trusted-host", cfg["pip_trusted_host"]]
    if args.force:
        argv.append("--force")
    return _delegate("bkas_new_case", argv)


def cmd_finalize(args) -> int:
    return _delegate("bkas_new_case", ["finalize", str(args.case)])


def cmd_draft(args) -> int:
    argv = [str(args.case), "--rounds", str(args.rounds)]
    for flag, val in (("--preset", args.preset), ("--model", args.model),
                      ("--base-url", args.base_url), ("--key-env", args.key_env),
                      ("--reference", args.reference), ("--max-tokens", args.max_tokens)):
        if val not in (None, ""):
            argv += [flag, str(val)]
    if args.send:
        argv.append("--send")
    if args.run:
        argv.append("--run")
    return _delegate("bkas_llm", argv)


# --------------------------------------------------------------------------- #

def main() -> int:
    ap = argparse.ArgumentParser(
        prog="bkas", description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("doctor", help="что доступно в этом окружении")
    d.set_defaults(func=cmd_doctor)

    c = sub.add_parser("config", help="показать или создать конфиг контура")
    c.add_argument("--example", action="store_true", help="создать заготовку")
    c.add_argument("--force", action="store_true")
    c.set_defaults(func=cmd_config)

    v = sub.add_parser("validate", help="соответствие стандарту БКАС")
    v.add_argument("paths", nargs="+", type=Path)
    v.add_argument("--json", action="store_true")
    v.set_defaults(func=cmd_validate)

    m = sub.add_parser("mutate", help="корпус контрольных ответов")
    m.add_argument("case", type=Path)
    m.add_argument("--oracle", type=Path)
    m.set_defaults(func=cmd_mutate)

    e = sub.add_parser("eval", help="различает ли кейс верное от неверного")
    e.add_argument("case", type=Path)
    e.add_argument("--mode", choices=("fast", "docker"), default="fast")
    e.set_defaults(func=cmd_eval)

    em = sub.add_parser("emulate", help="прогнать test.sh без Docker (флаги и reward как в скрипте)")
    em.add_argument("case", type=Path)
    em.add_argument("--answer", type=Path)
    em.set_defaults(func=cmd_emulate)

    r = sub.add_parser("run", help="validate + mutate + eval (+ emulate в режиме fast)")
    r.add_argument("case", type=Path)
    r.add_argument("--mode", choices=("fast", "docker"), default="fast")
    r.set_defaults(func=cmd_run)

    n = sub.add_parser("new", help="каркас кейса")
    n.add_argument("--from", dest="source", type=Path, required=True)
    n.add_argument("--name", required=True)
    n.add_argument("--out", type=Path, default=Path("work"))
    n.add_argument("--language", required=True)
    n.add_argument("--bank-domain", required=True)
    n.add_argument("--source-ref", required=True)
    n.add_argument("--team")
    n.add_argument("--base-image")
    n.add_argument("--force", action="store_true")
    n.set_defaults(func=cmd_new)

    f = sub.add_parser("finalize", help="контракт из схемы, sha256, task.toml")
    f.add_argument("case", type=Path)
    f.set_defaults(func=cmd_finalize)

    dr = sub.add_parser("draft", help="модель заполняет схему и эталон, верификатор их проверяет")
    dr.add_argument("case", type=Path)
    dr.add_argument("--preset", choices=("cloudru", "claude"))
    dr.add_argument("--model")
    dr.add_argument("--base-url", dest="base_url")
    dr.add_argument("--key-env", dest="key_env")
    dr.add_argument("--max-tokens", dest="max_tokens", type=int)
    dr.add_argument("--reference", type=Path, help="исправленный код (папка или файл)")
    dr.add_argument("--rounds", type=int, default=3)
    dr.add_argument("--send", action="store_true", help="разрешить отправку материала модели")
    dr.add_argument("--run", action="store_true", help="после успеха прогнать run --mode fast")
    dr.set_defaults(func=cmd_draft)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
