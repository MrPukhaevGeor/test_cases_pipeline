#!/usr/bin/env python3
"""
Эмуляция tests/test.sh без Docker.

Зачем нужна. `bkas_eval.py --mode fast` запускает pytest в собственной обвязке
(conftest подменяет /app), поэтому не видит дефектов самого test.sh: флагов
pytest, изоляции путей импорта, подсчёта reward. Так, например, `--import-mode=importlib`
без пути к каталогу тестов ломает `import bkas_matcher`: сбор тестов падает, эталон
получает reward 0, а быстрый эвал при этом ничего не замечает.

Что берётся из test.sh дословно:
    * строка запуска pytest со всеми флагами;
    * sitecustomize.py из heredoc ISOLATE (изоляция путей импорта);
    * EXPECTED_TESTS и правило, по которому пишется reward;
    * переменные окружения PYTHONNOUSERSITE и PYTEST_DISABLE_PLUGIN_AUTOLOAD.

Что подменяется: только пути /app и /tests на временные каталоги.

Чего НЕ воспроизводит (проверяется только в Docker):
    * shell-часть скрипта: mktemp, chmod, выбор python3/python;
    * версии Python и pytest образа: здесь используется текущий интерпретатор;
    * права файлов и монтирование томов.

Использование:
    python bkas_emulate.py <кейс>                  весь корпус + nop
    python bkas_emulate.py <кейс> --answer f.json  один ответ

Код возврата: 0 — все ответы получили ожидаемый reward, 1 — есть расхождения,
2 — эмуляция неприменима к этому кейсу (не удалось разобрать test.sh).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


class NotApplicable(Exception):
    """test.sh или verifier устроены так, что эмулировать их нельзя."""


def parse_test_sh(text: str) -> dict:
    # Продолжения строк вида «\<перевод строки» склеиваем: так найти вызов проще.
    flat = text.replace("\\\r\n", " ").replace("\\\n", " ")

    m = re.search(r"^EXPECTED_TESTS=(\d+)", text, re.M)
    if not m:
        raise NotApplicable("в test.sh нет строки EXPECTED_TESTS=<число>")

    # Аргументы обязаны начинаться с «-»: так отсекаются проверки вроде [ -z "$PY" ].
    # Закрывающая скобка необязательна: в старом шаблоне подоболочки нет.
    inv = re.search(r'"\$PY"\s+(-[^>]*?)\s*\)?\s*>\s*"\$PYTEST_LOG"', flat, re.S)
    if not inv:
        raise NotApplicable('не нашёл строку запуска pytest: "$PY" -... > "$PYTEST_LOG"')
    try:
        args = shlex.split(inv.group(1))
    except ValueError as exc:
        raise NotApplicable("не удалось разобрать аргументы pytest: %s" % exc)
    if "pytest" not in args:
        raise NotApplicable("в строке запуска нет pytest")

    iso = re.search(r"<<'ISOLATE'\n(.*?)\nISOLATE", text, re.S)
    return {
        "expected": int(m.group(1)),
        "args": args,
        "sitecustomize": iso.group(1) if iso else None,
        "nousersite": bool(re.search(r"^PYTHONNOUSERSITE=1", text, re.M)),
        "noautoload": bool(re.search(r"^PYTEST_DISABLE_PLUGIN_AUTOLOAD=1", text, re.M)),
    }


def decide_reward(returncode: int, output: str, expected: int) -> int:
    """Та же логика, что в test.sh: 1 только при полном и чистом прогоне."""
    def count(word: str) -> int:
        m = re.search(r"(\d+) %s" % word, output)
        return int(m.group(1)) if m else 0

    return int(
        expected > 0
        and returncode == 0
        and count("skipped") == 0
        and count("deselected") == 0
        and count("passed") == expected
    )


def build_sandbox(case: Path, spec: dict, root: Path) -> dict:
    """Создаёт каталоги /app и /tests во временной папке и готовит запуск."""
    for d in ("app", "work", "iso"):
        (root / d).mkdir()

    tests = root / "tests"
    shutil.copytree(case / "tests", tests, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    tests_posix = str(tests).replace("\\", "/")
    app_posix = str(root / "app").replace("\\", "/")

    verifier = tests / "test_verifier.py"
    if not verifier.is_file():
        raise NotApplicable("нет tests/test_verifier.py")
    src = verifier.read_text(encoding="utf-8")
    patched, n = re.subn(r"""^APP\s*=\s*["']/app["']""", "APP = %r" % app_posix, src, flags=re.M)
    if n != 1:
        raise NotApplicable('в test_verifier.py нет ровно одной строки APP = "/app"')
    verifier.write_text(patched, encoding="utf-8")

    repo = case / "environment" / "repo"
    if repo.is_dir():
        for p in repo.iterdir():
            dst = root / "app" / p.name
            if p.is_dir():
                shutil.copytree(p, dst)
            else:
                shutil.copy2(p, dst)

    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    env.pop("PYTHONHOME", None)
    env["PYTHONIOENCODING"] = "utf-8"
    if spec["nousersite"]:
        env["PYTHONNOUSERSITE"] = "1"
    if spec["noautoload"]:
        env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    if spec["sitecustomize"]:
        (root / "iso" / "sitecustomize.py").write_text(
            spec["sitecustomize"].replace('"/tests"', '"%s"' % tests_posix), encoding="utf-8")
        env["PYTHONPATH"] = str(root / "iso")

    args = [a.replace("/tests/", tests_posix + "/") if a.startswith("/tests/") else a
            for a in spec["args"]]
    return {"env": env, "args": args, "app": root / "app", "cwd": root / "work"}


def run_one(sb: dict, answer: Path | None, expected: int) -> tuple[int, int]:
    target = sb["app"] / "answer.json"
    if target.exists():
        target.unlink()
    if answer is not None:
        shutil.copy2(answer, target)
    r = subprocess.run([sys.executable] + sb["args"], cwd=sb["cwd"], env=sb["env"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return decide_reward(r.returncode, r.stdout, expected), r.returncode


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("case", type=Path)
    ap.add_argument("--answer", type=Path, help="прогнать один ответ вместо корпуса")
    ap.add_argument("--json", type=Path, help="сохранить результат")
    a = ap.parse_args()

    case = a.case.resolve()
    sh_path = case / "tests" / "test.sh"
    if not sh_path.is_file():
        print("нет tests/test.sh: %s" % sh_path, file=sys.stderr)
        return 2

    # Эмуляция читает test.sh из Python и CRLF не замечает, а настоящий sh в Linux-контейнере
    # на таком файле падает. Молча выдать PASS здесь нельзя.
    if b"\r\n" in sh_path.read_bytes():
        print("ВЕРДИКТ: FAIL")
        print("tests/test.sh содержит переводы строк CRLF: в Linux-контейнере он не запустится\n"
              "(«set: Illegal option -»), reward будет 0 у любого ответа, включая эталон.\n"
              "Переведите скрипт в LF.")
        return 1

    try:
        spec = parse_test_sh(sh_path.read_text(encoding="utf-8"))
    except NotApplicable as exc:
        print("эмуляция неприменима: %s" % exc, file=sys.stderr)
        return 2

    items: list[tuple[str, int, Path | None]] = [("nop (без answer.json)", 0, None)]
    if a.answer:
        items.append((a.answer.name, 1, a.answer))
    else:
        manifest = case / "eval" / "corpus" / "manifest.json"
        if not manifest.is_file():
            print("нет корпуса: %s\nсначала: python bkas.py mutate %s" % (manifest, case),
                  file=sys.stderr)
            return 2
        corpus = manifest.parent
        for e in json.loads(manifest.read_text(encoding="utf-8")):
            if e.get("needs_authoring"):
                continue
            items.append((e["name"], e["expected_reward"], corpus / (e["name"] + ".json")))

    print("=" * 78)
    print("ЭМУЛЯЦИЯ test.sh: %s" % case.name)
    print("=" * 78)
    print("запуск pytest : %s" % " ".join(spec["args"]))
    print("EXPECTED_TESTS: %d" % spec["expected"])
    print("изоляция      : %s" % ("sitecustomize из test.sh" if spec["sitecustomize"] else "нет"))
    print("интерпретатор : Python %d.%d.%d (образа здесь нет, см. docstring)\n" % sys.version_info[:3])

    rows, neg, pos = [], [0, 0], [0, 0]
    root = Path(tempfile.mkdtemp(prefix="bkas-emu-"))
    try:
        try:
            sb = build_sandbox(case, spec, root)
        except NotApplicable as exc:
            print("эмуляция неприменима: %s" % exc, file=sys.stderr)
            return 2
        for name, want, path in items:
            got, rc = run_one(sb, path, spec["expected"])
            ok = got == want
            bucket = neg if want == 0 else pos
            bucket[0] += ok
            bucket[1] += 1
            rows.append({"name": name, "expected": want, "actual": got, "pytest_exit": rc, "ok": ok})
            print(" [%s] %-26s ожидали %d, получили %d  (pytest код %d)" % (
                " ok " if ok else "FAIL", name, want, got, rc))
    finally:
        shutil.rmtree(root, ignore_errors=True)

    all_ok = all(r["ok"] for r in rows)
    print("\nнегативы -> 0 : %d/%d" % tuple(neg))
    print("позитивы -> 1 : %d/%d" % tuple(pos))
    print("\nВЕРДИКТ: %s" % ("PASS" if all_ok else "FAIL"))
    if not all_ok:
        exit_codes = {r["pytest_exit"] for r in rows if r["expected"] == 1 and not r["ok"]}
        if exit_codes == {2}:
            print("pytest завершился с кодом 2 на эталоне: тесты не собрались. Частая причина —\n"
                  "флаги запуска в test.sh (например --import-mode=importlib) без пути к tests/.")
    if a.json:
        a.json.write_text(json.dumps({"case": case.name, "rows": rows, "verdict": all_ok},
                                     ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
