#!/usr/bin/env python3
"""
Эвал кейса БКАС: меряет, различает ли верификатор верный разбор от неверного.

Статический валидатор (validate_case.py) отвечает на вопрос «собрано ли по стандарту».
Этот — на вопрос «а меряет ли собранное хоть что-нибудь». Кейс, прошедший стандарт,
но выдающий reward=1 отрицанию дефекта, бесполезен как бенчмарк.

Кейс здесь рассматривается как классификатор. Есть корпус ответов с известным
ожидаемым reward (см. bkas_mutate.py). Считаются две величины:

    строгость   = доля негативов, получивших 0   (падает — семейство A)
    терпимость  = доля позитивов, получивших 1   (падает — семейство B)

Обе обязаны быть 1.0. Это дословно критерий УМР: «мутант со слитыми метками и
минимум два независимых отрицательных пересказа получают reward 0, а минимум
три правдивых пересказа получают reward 1. Любой иной исход — FAIL».

Режимы:
    --mode docker   сборка образа и прогон в контейнере. Так считает УМР.
    --mode fast     pytest напрямую, без Docker. Быстро, для итераций.
                    Не воспроизводит логику подсчёта из tests/test.sh дословно.

Использование:
    python bkas_eval.py <путь-к-кейсу> [--mode fast|docker] [--json отчёт.json]
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, asdict, field
from pathlib import Path

CONFTEST = '''\
# Сгенерировано bkas_eval.py. Подменяет каталог приложения, чтобы верификатор
# читал ответ-кандидат вместо ответа агента. Сам верификатор не меняется.
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def pytest_configure(config):
    app = os.environ.get("BKAS_APP")
    if not app:
        return
    import test_verifier as tv
    tv.APP = app
    tv.ANSWER = os.path.join(app, "answer.json")
'''


@dataclass
class Result:
    name: str
    expected: int
    actual: int | None
    family: str
    rationale: str
    skipped: bool = False
    note: str = ""

    @property
    def ok(self) -> bool:
        return (not self.skipped) and self.actual == self.expected


@dataclass
class Scorecard:
    case: str
    mode: str
    results: list[Result] = field(default_factory=list)
    determinism_ok: bool | None = None

    def _subset(self, expected: int) -> list[Result]:
        return [r for r in self.results if r.expected == expected and not r.skipped]

    @property
    def strictness(self) -> float | None:
        neg = self._subset(0)
        return (sum(1 for r in neg if r.ok) / len(neg)) if neg else None

    @property
    def tolerance(self) -> float | None:
        pos = self._subset(1)
        return (sum(1 for r in pos if r.ok) / len(pos)) if pos else None

    @property
    def verdict(self) -> str:
        if self.strictness is None or self.tolerance is None:
            return "НЕТ ДАННЫХ"
        if self.determinism_ok is False:
            return "FAIL"
        return "PASS" if self.strictness == 1.0 and self.tolerance == 1.0 else "FAIL"


# --------------------------------------------------------------------------- #
# Прогон одного ответа
# --------------------------------------------------------------------------- #

def prepare_app(case: Path, answer: Path, app_dir: Path) -> None:
    """Каталог, который верификатор видит как /app: стартовый код + ответ."""
    app_dir.mkdir(parents=True, exist_ok=True)
    repo = case / "environment" / "repo"
    if repo.is_dir():
        for p in repo.iterdir():
            if p.is_file():
                shutil.copy2(p, app_dir / p.name)
    shutil.copy2(answer, app_dir / "answer.json")


def run_fast(case: Path, answer: Path, workdir: Path) -> tuple[int | None, str]:
    """pytest напрямую. Reward=1 только при нулевом коде возврата."""
    app = workdir / "app"
    if app.exists():
        shutil.rmtree(app)
    prepare_app(case, answer, app)

    tests = workdir / "tests"
    if not tests.exists():
        shutil.copytree(case / "tests", tests)
        (tests / "conftest.py").write_text(CONFTEST, encoding="utf-8")

    env = dict(os.environ)
    env["BKAS_APP"] = str(app)
    env["PYTHONIOENCODING"] = "utf-8"
    env.pop("PYTHONPATH", None)

    proc = subprocess.run(
        [sys.executable, "-m", "pytest", str(tests / "test_verifier.py"),
         "-q", "--tb=no", "-p", "no:cacheprovider"],
        capture_output=True, text=True, env=env, cwd=str(workdir),
    )
    if proc.returncode in (0, 1):
        return (1 if proc.returncode == 0 else 0), ""
    tail = (proc.stdout or proc.stderr or "").strip().splitlines()
    return None, f"pytest exit {proc.returncode}: {tail[-1] if tail else 'нет вывода'}"


def run_docker(case: Path, answer: Path, image: str, workdir: Path) -> tuple[int | None, str]:
    """Сборка уже выполнена; гоняем контейнер и читаем reward.txt."""
    app = workdir / "app"
    if app.exists():
        shutil.rmtree(app)
    prepare_app(case, answer, app)
    logs = workdir / "logs"
    if logs.exists():
        shutil.rmtree(logs)
    (logs / "verifier").mkdir(parents=True, exist_ok=True)

    # Источник bind-mount обязан быть абсолютным путём: относительный Docker принимает
    # за имя тома и падает с «Run 'docker run --help'». Прямые слэши безопасны и в Windows.
    tests_dir = (case / "tests").resolve().as_posix()
    proc = subprocess.run(
        ["docker", "run", "--rm", "--network", "none",
         "-v", f"{tests_dir}:/tests:ro",
         "-v", f"{app.resolve().as_posix()}:/app",
         "-v", f"{logs.resolve().as_posix()}:/logs",
         image, "sh", "/tests/test.sh"],
        capture_output=True, text=True,
    )
    reward_file = logs / "verifier" / "reward.txt"
    if not reward_file.is_file():
        tail = (proc.stderr or proc.stdout or "").strip().splitlines()
        return None, f"reward.txt не создан: {tail[-1] if tail else 'нет вывода'}"
    raw = reward_file.read_text(encoding="utf-8").strip()
    if raw not in ("0", "1"):
        return None, f"reward.txt содержит {raw!r}, ожидалось 0 или 1"
    return int(raw), ""


def docker_build(case: Path) -> tuple[str | None, str]:
    image = f"bkas-eval-{case.name.lower().replace('_', '-')}"
    proc = subprocess.run(
        ["docker", "build", "-q", "-t", image, str(case / "environment")],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        tail = (proc.stderr or "").strip().splitlines()
        return None, tail[-1] if tail else "сборка не удалась"
    return image, ""


# --------------------------------------------------------------------------- #
# Оркестрация
# --------------------------------------------------------------------------- #

def evaluate(case: Path, mode: str) -> Scorecard:
    case = case.resolve()
    corpus = case / "eval" / "corpus"
    manifest_path = corpus / "manifest.json"
    if not manifest_path.is_file():
        print(f"корпус не найден: {manifest_path}\n"
              f"сначала: python bkas.py mutate {case}", file=sys.stderr)
        sys.exit(2)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    card = Scorecard(case=case.name, mode=mode)
    image = None

    if mode == "docker":
        image, err = docker_build(case)
        if image is None:
            print(f"docker build не прошёл: {err}", file=sys.stderr)
            sys.exit(3)

    with tempfile.TemporaryDirectory(prefix="bkas-eval-") as tmp:
        workdir = Path(tmp)

        for entry in manifest:
            name = entry["name"]
            item = corpus / f"{name}.json"
            if entry.get("needs_authoring"):
                card.results.append(Result(name, entry["expected_reward"], None,
                                           entry["family"], entry["rationale"],
                                           skipped=True,
                                           note="заготовка не заполнена"))
                continue
            if not item.is_file():
                card.results.append(Result(name, entry["expected_reward"], None,
                                           entry["family"], entry["rationale"],
                                           skipped=True, note="файл отсутствует"))
                continue

            if mode == "docker":
                actual, note = run_docker(case, item, image, workdir)
            else:
                actual, note = run_fast(case, item, workdir)

            card.results.append(Result(name, entry["expected_reward"], actual,
                                       entry["family"], entry["rationale"],
                                       skipped=actual is None, note=note))

        # Детерминизм: тот же вход дважды обязан дать тот же reward.
        oracle = corpus / "pos_oracle.json"
        if oracle.is_file():
            runner = (lambda p: run_docker(case, p, image, workdir)) if mode == "docker" \
                else (lambda p: run_fast(case, p, workdir))
            a, _ = runner(oracle)
            b, _ = runner(oracle)
            card.determinism_ok = (a is not None and a == b)

    return card


# --------------------------------------------------------------------------- #
# Вывод
# --------------------------------------------------------------------------- #

def render(card: Scorecard) -> str:
    L = []
    L.append("=" * 78)
    L.append(f"ЭВАЛ КЕЙСА: {card.case}    режим: {card.mode}")
    L.append("=" * 78)

    for expected, title in ((0, "НЕГАТИВЫ — обязаны получить reward 0"),
                            (1, "ПОЗИТИВЫ — обязаны получить reward 1")):
        rows = [r for r in card.results if r.expected == expected]
        if not rows:
            continue
        L.append(f"\n{title}")
        for r in rows:
            if r.skipped:
                mark, got = "  ~  ", "пропущен"
            elif r.ok:
                mark, got = "  ok ", str(r.actual)
            else:
                mark, got = " FAIL", str(r.actual)
            L.append(f" [{mark}] {r.name:26} reward={got:9} {r.rationale}")
            if r.note:
                L.append(f"          {r.note}")

    L.append("")
    s, t = card.strictness, card.tolerance
    L.append(f"строгость  (негативы → 0): {'н/д' if s is None else f'{s:.0%}'}"
             f"   — падает при дефектах семейства A")
    L.append(f"терпимость (позитивы → 1): {'н/д' if t is None else f'{t:.0%}'}"
             f"   — падает при дефектах семейства B")
    if card.determinism_ok is not None:
        L.append(f"детерминизм: {'ок' if card.determinism_ok else 'НАРУШЕН'}")

    L.append("")
    L.append(f"ВЕРДИКТ: {card.verdict}")
    if card.verdict == "FAIL":
        bad = [r for r in card.results if not r.ok and not r.skipped]
        fams = sorted({r.family for r in bad if r.family != "—"})
        if fams:
            L.append(f"провалены семейства: {', '.join(fams)}")
        L.append("кейс не различает верный разбор от неверного и будет завёрнут "
                 "на приёмочном прогоне УМР")
    return "\n".join(L)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("case", type=Path)
    ap.add_argument("--mode", choices=("fast", "docker"), default="fast")
    ap.add_argument("--json", type=Path, help="сохранить отчёт машиночитаемо")
    args = ap.parse_args()

    card = evaluate(args.case, args.mode)
    print(render(card))

    if args.json:
        payload = asdict(card)
        payload["strictness"] = card.strictness
        payload["tolerance"] = card.tolerance
        payload["verdict"] = card.verdict
        args.json.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                             encoding="utf-8")

    return 0 if card.verdict == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
