#!/usr/bin/env python3
"""
bkas_llm — заполнение содержательной части кейса моделью.

Модель пишет ТОЛЬКО данные: схему (tests/fixtures/answer_schema.json) и эталонный
ответ (solution/solve.sh). Тесты, матчер, test.sh, Dockerfile и task.toml по-прежнему
делает детерминированный генератор. Поэтому ответ модели проходит те же ворота, что
и ручная работа: finalize, затем верификатор кейса на эталонном ответе.

Если эталон не проходит верификатор, модель получает список конкретных падений
и исправляет схему или эталон. Число раундов ограничено.

Протоколы:
    openai     POST {base_url}/chat/completions, Authorization: Bearer <ключ>
               Cloud.ru Foundation Models и любой OpenAI-совместимый шлюз
    anthropic  POST {base_url}/messages, заголовки x-api-key и anthropic-version
               Claude

Только стандартная библиотека (urllib, json): пакеты openai и python-dotenv не нужны.
Ключ берётся из переменной окружения или из файла .env рядом со скриптами.
Значение ключа нигде не печатается и не сохраняется.

Отправка исходников кейса во внешний сервис — действие с данными. Без флага --send
скрипт показывает, куда и что уйдёт, и ничего не отправляет.

Использование:
    python bkas_llm.py <кейс> [--preset cloudru|claude] [--model M] [--base-url U]
                              [--key-env VAR] [--reference DIR] [--rounds N] [--send]
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import bkas_matcher as bm  # noqa: E402
from bkas_eval import CONFTEST, prepare_app  # noqa: E402

# --------------------------------------------------------------------------- #
# Провайдеры
# --------------------------------------------------------------------------- #

PRESETS = {
    # Облако Сбера. Тот же способ подключения, что в скрипте отчёта по корзинам.
    "cloudru": {
        "protocol": "openai",
        "base_url": "https://foundation-models.api.cloud.ru/v1",
        "model": "Qwen/Qwen3-Coder-Next",
        "key_env": "API_KEY",
        "temperature": 0.1,
    },
    # Внешний сервис вне контура: исходники кейса уходят в Anthropic.
    "claude": {
        "protocol": "anthropic",
        "base_url": "https://api.anthropic.com/v1",
        "model": "claude-sonnet-5",
        "key_env": "ANTHROPIC_API_KEY",
        "temperature": None,
    },
}

# Хосты, куда исходники можно слать без предупреждения: облако Сбера и локальная машина.
TRUSTED_HOST_SUFFIXES = ("cloud.ru", "sber.ru", "sberbank.ru", "localhost", "127.0.0.1")

FIXED_CATEGORIES = ["security", "resource_leak", "error_handling", "code_quality"]
FIXED_TYPES = ["function", "variable", "import", "statement"]
MAX_SOURCE_BYTES = 200_000


class LLMError(Exception):
    pass


def load_dotenv(path: Path) -> None:
    """Минимальный разбор .env: KEY=VALUE, комментарии, кавычки. Окружение важнее файла."""
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def resolve_llm(cfg_llm: dict, overrides: dict) -> dict:
    preset = overrides.get("preset") or cfg_llm.get("preset") or "cloudru"
    if preset not in PRESETS:
        raise LLMError(f"неизвестный preset {preset!r}; есть: {', '.join(PRESETS)}")
    llm = dict(PRESETS[preset])
    for key in ("protocol", "base_url", "model", "key_env", "max_tokens", "timeout", "temperature"):
        if cfg_llm.get(key) not in (None, ""):
            llm[key] = cfg_llm[key]
        if overrides.get(key) not in (None, ""):
            llm[key] = overrides[key]
    llm.setdefault("max_tokens", 16000)
    llm.setdefault("timeout", 600)
    llm["preset"] = preset
    if llm["protocol"] not in ("openai", "anthropic"):
        raise LLMError(f"protocol должен быть openai или anthropic, а не {llm['protocol']!r}")
    return llm


def host_of(url: str) -> str:
    return urllib.parse.urlparse(url).hostname or url


def is_trusted_host(url: str) -> bool:
    host = host_of(url).lower()
    return any(host == s or host.endswith("." + s) for s in TRUSTED_HOST_SUFFIXES)


def chat(llm: dict, api_key: str, system: str, messages: list) -> tuple:
    """Один запрос. Возвращает (текст, обрезан_ли_по_лимиту, (токены_на_вход, на_выход))."""
    base = llm["base_url"].rstrip("/")
    if llm["protocol"] == "openai":
        url = base + "/chat/completions"
        body = {"model": llm["model"], "max_tokens": int(llm["max_tokens"]),
                "messages": [{"role": "system", "content": system}] + messages}
        if llm.get("temperature") is not None:
            body["temperature"] = float(llm["temperature"])
        headers = {"Authorization": "Bearer " + api_key, "Content-Type": "application/json"}
    else:
        url = base + "/messages"
        body = {"model": llm["model"], "max_tokens": int(llm["max_tokens"]),
                "system": system, "messages": messages}
        if llm.get("temperature") is not None:
            body["temperature"] = float(llm["temperature"])
        headers = {"x-api-key": api_key, "anthropic-version": "2023-06-01",
                   "content-type": "application/json"}

    req = urllib.request.Request(url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                                 headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=float(llm["timeout"])) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:600]
        raise LLMError(f"HTTP {exc.code} от {host_of(url)}: {detail}")
    except urllib.error.URLError as exc:
        raise LLMError(f"нет соединения с {host_of(url)}: {exc.reason}")
    except (socket.timeout, TimeoutError):
        raise LLMError(f"{host_of(url)} не ответил за {llm['timeout']} с")
    except ValueError as exc:
        raise LLMError(f"ответ {host_of(url)} не JSON: {exc}")

    try:
        if llm["protocol"] == "openai":
            choice = payload["choices"][0]
            text = choice["message"].get("content") or ""
            truncated = choice.get("finish_reason") == "length"
            usage = payload.get("usage") or {}
            tokens = (usage.get("prompt_tokens"), usage.get("completion_tokens"))
        else:
            text = "".join(b.get("text", "") for b in payload.get("content", [])
                           if b.get("type") == "text")
            truncated = payload.get("stop_reason") == "max_tokens"
            usage = payload.get("usage") or {}
            tokens = (usage.get("input_tokens"), usage.get("output_tokens"))
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError(f"неожиданная форма ответа {host_of(url)}: {exc}; "
                       f"начало ответа: {json.dumps(payload, ensure_ascii=False)[:300]}")
    return text, truncated, tokens


# --------------------------------------------------------------------------- #
# Промпт
# --------------------------------------------------------------------------- #

SYSTEM = (
    "Ты готовишь кейс для бенчмарка код-ревью. От тебя нужны только данные: схема проверки "
    "и эталонный ответ. Сами проверки пишет не модель, их делает фиксированная библиотека "
    "по твоей схеме. Отвечай ровно одним JSON-объектом, без пояснений и без markdown."
)

# Синтетический пример формата. Не данные Сбера: написан вручную для промпта,
# прогоняется верификатором в тестах bkas_llm, чтобы не учить модель неверному.
EXAMPLE_SOURCE = '''\
import json

def load_limits(path):
    f = open(path)
    data = json.load(f)
    return data["limit"]

def main():
    limit = load_limits("limits.json")
    print(limit * 2)
'''

EXAMPLE = {
    "schema": {
        "analyzed_file": "report.py",
        "analyzed_file_path": "report.py",
        "valid_elements": ["json", "load_limits", "main", "open", "f", "data", "limit",
                           "print", "path"],
        "valid_categories": FIXED_CATEGORIES,
        "valid_types": FIXED_TYPES,
        "required_elements_in_changes": ["load_limits", "main"],
        "min_changes": 2,
        "min_findings": 3,
        "min_alternative_findings": 1,
        "min_detail_len": 40,
        "required_findings": [
            {"id": "file_not_closed", "element": "load_limits",
             "accepted_elements": ["load_limits", "open", "f"],
             "category": "resource_leak",
             "rationale": "Файл открывается через open и не закрывается: при повторных вызовах "
                          "утекают файловые дескрипторы.",
             "keyword_groups": [["open", "не закры"], ["файл", "не закры"],
                                ["дескриптор", "утечк"], ["close", "отсутств"],
                                ["with", "не использ"], ["file", "not closed"],
                                ["descriptor", "leak"]]},
            {"id": "missing_key_unhandled", "element": "load_limits",
             "accepted_elements": ["load_limits", "data"],
             "category": "error_handling",
             "rationale": "Обращение data[\"limit\"] без проверки: при отсутствии ключа KeyError.",
             "keyword_groups": [["limit", "keyerror"], ["ключ", "отсутств"],
                                ["ключ", "не провер"], ["поле", "нет"],
                                ["key", "missing"]]},
        ],
        "alternative_findings": [
            {"id": "hardcoded_path", "element": "main", "accepted_elements": ["main"],
             "category": "code_quality",
             "rationale": "Путь к файлу зашит в код.",
             "keyword_groups": [["limits.json", "зашит"], ["путь", "зашит"],
                                ["путь", "констант"], ["hardcoded", "path"]]},
        ],
    },
    "oracle_answer": {
        "file": "report.py",
        "changes": [
            {"element": "load_limits", "type": "function",
             "description": "Функция открывает файл по пути path, разбирает JSON и возвращает "
                            "значение поля limit вызывающему коду."},
            {"element": "main", "type": "function",
             "description": "Точка входа: читает лимит из файла limits.json и печатает его "
                            "удвоенное значение."},
        ],
        "important_findings": [
            {"element": "load_limits", "category": "resource_leak",
             "finding": "файл не закрывается",
             "detail": "Функция открывает файл через open, но дескриптор f не закрывается; "
                       "если функцию вызывать многократно, это приводит к утечке файловых "
                       "дескрипторов."},
            {"element": "load_limits", "category": "error_handling",
             "finding": "отсутствие ключа не обрабатывается",
             "detail": "Обращение data[\"limit\"] не проверяет наличие ключа: если в файле "
                       "нет поля limit, возникает KeyError и программа падает без понятного "
                       "сообщения."},
            {"element": "main", "category": "code_quality",
             "finding": "путь зашит в код",
             "detail": "Путь limits.json зашит константой в main, поэтому для другого "
                       "окружения придётся править исходный код."},
        ],
    },
}


def build_prompt(sources: list, reference: list, language: str) -> str:
    filler = ", ".join(f"«{w}»" for w in bm.DEFAULT_FILLER)
    parts = [f"""\
## Что делает агент в этом кейсе

Агент читает приложенный материал (код или diff на языке: {language or "не указан"}) и сдаёт
разбор в /app/answer.json:
{{"file": "<анализируемый файл>", "changes": [{{"element", "type", "description"}}],
 "important_findings": [{{"element", "category", "finding", "detail"}}]}}

## Как верификатор засчитывает запись important_findings

Запись закрывает пункт схемы, только если выполнено всё сразу:
1. element входит в accepted_elements пункта;
2. category совпадает с category пункта;
3. в тексте finding + detail есть ЦЕЛИКОМ хотя бы одна группа из keyword_groups
   (И внутри группы, ИЛИ между группами; сравнение по подстроке в нижнем регистре, ё = е);
4. текст не является отрицанием дефекта;
5. в detail есть причинная связка (если, когда, приводит, поэтому, в результате, из-за,
   if, when, leads to, because, due to), кроме категории code_quality.
Сопоставление один к одному: одна запись закрывает не больше одного пункта.

## Что вернуть

Один JSON-объект с двумя ключами: "schema" и "oracle_answer". Формат — как в примере ниже.

Правила для schema:
- required_findings — ТОЛЬКО дефекты, которые однозначно следуют из приложенного кода.
  То, что зависит от внешних условий или гипотетично, — в alternative_findings или никуда.
  (Кейс вернули ревьюеры за обязательные SSRF и переполнение буфера, недостижимые в коде.)
- keyword_groups: 10–15 групп на пункт, по 1–3 термина. Покрывай разные правдивые
  формулировки: синонимы, имя вызова, последствие, английские варианты. Пиши основы слов
  в нижнем регистре («не провер», «утечк»). Каждая группа должна однозначно указывать
  на этот дефект, а не на любой текст.
- accepted_elements: охватывающая функция И место вызова или переменная, где дефект.
- valid_elements: все идентификаторы из кода, на которые можно сослаться (функции, вызовы,
  переменные, заголовки), в точном написании из кода.
- required_elements_in_changes: 2–5 ключевых элементов, которые опишет любой разбор.
- valid_categories строго {json.dumps(FIXED_CATEGORIES)};
  valid_types строго {json.dumps(FIXED_TYPES)}.
- min_findings = число обязательных пунктов + min_alternative_findings.
- analyzed_file — имя анализируемого файла, как оно указано в материале.

Правила для oracle_answer (эталон обязан пройти ВСЕ проверки):
- каждый обязательный пункт закрыт ОТДЕЛЬНОЙ записью; альтернативных не меньше
  min_alternative_findings;
- changes не меньше min_changes, в них есть все required_elements_in_changes;
- у каждой записи detail и description не короче 40 символов, description не равен имени
  элемента, detail не повторяются между записями;
- в тексте каждой записи есть термины хотя бы одной группы своего пункта;
- не используй слова-заглушки: {filler};
- не пиши формулировок, похожих на отрицание дефекта: «безопасен», «безопасный»,
  «избыточн», «нет проблем», «проверка не нужна», «всё в порядке».

## Пример формата (синтетический, в реальном ответе групп больше)

Материал report.py:
```
{EXAMPLE_SOURCE}```

Ответ:
{json.dumps(EXAMPLE, ensure_ascii=False, indent=1)}

## Материал кейса
"""]
    for label, text in sources:
        parts.append(f"\n### {label}\n```\n{text}\n```\n")
    if reference:
        parts.append("\n## Эталонное исправление (как код выглядит после починки)\n")
        for label, text in reference:
            parts.append(f"\n### {label}\n```\n{text}\n```\n")
    parts.append("\nВерни только JSON-объект {\"schema\": ..., \"oracle_answer\": ...}.")
    return "".join(parts)


def repair_prompt(problems: list) -> str:
    lines = "\n".join(f"- {p}" for p in problems[:40])
    return (
        "Эталонный ответ не прошёл проверку кейса. Конкретные падения:\n"
        f"{lines}\n\n"
        "Исправь схему и/или эталон так, чтобы эталон проходил все проверки. Не ослабляй "
        "требования к содержанию и не добавляй в обязательные пункты то, что не следует "
        "из кода. Верни снова полный JSON-объект {\"schema\": ..., \"oracle_answer\": ...}."
    )


# --------------------------------------------------------------------------- #
# Разбор и проверка ответа модели
# --------------------------------------------------------------------------- #

def extract_json(text: str) -> dict:
    t = text.strip()
    fence = re.search(r"```(?:json)?\s*(.*?)```", t, re.S)
    if fence and "{" in fence.group(1):
        t = fence.group(1)
    i, j = t.find("{"), t.rfind("}")
    if i < 0 or j <= i:
        raise LLMError("в ответе модели нет JSON-объекта")
    try:
        obj = json.loads(t[i:j + 1])
    except ValueError as exc:
        raise LLMError(f"JSON в ответе не разбирается: {exc}")
    if not isinstance(obj, dict):
        raise LLMError("ответ — не JSON-объект")
    return obj


def _is_str_list(x) -> bool:
    return isinstance(x, list) and all(isinstance(i, str) for i in x)


def structural_problems(obj: dict, source_blob: str) -> list:
    p = []
    schema, oracle = obj.get("schema"), obj.get("oracle_answer")
    if not isinstance(schema, dict):
        return ["нет объекта schema"]
    if not isinstance(oracle, dict):
        return ["нет объекта oracle_answer"]

    for key in ("analyzed_file", "valid_elements", "required_elements_in_changes",
                "min_changes", "min_findings", "required_findings"):
        if key not in schema:
            p.append(f"в schema нет поля {key}")
    if p:
        return p

    af = str(schema["analyzed_file"]).strip()
    if not af:
        p.append("schema.analyzed_file пустое")
    elif af not in source_blob:
        p.append(f"schema.analyzed_file = {af!r}: такого имени нет в материале кейса")

    valid = schema.get("valid_elements")
    if not _is_str_list(valid) or not valid:
        p.append("schema.valid_elements должен быть непустым списком строк")
        valid = []
    valid_n = {bm.norm(v) for v in valid}

    for el in schema.get("required_elements_in_changes") or []:
        if bm.norm(el) not in valid_n:
            p.append(f"required_elements_in_changes содержит {el!r}, которого нет в valid_elements")

    for key in ("min_changes", "min_findings"):
        if not isinstance(schema.get(key), int) or schema[key] < 1:
            p.append(f"schema.{key} должен быть целым числом ≥ 1")
    if not isinstance(schema.get("min_alternative_findings", 0), int):
        p.append("schema.min_alternative_findings должен быть целым числом")

    specs = [("required_findings", s) for s in schema.get("required_findings") or []] + \
            [("alternative_findings", s) for s in schema.get("alternative_findings") or []]
    if not schema.get("required_findings"):
        p.append("schema.required_findings пуст: в кейсе нет ни одного обязательного дефекта")
    ids = set()
    for where, s in specs:
        sid = s.get("id") if isinstance(s, dict) else None
        tag = f"{where}[{sid or '?'}]"
        if not isinstance(s, dict) or not sid:
            p.append(f"{where}: пункт без id")
            continue
        if sid in ids:
            p.append(f"{tag}: повторяющийся id")
        ids.add(sid)
        cats = s.get("categories") or [s.get("category")]
        if not all(c in FIXED_CATEGORIES for c in cats):
            p.append(f"{tag}: категория {cats} вне {FIXED_CATEGORIES}")
        acc = s.get("accepted_elements") or [s.get("element")]
        bad = [e for e in acc if not isinstance(e, str) or bm.norm(e) not in valid_n]
        if bad:
            p.append(f"{tag}: accepted_elements {bad} нет в valid_elements")
        groups = s.get("keyword_groups")
        if not isinstance(groups, list) or not groups or \
                not all(_is_str_list(g) and g and all(t.strip() for t in g) for g in groups):
            p.append(f"{tag}: keyword_groups должен быть непустым списком непустых групп строк")

    for key in ("file", "changes", "important_findings"):
        if key not in oracle:
            p.append(f"в oracle_answer нет поля {key}")
    if not isinstance(oracle.get("changes", []), list) or \
            not isinstance(oracle.get("important_findings", []), list):
        p.append("oracle_answer.changes и important_findings должны быть списками")
    return p


def normalize_schema(schema: dict) -> dict:
    """Детерминированная правка того, что модель не обязана знать про матчер."""
    s = dict(schema)
    s.pop("_HOWTO", None)
    s["valid_categories"] = list(FIXED_CATEGORIES)
    s["valid_types"] = list(FIXED_TYPES)
    s.setdefault("min_alternative_findings", 0)
    s.setdefault("min_detail_len", 40)
    s.setdefault("analyzed_file_path", s["analyzed_file"])
    for key in ("required_findings", "alternative_findings"):
        fixed = []
        for spec in s.get(key) or []:
            spec = dict(spec)
            # Матчер сравнивает термины с нормализованным текстом, но сами термины
            # не нормализует: «Утечк» или «ё» не совпали бы никогда.
            groups = []
            for g in spec.get("keyword_groups") or []:
                terms = [bm.norm(t) for t in g if str(t).strip()]
                if terms and terms not in groups:
                    groups.append(terms)
            spec["keyword_groups"] = groups
            acc = list(spec.get("accepted_elements") or [])
            if spec.get("element") and spec["element"] not in acc:
                acc.insert(0, spec["element"])
            spec["accepted_elements"] = acc
            fixed.append(spec)
        s[key] = fixed
    s.setdefault("alternative_findings", [])
    return s


def write_case_files(case: Path, schema: dict, oracle: dict, llm: dict) -> None:
    fixture = case / "tests" / "fixtures" / "answer_schema.json"
    with open(fixture, "w", encoding="utf-8", newline="\n") as f:
        json.dump(schema, f, ensure_ascii=False, indent=2)
    body = json.dumps(oracle, ensure_ascii=False, indent=2)
    with open(case / "solution" / "solve.sh", "w", encoding="utf-8", newline="\n") as f:
        f.write("#!/bin/sh\n"
                f"# Эталонный ответ. Черновик модели {llm['model']} ({llm['preset']}),\n"
                "# принят только после прохождения верификатора кейса.\n"
                "cat > /app/answer.json << 'ANSWER_JSON'\n"
                f"{body}\n"
                "ANSWER_JSON\n")


def run_finalize(case: Path) -> list:
    proc = subprocess.run([sys.executable, str(HERE / "bkas_new_case.py"), "finalize", str(case)],
                          capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode == 0:
        return []
    tail = [ln for ln in (proc.stderr or proc.stdout).strip().splitlines() if ln.strip()][-6:]
    return ["сборка кейса (finalize) не прошла: " + " | ".join(tail)]


def check_oracle(case: Path) -> list:
    """Прогон собранного верификатора на эталоне. Возвращает список падений."""
    work = Path(tempfile.mkdtemp(prefix="bkas-llm-"))
    try:
        answer = work / "oracle.json"
        sh = (case / "solution" / "solve.sh").read_text(encoding="utf-8")
        m = re.search(r"<<\s*'?(\w+)'?[ \t]*\r?\n(.*?)\r?\n\1[ \t]*$", sh, re.S | re.M)
        if not m:
            return ["в solution/solve.sh нет heredoc с answer.json"]
        answer.write_text(m.group(2), encoding="utf-8")
        app = work / "app"
        prepare_app(case, answer, app)
        tests = work / "tests"
        shutil.copytree(case / "tests", tests, ignore=shutil.ignore_patterns("__pycache__"))
        (tests / "conftest.py").write_text(CONFTEST, encoding="utf-8")
        env = dict(os.environ, BKAS_APP=str(app), PYTHONIOENCODING="utf-8")
        env.pop("PYTHONPATH", None)
        proc = subprocess.run(
            [sys.executable, "-m", "pytest", str(tests / "test_verifier.py"), "-q", "--tb=short",
             "-rf", "-p", "no:cacheprovider"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            env=env, cwd=str(work))
        if proc.returncode == 0:
            return []
        # Текст ошибки есть только в блоке «____ имя_теста ____ / E   AssertionError: ...»:
        # в итоговой строке FAILED pytest его не печатает. Модели нужен именно текст.
        fails, current, seen = [], None, set()
        for line in proc.stdout.splitlines():
            head = re.match(r"^_{3,} (\S+) _{3,}$", line)
            if head:
                current = head.group(1)
                continue
            if current and current not in seen and line.startswith("E ") and "Error:" in line:
                msg = line[1:].strip()
                msg = re.sub(r"^AssertionError:\s*", "", msg)
                fails.append(f"{current}: {msg}")
                seen.add(current)
        for line in proc.stdout.splitlines():
            if line.startswith("FAILED "):
                name = line[len("FAILED "):].split("::", 1)[-1].split(" - ")[0]
                if name not in seen:
                    fails.append(name)
                    seen.add(name)
        if not fails:
            tail = [ln for ln in proc.stdout.strip().splitlines() if ln.strip()][-5:]
            fails = [f"верификатор не отработал (pytest код {proc.returncode}): " + " | ".join(tail)]
        return fails
    finally:
        shutil.rmtree(work, ignore_errors=True)


# --------------------------------------------------------------------------- #
# Сбор материала
# --------------------------------------------------------------------------- #

GENERATED = {"system_prompt.txt"}


def read_text_files(root: Path, label: str) -> list:
    out = []
    files = [root] if root.is_file() else sorted(p for p in root.rglob("*") if p.is_file())
    for p in files:
        if p.name in GENERATED or "__pycache__" in p.parts:
            continue
        raw = p.read_bytes()
        if b"\x00" in raw[:4096]:
            continue
        rel = p.name if root.is_file() else p.relative_to(root).as_posix()
        out.append((f"{label}: {rel}", raw.decode("utf-8", "replace")))
    return out


# --------------------------------------------------------------------------- #
# Основной цикл
# --------------------------------------------------------------------------- #

def draft(args) -> int:
    case = args.case.resolve()
    if not (case / "tests" / "fixtures" / "answer_schema.json").is_file():
        print(f"это не каркас кейса: нет tests/fixtures/answer_schema.json в {case}\n"
              f"сначала: python bkas.py new ...", file=sys.stderr)
        return 2

    load_dotenv(HERE / ".env")
    load_dotenv(Path.cwd() / ".env")
    cfg_llm = {}
    cfg_path = Path(os.environ.get("BKAS_CONFIG") or (HERE / "bkas.config.json"))
    if cfg_path.is_file():
        try:
            cfg_llm = json.loads(cfg_path.read_text(encoding="utf-8")).get("llm") or {}
        except ValueError:
            pass
    try:
        llm = resolve_llm(cfg_llm, {"preset": args.preset, "model": args.model,
                                    "base_url": args.base_url, "key_env": args.key_env,
                                    "max_tokens": args.max_tokens})
    except LLMError as exc:
        print(f"ОТКАЗ: {exc}", file=sys.stderr)
        return 2

    sources = read_text_files(case / "environment" / "repo", "материал")
    if not sources:
        print("в environment/repo нет текстовых файлов для анализа", file=sys.stderr)
        return 2
    reference = read_text_files(args.reference.resolve(), "исправление") if args.reference else []
    total = sum(len(t.encode("utf-8")) for _, t in sources + reference)
    if total > MAX_SOURCE_BYTES:
        print(f"материал {total} байт больше лимита {MAX_SOURCE_BYTES}: сократите кейс",
              file=sys.stderr)
        return 2

    meta = {}
    gen = case / "eval" / "_generator.json"
    if gen.is_file():
        meta = json.loads(gen.read_text(encoding="utf-8"))

    api_key = os.environ.get(llm["key_env"], "")
    print("=" * 78)
    print(f"ЧЕРНОВИК СХЕМЫ МОДЕЛЬЮ: {case.name}")
    print("=" * 78)
    print(f"провайдер : {llm['preset']} ({llm['protocol']})")
    print(f"адрес     : {host_of(llm['base_url'])}")
    print(f"модель    : {llm['model']}")
    print(f"ключ      : переменная {llm['key_env']} — {'задана' if api_key else 'НЕ ЗАДАНА'}")
    print(f"отправится: {len(sources) + len(reference)} файл(ов), {total} байт материала")
    for label, _ in sources + reference:
        print(f"            {label}")
    if not is_trusted_host(llm["base_url"]):
        print("\nВНИМАНИЕ: адрес вне облака Сбера. Исходники кейса уйдут во внешний сервис.\n"
              "Отправляйте только материал, который разрешено передавать наружу.")

    if not api_key:
        print(f"\nнет ключа: задайте {llm['key_env']} в окружении или в файле .env рядом со "
              f"скриптами\n  {llm['key_env']}=...", file=sys.stderr)
        return 2
    if not args.send:
        print("\nНичего не отправлено. Чтобы отправить, повторите команду с --send.")
        return 2

    raw_dir = case / "eval" / "llm_raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    # Имя анализируемого файла ищется и в именах файлов материала, и в тексте (diff).
    blob = "\n".join(label + "\n" + t for label, t in sources)
    messages = [{"role": "user", "content": build_prompt(sources, reference,
                                                          meta.get("language", ""))}]
    used_in, used_out = 0, 0
    started = time.time()
    problems: list = []

    for rnd in range(1, args.rounds + 1):
        print(f"\n--- раунд {rnd}/{args.rounds}: запрос к модели ---")
        try:
            text, truncated, (t_in, t_out) = chat(llm, api_key, SYSTEM, messages)
        except LLMError as exc:
            print(f"ОШИБКА ВЫЗОВА: {exc}", file=sys.stderr)
            return 3
        used_in += t_in or 0
        used_out += t_out or 0
        (raw_dir / f"round{rnd}.txt").write_text(text, encoding="utf-8")
        print(f"получено {len(text)} символов, токены: вход {t_in}, выход {t_out}")

        if truncated:
            problems = [f"ответ оборвался по лимиту max_tokens={llm['max_tokens']}: верни JSON "
                        f"компактнее (rationale до 200 символов, без лишних полей)"]
        else:
            try:
                obj = extract_json(text)
                problems = structural_problems(obj, blob)
            except LLMError as exc:
                problems = [str(exc)]
                obj = None
            if not problems:
                schema = normalize_schema(obj["schema"])
                write_case_files(case, schema, obj["oracle_answer"], llm)
                problems = run_finalize(case) or check_oracle(case)

        if not problems:
            elapsed = time.time() - started
            provenance = {"preset": llm["preset"], "protocol": llm["protocol"],
                          "host": host_of(llm["base_url"]), "model": llm["model"],
                          "rounds": rnd, "tokens_in": used_in, "tokens_out": used_out,
                          "seconds": round(elapsed, 1),
                          "created": time.strftime("%Y-%m-%d %H:%M:%S")}
            with open(case / "eval" / "_llm_draft.json", "w", encoding="utf-8", newline="\n") as f:
                json.dump(provenance, f, ensure_ascii=False, indent=2)
            req = len(schema["required_findings"])
            alt = len(schema["alternative_findings"])
            groups = [len(s["keyword_groups"]) for s in
                      schema["required_findings"] + schema["alternative_findings"]]
            print(f"\nГОТОВО за {rnd} раунд(а), {elapsed:.0f} с, токены: вход {used_in}, "
                  f"выход {used_out}")
            print(f"  обязательных замечаний: {req}, альтернативных: {alt}")
            print(f"  групп ключевых слов на замечание: от {min(groups)} до {max(groups)}")
            print("  эталон проходит все проверки собранного верификатора")
            print("\nдальше проверьте кейс целиком и прочитайте схему глазами:")
            print(f"  python bkas.py run {case} --mode fast")
            print("  (модель не отличает реальный дефект от выдуманного: семейство C смотрит человек)")
            if args.run:
                sys.stdout.flush()
                return subprocess.run([sys.executable, str(HERE / "bkas.py"), "run",
                                       str(case), "--mode", "fast"]).returncode
            return 0

        print(f"не прошло, проблем: {len(problems)}")
        for pr in problems[:8]:
            print(f"  - {pr}")
        messages.append({"role": "assistant", "content": text or "(пустой ответ)"})
        messages.append({"role": "user", "content": repair_prompt(problems)})

    print(f"\nНЕ ГОТОВО: за {args.rounds} раунд(а) эталон так и не прошёл проверки.",
          file=sys.stderr)
    print("Сырые ответы модели: " + str(raw_dir), file=sys.stderr)
    return 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("case", type=Path)
    ap.add_argument("--preset", choices=sorted(PRESETS))
    ap.add_argument("--model")
    ap.add_argument("--base-url", dest="base_url")
    ap.add_argument("--key-env", dest="key_env")
    ap.add_argument("--max-tokens", dest="max_tokens", type=int)
    ap.add_argument("--reference", type=Path, help="папка или файл с исправленным кодом")
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--send", action="store_true", help="разрешить отправку материала модели")
    ap.add_argument("--run", action="store_true", help="после успеха сразу прогнать bkas.py run")
    return draft(ap.parse_args())


if __name__ == "__main__":
    sys.exit(main())
