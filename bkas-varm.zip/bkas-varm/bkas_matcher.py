#!/usr/bin/env python3
"""
Матчер БКАС: логика сопоставления ответа агента с контрактом кейса.

Библиотека, а не копипаст. Каждый завёрнутый кейс имел свой самописный матчер
с одними и теми же дефектами: сравнение по подстроке без проверки полярности,
совпадения не расходуются один к одному, привязка только к охватывающей функции,
язык связки зашит скрытым правилом. Пока эта логика пишется заново в каждом
кейсе, семейства A и B будут воспроизводиться.

Здесь логика одна на все кейсы и покрыта собственными тестами. Кейс становится
данными: схема задаёт элементы, категории, пороги и группы ключевых слов —
и всё. Поведение матчера кейсом не переопределяется.

Извлечено из b2c_case_04_50 после реворка под ревью УМР от 12.08.2026.

Дополнительно: `render_contract()` порождает видимый контракт из той же схемы,
по которой работают проверки. Согласованность видимого и исполняемого получается
по построению, а не выверяется руками.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata

# --------------------------------------------------------------------------- #
# Нормализация
# --------------------------------------------------------------------------- #

_WS_RE = re.compile(r"\s+")


def norm(text) -> str:
    """Регистр, ё/е и пробелы к общему виду. Без этого совпадения зависят
    от того, как агент набрал текст, а это не содержательное различие."""
    if text is None:
        return ""
    t = unicodedata.normalize("NFKC", str(text)).lower().replace("ё", "е")
    return _WS_RE.sub(" ", t).strip()


def sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------- #
# Значения по умолчанию
# --------------------------------------------------------------------------- #

# Причинные связки. Одиночное «может» намеренно НЕ маркер: общая фраза
# «может привести к ошибке» причинной связкой не является — это прямая
# формулировка из ревью.
DEFAULT_CAUSAL_RU = [
    "если", "когда", "приводит", "приведёт", "приведет", "позволяет", "позволит",
    "вследствие", "в результате", "из-за", "поэтому", "тогда",
    "при отказ", "при ошибк", "при сбое", "при некорректн", "при пуст",
    "при каждом", "останется", "остаётся", "остается", "окажется", "окажутся",
]

DEFAULT_CAUSAL_EN = [
    "if", "when", "leads to", "lead to", "results in", "result in", "because",
    "therefore", "so that", "otherwise", "remains", "will remain", "causes",
    "cause", "due to", "as a result", "consequently",
]

# Отрицание дефекта ловится шаблонами, а не отдельными словами. «Небезопасный»
# и «некорректный» содержат подстроки «безопасн»/«корректн», но отрицанием
# дефекта не являются — на этом ломались наивные реализации.
DEFAULT_DENIAL_PATTERNS = [
    r"(?:дефект\w*|проблем\w*|уязвимост\w*|утечк\w*|риск\w*|опасност\w*|замечан\w*|нарекан\w*)"
    r"[^.!?]{0,40}?(?:нет\b|отсутству\w*|не возника\w*)",
    r"(?:нет\b|отсутству\w*)[^.!?]{0,40}?"
    r"(?:дефект\w*|проблем\w*|уязвимост\w*|утечк\w*|риск\w*|опасност\w*|замечан\w*|нарекан\w*)",
    r"не (?:явля\w*|созда\w*|представля\w*|нес[её]т|порожда\w*)[^.!?]{0,40}?"
    r"(?:дефект\w*|проблем\w*|уязвимост\w*|утечк\w*|риск\w*|опасност\w*|ошибк\w*)",
    r"(?:провер\w*|обработк\w*|исправлен\w*|закрыт\w*|санитиз\w*|валидац\w*)"
    r"[^.!?]{0,30}?не (?:нужн\w*|требуетс\w*|обязательн\w*)",
    r"не (?:нужн\w*|требуетс\w*|обязательн\w*)[^.!?]{0,30}?"
    r"(?:провер\w*|обработк\w*|исправлен\w*|закрыт\w*|санитиз\w*|валидац\w*)",
    r"(?<![а-яё])безопас(?:ен|на|но|ный|ная|ное)(?![а-яё])",
    r"избыточн\w*",
    r"(?:вс[её] в порядке|нареканий нет|замечаний нет|ничего исправлять)",
    # «Мягкое» отрицание: дефект назван своими словами, но объявлен неважным.
    # Найдено прогоном: «HttpClient на каждый вызов, но это не проблема» получало reward 1.
    r"(?:это|что)\s+не\s+(?:проблем\w*|страшн\w*|критичн\w*)",
    r"(?:это|что)\s+(?:\w+\s+){0,2}?(?:допустим\w*|нормальн\w*|приемлем\w*)",
    r"обычн\w*\s+практик\w*",
    r"(?:менять|исправлять|переделывать|трогать|чинить)\s+(?:\w+\s+){0,2}?"
    r"не\s+(?:нужн\w*|надо|требуетс\w*|стоит)",
    r"оставить\s+как\s+есть",
    r"(?:смысла\s+нет|нет\s+смысла)",
    r"\bnot\s+(?:a|an)\s+(?:real\s+)?(?:problem|issue)\b",
    r"\b(?:is|it's|this\s+is)\s+(?:fine|acceptable)\b",
    r"\bno\s+need\s+to\s+(?:change|fix)\b",
    r"\bleave\s+(?:it\s+)?as\s+is\b",
]

# Категории, для которых причинная связка не требуется: структурные замечания
# по своей природе не имеют сценария срабатывания.
DEFAULT_NO_CAUSAL_CATEGORIES = {"code_quality"}

DEFAULT_FILLER = [
    "lorem", "ipsum", "dolor", "todo", "tbd", "fixme", "заглушка", "placeholder",
    "дописать", "потом", "n/a", "xxx",
]


# --------------------------------------------------------------------------- #
# Схема
# --------------------------------------------------------------------------- #

class Schema:
    """Обёртка над answer_schema.json. Единственный источник правды кейса."""

    def __init__(self, data: dict):
        self.raw = data
        self.analyzed_file = data["analyzed_file"]
        self.analyzed_file_path = data.get("analyzed_file_path", self.analyzed_file)

        self.valid_elements = {norm(e) for e in data["valid_elements"]}
        self.valid_elements_raw = list(data["valid_elements"])
        self.valid_categories = set(data["valid_categories"])
        self.valid_types = set(data.get("valid_types", []))
        self.required_in_changes = {norm(e) for e in
                                    data.get("required_elements_in_changes", [])}

        self.min_changes = data.get("min_changes", 1)
        self.min_findings = data.get("min_findings", 1)
        self.min_alternative = data.get("min_alternative_findings", 0)
        self.min_detail_len = data.get("min_detail_len", 40)

        self.required_findings = data.get("required_findings", [])
        self.alternative_findings = data.get("alternative_findings", [])

        self.causal_ru = data.get("causal_markers", DEFAULT_CAUSAL_RU)
        self.causal_en = data.get("causal_markers_en", DEFAULT_CAUSAL_EN)
        self.no_causal_categories = set(
            data.get("no_causal_categories", DEFAULT_NO_CAUSAL_CATEGORIES))
        self.filler = data.get("filler_words", DEFAULT_FILLER)

        # Шаблоны схемы ДОПОЛНЯЮТ библиотечные, а не заменяют их: иначе схема со своим
        # (устаревшим) списком молча отключает защиту от отрицаний. Так было со схемой 04_50.
        patterns = list(DEFAULT_DENIAL_PATTERNS)
        for p in data.get("denial_patterns") or []:
            if p not in patterns:
                patterns.append(p)
        self._denial_res = tuple(re.compile(p) for p in patterns)
        self._en_causal_re = re.compile(
            r"\b(" + "|".join(re.escape(m) for m in self.causal_en) + r")\b")

    @property
    def all_specs(self) -> dict:
        return {s["id"]: s for s in self.required_findings + self.alternative_findings}

    # -- предикаты ---------------------------------------------------------- #

    def filler_hit(self, text):
        """Первое слово-заглушка в тексте или None.

        Ищется как отдельное слово, а не подстрока: иначе «потом» находится внутри
        «потому что», и правдивое объяснение отклоняется как заглушка.
        """
        t = norm(text)
        for w in self.filler:
            wn = norm(w)
            if re.search(r"(?<![0-9a-zа-я])" + re.escape(wn) + r"(?![0-9a-zа-я])", t):
                return w
        return None

    def is_denial(self, text) -> bool:
        t = norm(text)
        return any(rx.search(t) for rx in self._denial_res)

    def has_causal_link(self, text, category) -> bool:
        if category in self.no_causal_categories:
            return True
        t = norm(text)
        if any(m in t for m in self.causal_ru):
            return True
        return bool(self._en_causal_re.search(t))

    @staticmethod
    def spec_categories(spec) -> set:
        if "categories" in spec:
            return {c.lower() for c in spec["categories"]}
        return {spec["category"].lower()}

    @staticmethod
    def spec_elements(spec) -> set:
        """Привязка к охватывающей функции ИЛИ к месту вызова. Обе правдивы."""
        return {norm(e) for e in spec.get("accepted_elements", [spec["element"]])}

    def record_matches_spec(self, record, spec) -> bool:
        if norm(record.get("element", "")) not in self.spec_elements(spec):
            return False
        cat = norm(record.get("category", ""))
        if cat not in self.spec_categories(spec):
            return False
        text = norm(str(record.get("detail", "")) + " " + str(record.get("finding", "")))
        if not any(all(kw in text for kw in group) for group in spec["keyword_groups"]):
            return False
        if self.is_denial(text):
            return False
        return self.has_causal_link(record.get("detail", ""), cat)

    # -- сопоставление ------------------------------------------------------ #

    def assignment(self, findings: list) -> tuple[dict, list]:
        """Сопоставление один к одному (алгоритм Куна).

        Одна запись закрывает не более одной спецификации. Иначе «сборная»
        запись, перечисляющая несколько дефектов, закрывала бы несколько
        обязательных меток разом — дефект 04_50-F001.
        """
        specs = self.all_specs
        owner: dict[int, str] = {}

        def candidates(spec):
            return [i for i, rec in enumerate(findings)
                    if isinstance(rec, dict) and self.record_matches_spec(rec, spec)]

        def augment(spec, visited):
            for i in candidates(spec):
                if i in visited:
                    continue
                visited.add(i)
                held = owner.get(i)
                if held is None or augment(specs[held], visited):
                    owner[i] = spec["id"]
                    return True
            return False

        for spec in self.required_findings:
            augment(spec, set())
        matched_alt = [s["id"] for s in self.alternative_findings if augment(s, set())]
        return {spec_id: idx for idx, spec_id in owner.items()}, matched_alt

    def matched_ids(self, findings: list) -> dict:
        return self.assignment(findings)[0]

    def substantive(self, findings: list) -> list:
        """Записи, сообщающие о дефекте. Отрицание в объём не засчитывается."""
        out = []
        for f in findings:
            if not isinstance(f, dict):
                continue
            if self.is_denial(str(f.get("detail", "")) + " " + str(f.get("finding", ""))):
                continue
            out.append(f)
        return out


# --------------------------------------------------------------------------- #
# Порождение видимого контракта
# --------------------------------------------------------------------------- #

def render_contract(schema: Schema, answer_field_docs: str = "") -> str:
    """Видимый контракт из той же схемы, по которой работают проверки.

    Смысл: скрытое правило невозможно, потому что и текст задания, и проверки
    порождаются из одного источника. Семейство B закрывается по построению,
    а не выверяется вручную перед сдачей.
    """
    s = schema
    lines = []
    lines.append("Ты анализируешь код и сдаёшь разбор в файл /app/answer.json.")
    lines.append("")
    lines.append(f"Анализируемый файл: {s.analyzed_file}")
    if s.analyzed_file_path != s.analyzed_file:
        lines.append(f"Полный путь: {s.analyzed_file_path}")
    lines.append("")

    lines.append("## Формат ответа")
    lines.append("")
    lines.append("```json")
    lines.append("{")
    lines.append(f'  "file": "{s.analyzed_file}",')
    lines.append('  "changes": [')
    lines.append('    {"element": "<имя>", "type": "<тип>", "description": "<что это>"}')
    lines.append("  ],")
    lines.append('  "important_findings": [')
    lines.append('    {"element": "<имя>", "category": "<категория>",')
    lines.append('     "finding": "<кратко>", "detail": "<механика дефекта>"}')
    lines.append("  ]")
    lines.append("}")
    lines.append("```")
    lines.append("")

    lines.append("## Объём")
    lines.append("")
    lines.append(f"- не менее {s.min_changes} записей в changes")
    lines.append(f"- не менее {s.min_findings} записей в important_findings")
    if s.min_alternative:
        lines.append(f"- сверх обязательных замечаний — не менее {s.min_alternative} "
                     f"из числа прочих технически корректных")
    lines.append("")

    lines.append("## Допустимые значения")
    lines.append("")
    lines.append("Элементы (поле element) — только из этого списка:")
    lines.append("")
    for e in s.valid_elements_raw:
        lines.append(f"- {e}")
    lines.append("")
    lines.append(f"Категории (поле category): {', '.join(sorted(s.valid_categories))}")
    if s.valid_types:
        lines.append(f"Типы (поле type в changes): {', '.join(sorted(s.valid_types))}")
    if s.required_in_changes:
        req = ", ".join(sorted(e for e in s.required_in_changes))
        lines.append(f"Обязательно опиши в changes: {req}")
    lines.append("")

    lines.append("## Требования к объяснению")
    lines.append("")
    lines.append("- detail обязан объяснять механику дефекта: какая операция его "
                 "создаёт и при каком сценарии он проявляется")
    lines.append("- название проблемы без причинно-следственного объяснения не "
                 "принимается; общая фраза «может привести к ошибке» причинной "
                 "связкой не считается")
    no_causal = ", ".join(sorted(s.no_causal_categories))
    if no_causal:
        lines.append(f"- исключение — категория {no_causal}: для неё сценарий "
                     f"срабатывания не требуется")
    lines.append("- причинная связка принимается на русском или на английском; "
                 "язык ответа не ограничен")
    lines.append("- привязать замечание можно как к охватывающей функции, так и "
                 "к конкретному месту вызова — обе формы принимаются")
    lines.append("- запись, утверждающая отсутствие дефекта («утечки нет», "
                 "«проверка не нужна», «вызов безопасен»), находкой не считается "
                 "и в объём important_findings не входит")
    lines.append("- одна запись закрывает не более одного замечания: перечисление "
                 "нескольких дефектов в одной записи их не закрывает")
    lines.append("- поле file обязано называть реально анализируемый файл")
    lines.append("- дословный повтор одного объяснения в разных записях не принимается")
    lines.append("")

    if answer_field_docs:
        lines.append(answer_field_docs)
        lines.append("")

    lines.append("## Что нельзя")
    lines.append("")
    lines.append("- изменять входные файлы (контроль sha256)")
    lines.append("- выдумывать элементы, которых нет в анализируемом коде")
    lines.append("- оставлять заглушки и филлер вместо содержания")
    return "\n".join(lines)


def load_schema(path) -> Schema:
    import json
    with open(path, "r", encoding="utf-8") as f:
        return Schema(json.load(f))
