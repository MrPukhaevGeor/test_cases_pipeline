#!/usr/bin/env python3
"""
Генератор корпуса контрольных ответов для кейса БКАС.

Берёт эталонный ответ и схему кейса, механически порождает набор ответов
с заранее известным ожидаемым reward:

  негативы (ожидается reward=0) — заведомо неверные разборы. Если верификатор
      выдаёт им 1, кейс завернут по семейству A;
  позитивы (ожидается reward=1) — содержательно верные разборы в иной форме.
      Если верификатор выдаёт им 0, кейс завернут по семейству B.

Это формализация раздела «Как будет проверено» из ревью УМР: «мутант со слитыми
метками и минимум два независимых отрицательных пересказа получают reward 0,
а минимум три правдивых пересказа получают reward 1. Любой иной исход — FAIL».

Негативы порождаются механически и полно: порча — операция разрушающая.
Позитивы механически порождаются лишь частично (перестановка, привязка к месту
вызова, английские причинные связки, добавление альтернатив) — настоящий
смысловой пересказ другими словами требует авторской руки. Такие позиции
создаются как заготовки и помечаются `needs_authoring`.

Использование:
    python bkas_mutate.py <путь-к-кейсу> [--oracle answer.json] [--out eval/corpus]
"""

from __future__ import annotations

import argparse
import copy
import json
import random
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path

random.seed(20260824)  # корпус обязан быть воспроизводимым


# --------------------------------------------------------------------------- #
# Заготовки формулировок
# --------------------------------------------------------------------------- #

# Отрицания дефекта. Ровно тот класс, который в 04_50 прошёл все 26 проверок:
# «не может» содержит подстроку «может», поэтому наивный matcher засчитывает
# опровержение как объяснение причины.
DENIALS = [
    "Здесь дефекта нет, проверка не нужна: вызов безопасен и данные всегда корректны.",
    "Утечки не возникает, ресурс освобождается сам, замечаний нет.",
    "Это не является уязвимостью, обработка избыточна и ничего исправлять не нужно.",
    "Код безопасен, риска нет, дополнительная валидация не требуется.",
    "Всё в порядке, нареканий нет, поведение оправдано.",
]

# Набор слов есть, причинно-следственного объяснения нет.
SOUP_TAIL = "проверка валидация обработка ошибка буфер ресурс освобождение статус контроль"

# Общая фраза без механики. Ревью прямо говорит: «общая фраза "может привести
# к ошибке" причинной связкой не считается».
GENERIC = "Это может привести к ошибке в работе программы при некоторых условиях."

SUBJECTIVE = "Плохой код, написано неаккуратно, мне не нравится такой стиль, надо переписать."

FILLER = "TODO дописать позже lorem ipsum dolor sit amet заглушка"

# Русская причинная связка -> английская. Схема 04_50 объявляет causal_markers_en,
# значит английская формулировка обязана приниматься. Если не принимается —
# это скрытое правило про язык, семейство B.
RU_TO_EN = {
    "если": "if",
    "когда": "when",
    "приводит к": "leads to",
    "приведёт к": "will lead to",
    "приведет к": "will lead to",
    "позволяет": "allows",
    "в результате": "as a result",
    "из-за": "due to",
    "поэтому": "therefore",
    "остаётся": "remains",
    "остается": "remains",
    "останется": "will remain",
    "вследствие": "because of",
}


# --------------------------------------------------------------------------- #
# Модель корпуса
# --------------------------------------------------------------------------- #

@dataclass
class CorpusItem:
    name: str
    expected_reward: int
    family: str          # какое семейство рубрики проверяет
    rationale: str       # что именно проверяется
    needs_authoring: bool = False


def _detail_keys(rec: dict) -> list[str]:
    """Поле с объяснением называется по-разному в разных кейсах."""
    return [k for k in ("detail", "description", "explanation", "rationale", "text")
            if k in rec]


def _findings_key(answer: dict) -> str | None:
    for k in ("important_findings", "findings", "issues", "remarks", "problems"):
        if isinstance(answer.get(k), list):
            return k
    return None


def _changes_key(answer: dict) -> str | None:
    for k in ("changes", "elements", "components"):
        if isinstance(answer.get(k), list):
            return k
    return None


# --------------------------------------------------------------------------- #
# Негативные мутации — ожидается reward 0
# --------------------------------------------------------------------------- #

def _denial_preserving(rec: dict, spec: dict | None, variant: int) -> str:
    """Отрицание, сохраняющее термины и причинную связку.

    Ключевой момент. Если просто написать «дефекта нет», запись потеряет и
    ключевые группы, и причинные маркеры — и будет отклонена любой проверкой,
    хоть полярность в ней есть, хоть нет. Такой мутант ничего не изолирует.

    Мутант из ревью устроен иначе: он упоминает требуемый дефект ровно теми же
    словами и с причинной связкой, но утверждает обратное. Именно на нём
    в 04_50 ответ с восемью отрицаниями прошёл все 26 проверок.
    """
    terms = ""
    if spec:
        groups = spec.get("keyword_groups") or []
        if groups:
            terms = " ".join(groups[variant % len(groups)])
    if not terms:
        keys = _detail_keys(rec)
        terms = " ".join(str(rec.get(keys[0], "")).split()[:6]) if keys else ""

    tails = [
        "формально присутствует, однако дефектом это не является: поведение "
        "безопасно при любых входных данных, поэтому проверка не нужна.",
        "упоминается в коде, но риска нет: ресурс освобождается сам, "
        "поэтому исправлять здесь нечего.",
        "выглядит подозрительно, однако уязвимости нет — вызов безопасен, "
        "поэтому дополнительная валидация избыточна.",
    ]
    return f"{terms} — {tails[variant % len(tails)]}"


def mut_denial_all(answer: dict, schema: dict) -> dict:
    """Все записи отрицают дефект, сохраняя его термины и причинную связку."""
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    reqs = {(r.get("element"), r.get("category")): r
            for r in schema.get("required_findings", [])}
    for i, rec in enumerate(out[fk]):
        spec = reqs.get((rec.get("element"), rec.get("category")))
        for k in _detail_keys(rec):
            rec[k] = _denial_preserving(rec, spec, i)
    return out


def mut_denial_partial(answer: dict, schema: dict, n: int = 2) -> dict:
    """Два независимых отрицательных пересказа — формулировка УМР дословно.

    Остальные записи остаются правдивыми, поэтому мутант проходит всё,
    кроме проверки полярности. Это и есть изоляция.
    """
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    reqs = {(r.get("element"), r.get("category")): r
            for r in schema.get("required_findings", [])}
    for i, rec in enumerate(out[fk][:n]):
        spec = reqs.get((rec.get("element"), rec.get("category")))
        for k in _detail_keys(rec):
            rec[k] = _denial_preserving(rec, spec, i)
    return out


SOFT_DENIAL_TAILS = [
    "в коде есть, но это не проблема: поведение допустимо, поэтому оставить как есть.",
    "присутствует, однако это нормально для такого кода, поэтому менять ничего не нужно.",
    "встречается, но это обычная практика, поэтому исправлять здесь смысла нет.",
]


def mut_denial_soft(answer: dict, schema: dict) -> dict:
    """«Мягкое» отрицание: дефект назван терминами схемы, но объявлен неважным.

    Отличается от mut_denial_all формулировкой: не «дефекта нет», а «это не проблема»,
    «это допустимо», «менять ничего не нужно». Такие ответы получали reward 1, пока
    в корпусе не было этого мутанта, а эвал показывал строгость 100%.
    """
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    reqs = {(r.get("element"), r.get("category")): r
            for r in schema.get("required_findings", [])}
    # Тексты записей обязаны различаться: иначе мутант отсекает проверка дублей,
    # а не детект отрицаний, и изоляции нет (так и было в первой версии мутанта).
    used = set()
    for i, rec in enumerate(out[fk]):
        spec = reqs.get((rec.get("element"), rec.get("category")))
        groups = (spec.get("keyword_groups") or []) if spec else []
        terms = " ".join(groups[i % len(groups)]) if groups else ""
        if not terms:
            keys = _detail_keys(rec)
            terms = " ".join(str(rec.get(keys[0], "")).split()[:6]) if keys else ""
        text = f"{terms} {SOFT_DENIAL_TAILS[i % len(SOFT_DENIAL_TAILS)]}"
        if text in used:
            text = f"{rec.get('element', '')}: {text}"
        used.add(text)
        for k in _detail_keys(rec):
            rec[k] = text
    return out


def mut_merged(answer: dict, schema: dict) -> dict:
    """Одна «сборная» запись, упоминающая сразу все обязательные дефекты.

    В 04_50 такая запись закрывала три обязательные метки разом, потому что
    совпадения не расходовались один к одному.
    """
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk or not out[fk]:
        return out

    reqs = schema.get("required_findings", [])
    terms = []
    for r in reqs:
        groups = r.get("keyword_groups") or []
        if groups:
            terms.extend(groups[0])
    blob = ", ".join(dict.fromkeys(terms)) or "переполнение буфера, SSRF, внедрение команды"

    merged = copy.deepcopy(out[fk][0])
    for k in _detail_keys(merged):
        merged[k] = (
            f"В коде одновременно присутствуют: {blob}. "
            f"Если эти места не исправить, это приводит к некорректной работе."
        )
    out[fk] = [merged]
    return out


def mut_fabricated_file(answer: dict) -> dict:
    """Разбор указывает на несуществующий файл (в 04_50 это был fabricated.c)."""
    out = copy.deepcopy(answer)
    if "file" in out:
        out["file"] = "fabricated_module.c"
    return out


def mut_keyword_soup(answer: dict, schema: dict) -> dict:
    """Термины на месте, причинно-следственного объяснения нет."""
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    reqs = schema.get("required_findings", [])
    for i, rec in enumerate(out[fk]):
        groups = reqs[i].get("keyword_groups") if i < len(reqs) else None
        words = " ".join(groups[0]) if groups else ""
        for k in _detail_keys(rec):
            rec[k] = f"{words} {SOUP_TAIL}".strip()
    return out


def mut_generic(answer: dict) -> dict:
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    for rec in out[fk]:
        for k in _detail_keys(rec):
            rec[k] = GENERIC
    return out


def mut_duplicate_detail(answer: dict) -> dict:
    """Одно объяснение скопировано во все записи."""
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk or not out[fk]:
        return out
    keys = _detail_keys(out[fk][0])
    if not keys:
        return out
    shared = out[fk][0][keys[0]]
    for rec in out[fk]:
        for k in _detail_keys(rec):
            rec[k] = shared
    return out


def mut_subjective(answer: dict) -> dict:
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    for rec in out[fk]:
        for k in _detail_keys(rec):
            rec[k] = SUBJECTIVE
    return out


def mut_filler(answer: dict) -> dict:
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    for rec in out[fk]:
        for k in _detail_keys(rec):
            rec[k] = FILLER
    return out


def mut_undercount(answer: dict, schema: dict) -> dict:
    """Записей меньше объявленного минимума — обязан падать легитимно."""
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    out[fk] = out[fk][:1]
    return out


def mut_invalid_element(answer: dict) -> dict:
    """Элемент, которого нет в анализируемом коде."""
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if fk and out[fk]:
        out[fk][0]["element"] = "nonexistent_helper_fn"
    ck = _changes_key(out)
    if ck and out[ck]:
        out[ck][0]["element"] = "nonexistent_helper_fn"
    return out


def mut_invalid_category(answer: dict) -> dict:
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if fk and out[fk]:
        out[fk][0]["category"] = "performance"
    return out


# --------------------------------------------------------------------------- #
# Позитивные мутации — ожидается reward 1
# --------------------------------------------------------------------------- #

def mut_reorder(answer: dict) -> dict:
    """Тот же разбор в другом порядке. Порядок нигде не объявлен контрактом."""
    out = copy.deepcopy(answer)
    for key in (_findings_key(out), _changes_key(out)):
        if key and len(out[key]) > 1:
            out[key] = list(reversed(out[key]))
    return out


def mut_callsite_binding(answer: dict, schema: dict) -> dict:
    """Привязка к месту вызова вместо охватывающей функции.

    В ревью 04_50: «привязка к месту вызова встречается в 16 случаях из 16»,
    и её отклонение названо скрытым правилом. Берём альтернативы из самой схемы,
    поэтому мутация остаётся в границах объявленного контракта.
    """
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    # Ключ — пара (элемент, категория): один элемент может нести несколько
    # обязательных находок разных категорий, и по одному элементу они схлопнутся,
    # а запись получит привязку из чужой спецификации.
    reqs = {(r.get("element"), r.get("category")): r
            for r in schema.get("required_findings", [])}
    for rec in out[fk]:
        spec = reqs.get((rec.get("element"), rec.get("category")))
        if not spec:
            continue
        alts = [e for e in spec.get("accepted_elements", []) if e != rec.get("element")]
        if alts:
            rec["element"] = alts[0]
    return out


def mut_english_causal(answer: dict, schema: dict) -> dict:
    """Причинные связки по-английски.

    Обязана проходить, если схема объявляет causal_markers_en. Если не проходит —
    язык ответа является скрытым правилом (семейство B).
    """
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    for rec in out[fk]:
        for k in _detail_keys(rec):
            text = rec[k]
            for ru, en in RU_TO_EN.items():
                text = re.sub(ru, en, text, flags=re.IGNORECASE)
            rec[k] = text
    return out


def mut_extra_alternative(answer: dict, schema: dict) -> dict:
    """Больше альтернативных находок, чем требует минимум. Полнее эталона — не хуже."""
    out = copy.deepcopy(answer)
    fk = _findings_key(out)
    if not fk:
        return out
    alts = schema.get("alternative_findings", [])
    have = {(r.get("element"), r.get("category")) for r in out[fk]}
    for spec in alts:
        key = (spec.get("element"), spec.get("category"))
        if key in have:
            continue
        groups = spec.get("keyword_groups") or [[]]
        words = " ".join(groups[0])
        out[fk].append({
            "element": spec.get("element"),
            "category": spec.get("category") or "code_quality",
            "finding": spec.get("id", "additional"),
            "detail": (f"{words}: если это место не исправить, "
                       f"проблема проявится при штатном сценарии работы."),
        })
        break
    return out


def stub_paraphrase(answer: dict) -> dict:
    """Заготовка под авторский пересказ: смысл тот же, слова другие.

    Механически не порождается — требует руки. Помечается needs_authoring,
    в прогоне пропускается, пока не заполнена.
    """
    out = copy.deepcopy(answer)
    out["_TODO"] = (
        "Переписать каждое объяснение другими словами, сохранив механику дефекта. "
        "Не использовать те же термины, что в эталоне. Убрать этот ключ после правки."
    )
    return out


# --------------------------------------------------------------------------- #
# Сборка корпуса
# --------------------------------------------------------------------------- #

def extract_oracle_from_solve(case: Path) -> Path | None:
    """Эталонный ответ из heredoc в solution/solve.sh -> eval/oracle_answer.json.

    Ищет блок `cat > /app/answer.json << 'JSON' ... JSON`. Без него эталон
    пришлось бы снимать руками, а это ручной шаг, на котором легко ошибиться.
    """
    sh = case / "solution" / "solve.sh"
    if not sh.is_file():
        return None
    text = sh.read_text(encoding="utf-8")
    m = re.search(r"cat\s*>\s*/app/answer\.json\s*<<\s*'?(\w+)'?[ \t]*\r?\n(.*?)\r?\n\1[ \t]*$",
                  text, re.S | re.M)
    if not m:
        return None
    try:
        json.loads(m.group(2))
    except ValueError:
        return None
    out = case / "eval" / "oracle_answer.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(m.group(2), encoding="utf-8")
    return out


def build_corpus(answer: dict, schema: dict) -> list[tuple[CorpusItem, dict]]:
    items: list[tuple[CorpusItem, dict]] = []

    def neg(name, fam, why, data, authoring=False):
        items.append((CorpusItem(name, 0, fam, why, authoring), data))

    def pos(name, fam, why, data, authoring=False):
        items.append((CorpusItem(name, 1, fam, why, authoring), data))

    pos("pos_oracle", "—", "эталонный ответ как есть; базовая проверка, что 1 достижима",
        copy.deepcopy(answer))

    neg("neg_denial_all", "A", "все объяснения — прямое опровержение дефекта",
        mut_denial_all(answer, schema))
    neg("neg_denial_partial", "A",
        "два независимых отрицательных пересказа (формулировка УМР дословно)",
        mut_denial_partial(answer, schema))
    neg("neg_denial_soft", "A",
        "дефект назван, но объявлен неважным: «это не проблема», «менять не нужно»",
        mut_denial_soft(answer, schema))
    neg("neg_merged", "A",
        "одна сборная запись на все обязательные метки; совпадения обязаны "
        "расходоваться один к одному",
        mut_merged(answer, schema))
    neg("neg_fabricated_file", "A", "разбор указывает на несуществующий файл",
        mut_fabricated_file(answer))
    neg("neg_keyword_soup", "A", "термины есть, причинного объяснения нет",
        mut_keyword_soup(answer, schema))
    neg("neg_generic", "A", "общая фраза «может привести к ошибке» вместо механики",
        mut_generic(answer))
    neg("neg_duplicate_detail", "A", "одно объяснение скопировано во все записи",
        mut_duplicate_detail(answer))
    neg("neg_subjective", "A", "субъективная оценка вместо разбора",
        mut_subjective(answer))
    neg("neg_filler", "A", "заглушки и филлер вместо содержания",
        mut_filler(answer))
    neg("neg_undercount", "B", "записей меньше объявленного минимума — обязан падать",
        mut_undercount(answer, schema))
    neg("neg_invalid_element", "A", "элемент отсутствует в анализируемом коде",
        mut_invalid_element(answer))
    neg("neg_invalid_category", "A", "категория вне объявленного множества",
        mut_invalid_category(answer))

    pos("pos_reorder", "B", "тот же разбор в другом порядке; порядок контрактом не задан",
        mut_reorder(answer))
    pos("pos_callsite", "B",
        "привязка к месту вызова вместо охватывающей функции (из accepted_elements схемы)",
        mut_callsite_binding(answer, schema))
    if schema.get("causal_markers_en"):
        pos("pos_english_causal", "B",
            "причинные связки по-английски; схема объявляет causal_markers_en",
            mut_english_causal(answer, schema))
    if schema.get("alternative_findings"):
        pos("pos_extra_alternative", "B",
            "альтернативных находок больше минимума; полнее эталона — не хуже",
            mut_extra_alternative(answer, schema))

    pos("pos_paraphrase_authored", "B",
        "смысловой пересказ другими словами — требует авторской правки",
        stub_paraphrase(answer), authoring=True)

    return items


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("case", type=Path)
    ap.add_argument("--oracle", type=Path,
                    help="эталонный answer.json; по умолчанию ищется в кейсе")
    ap.add_argument("--schema", type=Path,
                    help="answer_schema.json; по умолчанию tests/fixtures/")
    ap.add_argument("--out", type=Path, default=None,
                    help="каталог корпуса (по умолчанию <case>/eval/corpus)")
    args = ap.parse_args()

    case = args.case
    schema_path = args.schema or (case / "tests" / "fixtures" / "answer_schema.json")
    if not schema_path.is_file():
        print(f"схема не найдена: {schema_path}", file=sys.stderr)
        return 2
    schema = json.loads(schema_path.read_text(encoding="utf-8"))

    oracle_path = args.oracle
    if oracle_path is None:
        for cand in (case / "eval" / "oracle_answer.json",
                     case / "solution" / "answer.json",
                     case / "tests" / "fixtures" / "oracle_answer.json"):
            if cand.is_file():
                oracle_path = cand
                break
    if oracle_path is None:
        oracle_path = extract_oracle_from_solve(case)
        if oracle_path is not None:
            print("эталонный ответ взят из solution/solve.sh -> %s" % oracle_path)
    if oracle_path is None or not oracle_path.is_file():
        print("эталонный ответ не найден. Укажи --oracle.\n"
              "Автоматически он берётся из heredoc в solution/solve.sh "
              "(cat > /app/answer.json << 'JSON' ... JSON); там его не оказалось.",
              file=sys.stderr)
        return 2
    answer = json.loads(oracle_path.read_text(encoding="utf-8"))

    out = args.out or (case / "eval" / "corpus")
    out.mkdir(parents=True, exist_ok=True)

    items = build_corpus(answer, schema)
    manifest = []
    for meta, data in items:
        (out / f"{meta.name}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        manifest.append(asdict(meta))

    (out / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    n_neg = sum(1 for m in manifest if m["expected_reward"] == 0)
    n_pos = sum(1 for m in manifest if m["expected_reward"] == 1)
    n_todo = sum(1 for m in manifest if m["needs_authoring"])
    print(f"корпус собран: {out}")
    print(f"  негативов (ожидается 0): {n_neg}")
    print(f"  позитивов (ожидается 1): {n_pos}")
    if n_todo:
        print(f"  требуют авторской правки: {n_todo} — в прогоне пропускаются")
    return 0


if __name__ == "__main__":
    sys.exit(main())
