#!/usr/bin/env python3
"""
Генератор кейса БКАС.

Делит работу по линии «механическое / содержательное».

Механическое генератор делает сам и делает правильно: структура пакета,
Dockerfile с неизменяемым базовым образом и полным замыканием зависимостей,
tests/test.sh с корректным контрактом reward, task.toml со всеми обязательными
полями, видимый контракт, sha256 последним шагом, списки fail_to_pass и
pass_to_pass по факту собранных тестов.

Содержательное остаётся человеку или скиллу: какие в коде дефекты, как они
формулируются, какие группы ключевых слов их опознают. Это и есть настоящая
работа — генератор оставляет под неё размеченную дыру, а не заполняет
правдоподобным мусором.

Ключевое свойство: видимый контракт порождается из той же схемы, по которой
работают проверки. Скрытое правило становится невозможным по построению —
это семейство B, за которое заворачивали все три наших кейса.

Два шага:

    python bkas_new_case.py init  --from <исходники> --name b2c_case_XX_YY \\
                                  --language c --bank-domain b2c --out work/
    # ... автор заполняет tests/fixtures/answer_schema.json и solution/solve.sh
    python bkas_new_case.py finalize <кейс>

`finalize` перегенерирует контракт из схемы, посчитает sha256 и заполнит
списки тестов. Его надо повторять после каждой правки схемы.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bkas_matcher as bm  # noqa: E402


# Все генерируемые файлы пишутся с LF. На Windows Path.write_text по умолчанию даёт CRLF,
# а shell-скрипт с CRLF в Linux-контейнере не запускается («set: Illegal option -»).
# Заодно кейс, собранный на Windows и на Linux, получается побайтово одинаковым.
# Реализовано через open(): параметр newline у Path.write_text появился только в Python 3.10,
# а конвейер обязан работать на 3.8.
def _write_text_lf(self, data, encoding=None, errors=None):
    with open(str(self), "w", encoding=encoding or "utf-8", errors=errors, newline="\n") as f:
        return f.write(data)


Path.write_text = _write_text_lf


# --------------------------------------------------------------------------- #
# Шаблоны
# --------------------------------------------------------------------------- #

DOCKERFILE = '''\
# Базовый образ зафиксирован неизменяемым идентификатором (digest), а не тегом:
# две чистые сборки при любом состоянии реестра дают одни и те же байты.
# Платформа задана явно, поэтому набор пакетов не зависит от хоста сборки.
FROM --platform={platform} {base_image}

# Полное разрешение зависимостей: точные версии и хеши дистрибутивов.
# --no-deps запрещает подтянуть что-либо сверх перечисленного.
# Установка только на этапе сборки — во время проверки сеть отключена.
COPY requirements.txt /tmp/requirements.txt
RUN pip install --no-cache-dir --require-hashes --no-deps{pip_args} \\
        -r /tmp/requirements.txt \\
    && pip check \\
    && pip freeze --all > /opt/pip-freeze.txt \\
    && rm -f /tmp/requirements.txt

WORKDIR /app
COPY repo/ /app/

CMD ["/bin/bash"]
'''

TEST_SH = '''\
#!/bin/sh
# Verifier кейса {name}.
#
# Контракт логов:
#   /logs/verifier/reward.txt   — РОВНО одна строка: 0 или 1;
#   /logs/verifier/pytest.log   — полный вывод pytest;
#   /logs/verifier/verifier.log — почему именно такой reward.
#
# Итоговый reward пишется ПОСЛЕ прогона, поэтому значение, записанное агентом
# во время работы (в том числе при импорте его модуля), перетирается.
set -u

# Права могут теряться при распаковке архива на файловой системе без POSIX-битов.
chmod +x /tests/test.sh /solution/solve.sh 2>/dev/null || true

LOG_DIR="${{VERIFIER_LOG_DIR:-/logs/verifier}}"
mkdir -p "$LOG_DIR"

REWARD_FILE="$LOG_DIR/reward.txt"
PYTEST_LOG="$LOG_DIR/pytest.log"
DIAG_LOG="$LOG_DIR/verifier.log"

# Полное число объявленных проверок. Заполняется bkas_new_case.py finalize.
EXPECTED_TESTS={expected_tests}

: > "$PYTEST_LOG"
: > "$DIAG_LOG"
printf '0\\n' > "$REWARD_FILE"

log() {{ printf '%s\\n' "$*" >> "$DIAG_LOG"; }}

unset PYTHONPATH
unset PYTHONHOME
PYTHONNOUSERSITE=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONNOUSERSITE PYTEST_DISABLE_PLUGIN_AUTOLOAD

# Рабочий каталог со случайным именем: агент не может подготовить его заранее,
# а запуск из /app подхватил бы conftest.py и модули решения.
TRUSTED_WORK="$(mktemp -d 2>/dev/null || echo /run/verifier_work)"
mkdir -p "$TRUSTED_WORK/_isolate" 2>/dev/null || true
log "[verifier] рабочий каталог: $TRUSTED_WORK"

# Изоляция путей импорта, совместимая с Python 3.8+.
# Флаг -P делает то же самое, но появился только в 3.11: на более раннем
# интерпретаторе он даёт «Unknown option» уже ПОСЛЕ проверки доступности,
# и причина отказа по логам не читается. Поэтому используется sitecustomize.
cat > "$TRUSTED_WORK/_isolate/sitecustomize.py" <<'ISOLATE'
import os
import sys

_here = os.getcwd()
sys.path[:] = [p for p in sys.path if p not in ("", ".", _here)]
# Каталог верификатора доверенный. При --import-mode=importlib pytest сам его
# в sys.path не добавляет, и `import bkas_matcher` не находился бы: сбор тестов
# падал бы с ModuleNotFoundError, а reward был бы 0 даже у эталона.
sys.path.insert(0, "/tests")
ISOLATE

PY=""
for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 &&
       ( cd "$TRUSTED_WORK" && PYTHONPATH="$TRUSTED_WORK/_isolate" \\
         "$candidate" -s -c "import pytest" >/dev/null 2>&1 ); then
        PY="$candidate"
        break
    fi
done

if [ -z "$PY" ]; then
    log "[verifier] FATAL: рабочий python с pytest не найден"
    log "[verifier] outcome=environment_error reward=0"
    printf '0\\n' > "$REWARD_FILE"
    exit 0
fi

if [ ! -f /tests/test_verifier.py ]; then
    log "[verifier] FATAL: /tests/test_verifier.py отсутствует"
    log "[verifier] outcome=environment_error reward=0"
    printf '0\\n' > "$REWARD_FILE"
    exit 0
fi

( cd "$TRUSTED_WORK" && PYTHONPATH="$TRUSTED_WORK/_isolate" \\
  "$PY" -s -m pytest /tests/test_verifier.py -v --tb=short \\
      --import-mode=importlib -p no:cacheprovider ) > "$PYTEST_LOG" 2>&1
PYTEST_CODE=$?

log "[verifier] pytest exit code: $PYTEST_CODE"

RESULT=0
case "$PYTEST_CODE" in
    0)
        PASSED="$(grep -oE '[0-9]+ passed' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        SKIPPED="$(grep -oE '[0-9]+ skipped' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        DESELECTED="$(grep -oE '[0-9]+ deselected' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        : "${{PASSED:=0}}"; : "${{SKIPPED:=0}}"; : "${{DESELECTED:=0}}"
        log "[verifier] passed=$PASSED skipped=$SKIPPED deselected=$DESELECTED (ожидается $EXPECTED_TESTS)"
        if [ "$EXPECTED_TESTS" -le 0 ]; then
            # Пустой набор не может быть успехом: значит finalize собрал кейс
            # с нулём проверок и это дефект самого кейса, а не решения.
            log "[verifier] outcome=no_expected_tests reward=0"
        elif [ "$SKIPPED" -ne 0 ] || [ "$DESELECTED" -ne 0 ]; then
            log "[verifier] outcome=checks_skipped reward=0"
        elif [ "$PASSED" -ne "$EXPECTED_TESTS" ]; then
            log "[verifier] outcome=unexpected_test_count reward=0 ($PASSED из $EXPECTED_TESTS)"
        else
            RESULT=1
            log "[verifier] outcome=all_checks_passed reward=1"
        fi
        ;;
    1) log "[verifier] outcome=checks_failed reward=0" ;;
    2) log "[verifier] outcome=pytest_interrupted reward=0" ;;
    3) log "[verifier] outcome=pytest_internal_error reward=0" ;;
    4) log "[verifier] outcome=pytest_usage_error reward=0" ;;
    5) log "[verifier] outcome=no_tests_collected reward=0" ;;
    *) log "[verifier] outcome=unexpected_exit_${{PYTEST_CODE}} reward=0" ;;
esac

# Единственная авторитетная запись: перекрывает всё, что мог оставить агент.
printf '%s\\n' "$RESULT" > "$REWARD_FILE"
log "[verifier] final reward=$RESULT"
exit 0
'''

# Верификатор кейса — тонкий. Вся логика сопоставления живёт в bkas_matcher,
# который вендорится в tests/. Кейс задаёт только данные.
TEST_VERIFIER = '''\
"""Verifier кейса {name}.

Логика сопоставления — в bkas_matcher (общая библиотека, вендорится рядом).
Здесь только данные кейса и стандартный набор проверок. Ничего специфического
для кейса в поведении матчера нет: если нужно другое поведение, это меняется
в схеме, а не здесь.

sha256 входных файлов и фикстуры вычислены bkas_new_case.py finalize.
"""
import json
import os

import pytest

import bkas_matcher as bm

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

INPUT_SHA256 = {input_sha}
SCHEMA_SHA256 = "{schema_sha}"

SCHEMA = bm.load_schema(FIXTURE)
ANALYZED_FILE = SCHEMA.analyzed_file


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _findings(data):
    return [f for f in data.get("important_findings", []) if isinstance(f, dict)]


def _changes(data):
    return [c for c in data.get("changes", []) if isinstance(c, dict)]


# ── pass_to_pass ────────────────────────────────────────────────────────────

@pytest.mark.parametrize("fname", sorted(INPUT_SHA256))
def test_inputs_untouched(fname):
    """Входные файлы существуют и не изменены агентом."""
    path = os.path.join(APP, fname)
    assert os.path.isfile(path), fname + " отсутствует в /app"
    assert bm.sha256(path) == INPUT_SHA256[fname], fname + " изменён агентом"


def test_fixture_schema_intact():
    """Фикстура схемы не подменена."""
    assert bm.sha256(FIXTURE) == SCHEMA_SHA256, "answer_schema.json изменён"


def test_visible_contract_matches_fixture():
    """Видимое задание и исполняемые проверки описывают одно и то же.

    Контракт порождается из этой же схемы, поэтому проверка сторожит
    рассинхронизацию, а не выверяет ручную работу. Скрытых правил нет.
    """
    path = os.path.join(APP, "system_prompt.txt")
    assert os.path.isfile(path), "system_prompt.txt отсутствует в /app"
    text = open(path, "r", encoding="utf-8").read()
    low = text.lower()
    for element in SCHEMA.valid_elements_raw:
        assert element.lower() in low, "элемент '" + element + "' не в видимом контракте"
    for category in SCHEMA.valid_categories:
        assert category in low, "категория '" + category + "' не в видимом контракте"
    for type_name in SCHEMA.valid_types:
        assert type_name in low, "тип '" + type_name + "' не в видимом контракте"
    # Пороги ищутся во фразе целиком: голое число совпало бы с любой цифрой
    # в тексте и делало бы проверку тривиальной.
    assert ("changes" in low and str(SCHEMA.min_changes) in text), (
        "порог changes не объявлен в видимом контракте")
    assert ("important_findings" in low and str(SCHEMA.min_findings) in text), (
        "порог findings не объявлен в видимом контракте")
    assert ANALYZED_FILE in text, "имя анализируемого файла не в видимом контракте"


# ── fail_to_pass: структура ─────────────────────────────────────────────────

def test_answer_file_exists():
    assert os.path.isfile(ANSWER), "агент не создал /app/answer.json"


def test_answer_is_valid_json():
    with open(ANSWER, "r", encoding="utf-8") as f:
        json.load(f)


def test_answer_has_required_fields():
    data = _load()
    for key in ("file", "changes", "important_findings"):
        assert key in data, "в ответе нет поля '" + key + "'"
    assert isinstance(data["changes"], list), "changes обязан быть списком"
    assert isinstance(data["important_findings"], list), "findings обязан быть списком"


def test_file_field_names_analyzed_file():
    """Разбор, указывающий на выдуманный файл, контракт не выполняет."""
    data = _load()
    value = bm.norm(data.get("file", "")).replace("\\\\", "/")
    name = bm.norm(ANALYZED_FILE)
    full = bm.norm(SCHEMA.analyzed_file_path)
    assert value in (name, full) or value.endswith("/" + name), (
        "поле file называет '" + str(data.get("file")) + "', "
        "а анализируется '" + ANALYZED_FILE + "'")


# ── fail_to_pass: changes ───────────────────────────────────────────────────

def test_changes_minimum_count():
    assert len(_changes(_load())) >= SCHEMA.min_changes, (
        "в changes меньше " + str(SCHEMA.min_changes) + " записей")


def test_changes_required_elements_present():
    got = {{bm.norm(c.get("element", "")) for c in _changes(_load())}}
    missing = SCHEMA.required_in_changes - got
    assert not missing, "в changes не описаны: " + ", ".join(sorted(missing))


def test_changes_elements_exist():
    for c in _changes(_load()):
        el = bm.norm(c.get("element", ""))
        assert el in SCHEMA.valid_elements, "элемент '" + el + "' отсутствует в коде"


def test_changes_types_valid():
    if not SCHEMA.valid_types:
        return
    for c in _changes(_load()):
        t = c.get("type", "")
        assert t in SCHEMA.valid_types, "недопустимый type: '" + str(t) + "'"


def test_changes_descriptions_substantive():
    """Описание объясняет роль элемента, а не повторяет его имя."""
    for c in _changes(_load()):
        d = str(c.get("description", ""))
        assert d.strip(), "описание '" + str(c.get("element")) + "' пустое"
        assert bm.norm(d) != bm.norm(c.get("element", "")), (
            "описание повторяет имя элемента")
        assert len(d) >= SCHEMA.min_detail_len, (
            "описание '" + str(c.get("element")) + "' не раскрывает роль элемента")


def test_changes_not_filler():
    for c in _changes(_load()):
        w = SCHEMA.filler_hit(c.get("description", ""))
        assert w is None, "заглушка '" + str(w) + "' в описании"


# ── fail_to_pass: findings ──────────────────────────────────────────────────

def test_findings_minimum_count():
    """Записи, отрицающие дефект, в объём не засчитываются."""
    subst = SCHEMA.substantive(_findings(_load()))
    assert len(subst) >= SCHEMA.min_findings, (
        "содержательных findings меньше " + str(SCHEMA.min_findings))


def test_findings_categories_valid():
    for f in _findings(_load()):
        cat = f.get("category", "")
        assert cat in SCHEMA.valid_categories, "недопустимая категория: '" + str(cat) + "'"


def test_findings_elements_exist():
    for f in _findings(_load()):
        el = bm.norm(f.get("element", ""))
        assert el in SCHEMA.valid_elements, "элемент '" + el + "' отсутствует в коде"


def test_findings_details_explain_mechanics():
    """detail объясняет механику дефекта: при каком условии он проявляется.

    Правило объявлено в видимом контракте (причинная связка, для code_quality
    не требуется). Буквального названия элемента кода в тексте требовать нельзя:
    правдивое объяснение вроде «адрес задан литералом в глобальной переменной»
    элемент по имени не называет, но дефект описывает верно, а такое требование
    в задании нигде не объявлено. Длина служит только отсечкой пустых заглушек
    и мерой качества не является.
    """
    for f in _findings(_load()):
        d = str(f.get("detail", ""))
        assert d.strip(), "detail пустой"
        cat = bm.norm(f.get("category", ""))
        assert SCHEMA.has_causal_link(d, cat), (
            "detail не объясняет механику: нужна причинная связка "
            "(при каком условии дефект проявляется и к чему приводит)")
        assert len(d) >= SCHEMA.min_detail_len, "detail не раскрывает механику"
        w = SCHEMA.filler_hit(d)
        assert w is None, "заглушка '" + str(w) + "' в detail"


def test_findings_have_finding_field():
    for f in _findings(_load()):
        assert str(f.get("finding", "")).strip(), "поле finding пустое"


def test_findings_no_duplicate_pairs():
    seen = set()
    for f in _findings(_load()):
        key = (bm.norm(f.get("element", "")), bm.norm(f.get("category", "")),
               bm.norm(f.get("finding", "")))
        assert key not in seen, "дублирующаяся запись: " + str(key)
        seen.add(key)


def test_findings_details_distinct():
    """Одно объяснение, скопированное в несколько записей, не закрывает их все."""
    seen = set()
    for f in _findings(_load()):
        d = bm.norm(f.get("detail", ""))
        assert d not in seen, "detail дословно повторяется между записями"
        seen.add(d)


# ── fail_to_pass: покрытие контракта ────────────────────────────────────────

REQUIRED_IDS = [s["id"] for s in SCHEMA.required_findings]


@pytest.mark.parametrize("spec_id", REQUIRED_IDS)
def test_required_finding_present(spec_id):
    """Обязательное замечание закрыто, причём отдельной записью.

    Сопоставление один к одному: «сборная» запись, перечисляющая несколько
    дефектов, закрывает не более одного.
    """
    matched = SCHEMA.matched_ids(_findings(_load()))
    assert spec_id in matched, "не закрыто обязательное замечание: " + spec_id


def test_minimum_alternative_findings():
    if SCHEMA.min_alternative <= 0:
        return
    _, alts = SCHEMA.assignment(_findings(_load()))
    assert len(alts) >= SCHEMA.min_alternative, (
        "закрыто альтернативных замечаний " + str(len(alts)) +
        ", требуется " + str(SCHEMA.min_alternative))
'''

SCHEMA_STUB = {
    "_HOWTO": [
        "Это единственный источник правды кейса. Из него порождается видимый",
        "контракт и по нему работают проверки — поэтому скрытых правил быть не может.",
        "После любой правки запусти: python bkas_new_case.py finalize <кейс>",
        "",
        "Заполнить надо: valid_elements, required_elements_in_changes, пороги,",
        "required_findings и alternative_findings. Это содержательная работа —",
        "какие в коде дефекты и по каким словам их узнать.",
        "",
        "keyword_groups: AND внутри группы, OR между группами. Группы должны",
        "покрывать разные способы сказать одно и то же, иначе правдивый пересказ",
        "другими словами будет отклонён (семейство B).",
        "",
        "accepted_elements: и охватывающая функция, и место вызова. Обе привязки",
        "правдивы, отклонять одну из них нельзя.",
        "",
        "В required_findings попадают ТОЛЬКО дефекты, следующие из приложенного",
        "кода. Гипотетические угрозы — в alternative_findings или никуда",
        "(семейство C: 04_50 завернули за обязательные buffer overflow и SSRF,",
        "которые из кода не следовали).",
        "",
        "min_detail_len — отсечка пустых заглушек, а НЕ мера качества. Основная",
        "проверка содержательности — упоминание конкретного элемента кода.",
    ],
    "analyzed_file": "ЗАПОЛНИТЬ.c",
    "analyzed_file_path": "ЗАПОЛНИТЬ/путь/ЗАПОЛНИТЬ.c",
    "valid_elements": ["ЗАПОЛНИТЬ"],
    "valid_categories": ["security", "resource_leak", "error_handling", "code_quality"],
    "valid_types": ["function", "variable", "import", "statement"],
    "required_elements_in_changes": ["ЗАПОЛНИТЬ"],
    "min_changes": 4,
    "min_findings": 5,
    "min_alternative_findings": 1,
    "min_detail_len": 40,
    "required_findings": [
        {
            "id": "ЗАПОЛНИТЬ_id",
            "element": "ЗАПОЛНИТЬ",
            "accepted_elements": ["ЗАПОЛНИТЬ", "место_вызова"],
            "category": "error_handling",
            "rationale": "Механика дефекта: какая операция его создаёт и когда проявляется.",
            "keyword_groups": [
                ["термин", "не провер"],
                ["термин", "игнорир"],
            ],
        }
    ],
    "alternative_findings": [],
}

# Пункты anti_cheat отражают то, что реально исполняется проверками.
# Список правится вместе с шаблоном verifier, иначе он станет декларацией
# вместо описания поведения.
ANTI_CHEAT = [
    "итоговый reward выставляется только verifier и только после прогона: "
    "значение, записанное решением в /logs во время импорта модуля или через "
    "atexit, перекрывается",
    "reward=1 возможен лишь при полном совпадении числа пройденных проверок с "
    "объявленным и нулевом числе пропущенных или отфильтрованных",
    "verifier запускается из каталога со случайным именем с изолированными "
    "путями импорта: модуль, conftest или плагин из каталога, доступного "
    "агенту, на прогон не влияет",
    "входные файлы и фикстура схемы защищены сверкой sha256: правка или "
    "удаление любого из них даёт reward 0",
    "видимый контракт порождается из той же схемы, по которой работают "
    "проверки, поэтому скрытых требований не существует по построению",
    "содержательность объяснений проверяется наличием причинной связки "
    "(при каком условии дефект проявляется), а не длиной текста",
    "одно объяснение, скопированное в несколько записей, закрывает не более "
    "одной позиции контракта",
    "запись, отрицающая дефект, не засчитывается в объём и не закрывает "
    "обязательное замечание",
    "окружение воспроизводимо: базовый образ закреплён digest, зависимости "
    "заданы полным замыканием с хешами, сборка выполняет pip check",
]


# --------------------------------------------------------------------------- #
# init
# --------------------------------------------------------------------------- #

def resolve_digest(image: str) -> str | None:
    """Превращает тег в неизменяемый идентификатор через реестр."""
    if "@sha256:" in image:
        return image
    try:
        subprocess.run(["docker", "pull", "-q", image],
                       capture_output=True, text=True, timeout=300, check=True)
        out = subprocess.run(
            ["docker", "inspect", "--format", "{{index .RepoDigests 0}}", image],
            capture_output=True, text=True, check=True).stdout.strip()
        return out or None
    except Exception:
        return None


def cmd_init(args) -> int:
    name = args.name
    root = args.out / name
    if root.exists() and not args.force:
        print(f"каталог уже существует: {root} (--force чтобы перезаписать)",
              file=sys.stderr)
        return 2
    if root.exists():
        shutil.rmtree(root)

    base = args.base_image
    # Дайджест обязан быть настоящим: '@sha256:<подставить>' из шаблона конфига
    # проверку на подстроку проходит, а образ по нему не разрешится.
    if "@sha256:" in base and not re.search(r"@sha256:[0-9a-f]{64}$", base):
        print(f"ОТКАЗ: '{base}' содержит @sha256:, но дайджест не похож на настоящий\n"
              f"(ожидается 64 шестнадцатеричных символа).\n"
              f"Похоже, значение из шаблона конфига не заполнено.",
              file=sys.stderr)
        return 3
    if "@sha256:" not in base:
        resolved = resolve_digest(base)
        if resolved:
            print(f"базовый образ разрешён в дайджест:\n  {resolved}")
            base = resolved
        else:
            print(
                f"ОТКАЗ: базовый образ '{base}' задан изменяемым тегом, а разрешить\n"
                f"его в дайджест не удалось (нет Docker или нет сети).\n\n"
                f"Незафиксированный образ — причина возврата 02_11, 04_47 и 04_50,\n"
                f"уровень требования MUST. Подставлять тег генератор не будет.\n\n"
                f"Варианты: запустить Docker и повторить, либо передать образ\n"
                f"с дайджестом: --base-image python:3.11.9-slim@sha256:<...>",
                file=sys.stderr)
            return 3

    for sub in ("environment/repo", "solution", "tests/fixtures", "eval"):
        (root / sub).mkdir(parents=True, exist_ok=True)

    # Артефакт кейса
    src = args.source
    copied = []
    if src.is_dir():
        for p in sorted(src.rglob("*")):
            if p.is_file():
                dst = root / "environment" / "repo" / p.name
                shutil.copy2(p, dst)
                copied.append(p.name)
    elif src.is_file():
        shutil.copy2(src, root / "environment" / "repo" / src.name)
        copied.append(src.name)
    if not copied:
        print(f"в источнике нет файлов: {src}", file=sys.stderr)
        return 2

    # Индекс пакетов контура: в закрытом периметре PyPI недоступен.
    pip_args = ""
    if args.pip_index_url:
        pip_args += " --index-url " + args.pip_index_url
        if args.pip_trusted_host:
            pip_args += " --trusted-host " + args.pip_trusted_host

    (root / "environment" / "Dockerfile").write_text(
        DOCKERFILE.format(base_image=base, platform=args.platform,
                          pip_args=pip_args), encoding="utf-8")

    # Полное замыкание с хешами получаем от pip; без него --require-hashes не поедет.
    (root / "environment" / "requirements.txt").write_text(
        "# Полное транзитивное замыкание с хешами.\n"
        "# Сгенерировать:  pip-compile --generate-hashes --allow-unsafe\n"
        "# Пока не сгенерировано, сборка намеренно не пройдёт — это лучше,\n"
        "# чем незафиксированные зависимости, за которые заворачивают.\n",
        encoding="utf-8")

    (root / "tests" / "fixtures" / "answer_schema.json").write_text(
        json.dumps(SCHEMA_STUB, ensure_ascii=False, indent=2), encoding="utf-8")

    # Матчер вендорится: кейс обязан быть самодостаточным каталогом.
    shutil.copy2(Path(__file__).resolve().parent / "bkas_matcher.py",
                 root / "tests" / "bkas_matcher.py")

    (root / "solution" / "solve.sh").write_text(
        "#!/bin/sh\n"
        "# Эталонное решение: пишет разбор, закрывающий весь контракт схемы.\n"
        "# Заполняется автором. Именно этот ответ идёт в oracle-прогон и в\n"
        "# корпус контролей (bkas_mutate.py), поэтому он обязан быть правдивым.\n"
        "cat > /app/answer.json << 'JSON'\n"
        "{\n  \"file\": \"ЗАПОЛНИТЬ\",\n  \"changes\": [],\n"
        "  \"important_findings\": []\n}\n"
        "JSON\n",
        encoding="utf-8")

    (root / "eval" / ".gitignore").write_text(
        "# Материалы прогона в пакет задачи не входят (02_11-F002).\n*\n!.gitignore\n",
        encoding="utf-8")

    meta = {
        "name": name, "language": args.language, "bank_domain": args.bank_domain,
        "build_tool": args.build_tool, "difficulty": args.difficulty,
        "source": args.source_ref, "team": args.team,
        "base_image": base, "platform": args.platform,
    }
    (root / "eval" / "_generator.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\nкаркас создан: {root}")
    print(f"  артефакт: {', '.join(copied)}")
    print("\nдальше — содержательная часть:")
    print(f"  1. заполнить {root / 'tests/fixtures/answer_schema.json'}")
    print(f"  2. заполнить {root / 'solution/solve.sh'}")
    print(f"  3. сгенерировать requirements.txt с хешами")
    print(f"  4. python bkas_new_case.py finalize {root}")
    return 0


# --------------------------------------------------------------------------- #
# finalize
# --------------------------------------------------------------------------- #

STUB_RE = re.compile(r"ЗАПОЛНИТЬ")

# Проверки, которые обязаны проходить и до решения задачи: целостность входов
# и согласованность видимого контракта с фикстурой.
P2P_MARKERS = ("inputs_untouched", "fixture_schema_intact", "visible_contract")


def collect_test_ids(root: Path) -> tuple[list[str], str]:
    """Возвращает идентификаторы собранных тестов и диагностику при сбое."""
    # Путь обязан быть абсолютным: cwd переставлен в tests/, и относительный
    # путь склеился бы сам с собой.
    target = (root / "tests" / "test_verifier.py").resolve()
    proc = subprocess.run(
        [sys.executable, "-m", "pytest", str(target),
         "--collect-only", "-q", "-p", "no:cacheprovider"],
        capture_output=True, text=True, cwd=str((root / "tests").resolve()),
    )
    ids = []
    for line in proc.stdout.splitlines():
        line = line.strip()
        # Строки сбора выглядят как 'test_verifier.py::test_x[param]'.
        # Итоговые строки вида '17 tests collected' отсеиваются отсутствием '::'.
        if "::" not in line or line.startswith("="):
            continue
        if " " in line:  # защита от строк с посторонним текстом
            line = line.split(" ", 1)[0]
            if "::" not in line:
                continue
        ids.append("tests/" + line.split("/")[-1] if "/" in line else "tests/" + line)
    diag = (proc.stdout or "") + (proc.stderr or "")
    return ids, diag


def cmd_finalize(args) -> int:
    root = args.case
    fixture = root / "tests" / "fixtures" / "answer_schema.json"
    if not fixture.is_file():
        print(f"нет схемы: {fixture}", file=sys.stderr)
        return 2

    raw = fixture.read_text(encoding="utf-8")
    if STUB_RE.search(raw):
        print("схема содержит незаполненные места (ЗАПОЛНИТЬ). "
              "Это содержательная часть — генератор её не выдумывает.", file=sys.stderr)
        return 3

    data = json.loads(raw)
    data.pop("_HOWTO", None)
    fixture.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    schema = bm.Schema(data)

    # 1. Видимый контракт из схемы — согласованность по построению.
    repo = root / "environment" / "repo"
    contract = bm.render_contract(schema)
    (repo / "system_prompt.txt").write_text(contract, encoding="utf-8")

    (root / "instruction.md").write_text(
        f"# Задание\n\n"
        f"В каталоге `/app` лежит анализируемый материал и файл "
        f"`system_prompt.txt` с полным контрактом ответа.\n\n"
        f"Прочитай `system_prompt.txt` и сдай разбор в `/app/answer.json` "
        f"строго по описанному формату.\n\n"
        f"Анализируемый файл: `{schema.analyzed_file}`\n",
        encoding="utf-8")

    # 2. sha256 — ПОСЛЕДНИМ шагом, после того как контракт записан.
    inputs = {p.name: bm.sha256(p) for p in sorted(repo.iterdir()) if p.is_file()}
    schema_sha = bm.sha256(fixture)

    gen = root / "eval" / "_generator.json"
    meta = json.loads(gen.read_text(encoding="utf-8")) if gen.is_file() else {}

    (root / "tests" / "test_verifier.py").write_text(
        TEST_VERIFIER.format(
            name=meta.get("name", root.name),
            input_sha=json.dumps(inputs, ensure_ascii=False, indent=4),
            schema_sha=schema_sha),
        encoding="utf-8")

    # 3. Списки тестов — по факту собранных, а не по памяти.
    ids, diag = collect_test_ids(root)

    # Пустой сбор означает сломанный verifier: без этой проверки кейс уехал бы
    # с EXPECTED_TESTS=0 и пустыми списками, а обнаружилось бы это только на
    # прогоне evidence.
    if not ids:
        print("ОТКАЗ: сбор тестов вернул пустой список — verifier не собирается.\n"
              "Обычные причины: ошибка импорта bkas_matcher, несовместимая схема,\n"
              "отсутствие pytest у текущего интерпретатора.\n\n"
              "Вывод pytest:\n" + diag.strip(), file=sys.stderr)
        return 3

    p2p = [i for i in ids if any(k in i for k in P2P_MARKERS)]
    f2p = [i for i in ids if i not in p2p]

    if not p2p:
        print("ОТКАЗ: не собрано ни одной проверки pass_to_pass.\n"
              "Кейс без них не проверяет «не сломай остальное».", file=sys.stderr)
        return 3
    if not f2p:
        print("ОТКАЗ: не собрано ни одной проверки fail_to_pass.\n"
              "Кейс без них ничего не требует от решения.", file=sys.stderr)
        return 3

    (root / "tests" / "test.sh").write_text(
        TEST_SH.format(name=meta.get("name", root.name), expected_tests=len(ids)),
        encoding="utf-8")

    # 4. task.toml
    def toml_list(items, indent="    "):
        return "\n".join(f'{indent}"{i}",' for i in items)

    def toml_strings(items, indent="    "):
        out = []
        for item in items:
            out.append(f'{indent}"{item}",')
        return "\n".join(out)

    required = ("bank_domain", "language", "build_tool", "difficulty", "source", "team")
    missing = [k for k in required if not str(meta.get(k, "")).strip()]
    if missing:
        print(f"в метаданных не заполнено: {', '.join(missing)}", file=sys.stderr)
        return 3

    (root / "task.toml").write_text(f'''\
schema_version = "1.1"

[task]
name        = "bkas/{meta['name'].replace('_', '-')}"
description = "Агент анализирует {schema.analyzed_file} и сдаёт структурированный разбор в answer.json. Верификатор проверяет схему, существование элементов, содержательность объяснений и покрытие контракта: {len(schema.required_findings)} обязательных замечаний плюс не менее {schema.min_alternative} из пула альтернатив. В обязательный контракт входят только дефекты, следующие из приложенного кода."
authors     = [{{name = "{meta['team']}", email = "{meta['team']}@example.ru"}}]
keywords    = ["code-review", "{meta['language']}", "structured-output"]

[agent]
timeout_sec = 1800.0

[environment]
os                = "linux"
allow_internet    = false
build_timeout_sec = 300.0
memory_mb         = 1024

[verifier]
timeout_sec = 120.0

[metadata]
task_type       = "agentic"
bank_domain     = "{meta['bank_domain']}"
language        = "{meta['language']}"
build_tool      = "{meta['build_tool']}"
difficulty      = "{meta['difficulty']}"
source          = "{meta['source']}"
team            = "{meta['team']}"
verifier_method = "execution_test"
uses_judge      = false
base_image      = "{meta['base_image']}"

anti_cheat = [
{toml_strings(ANTI_CHEAT)}
]

fail_to_pass = [
{toml_list(f2p)}
]

pass_to_pass = [
{toml_list(p2p)}
]
''', encoding="utf-8")

    for script in (root / "tests" / "test.sh", root / "solution" / "solve.sh"):
        script.chmod(0o755)

    # Сбор тестов оставляет байткод-кеш: в пакет задачи он не входит, а при
    # сверке sha256 в tests/ создаёт лишний файл.
    for cache in root.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    for pyc in root.rglob("*.pyc"):
        pyc.unlink(missing_ok=True)

    print(f"кейс собран: {root}")
    print(f"  проверок: {len(ids)} ({len(f2p)} f2p + {len(p2p)} p2p)")
    print(f"  контракт перегенерирован из схемы")
    print(f"  sha256 посчитан последним шагом")
    print("\nдальше:")
    print(f"  python bkas.py run {root} --mode fast")
    print("    (без Docker: validate + корпус + эвал + эмуляция test.sh;")
    print("     эталонный ответ берётся из solution/solve.sh сам)")
    print(f"  python bkas.py eval {root} --mode docker")
    print("    (честный прогон: нужен Docker и pytest с хешами в environment/requirements.txt)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    i = sub.add_parser("init", help="создать каркас кейса")
    i.add_argument("--from", dest="source", type=Path, required=True)
    i.add_argument("--name", required=True)
    i.add_argument("--out", type=Path, default=Path("work"))
    i.add_argument("--language", required=True)
    i.add_argument("--bank-domain", required=True,
                   help="банковский домен или продуктовая область. Дефолта нет "
                        "намеренно: 02_11 завернули за placeholder, а правдоподобное "
                        "но неверное значение хуже — его не видно глазами")
    i.add_argument("--team", default="b2c-team")
    i.add_argument("--build-tool", default="pip")
    i.add_argument("--difficulty", default="medium",
                   choices=("easy", "medium", "hard"))
    i.add_argument("--source-ref", required=True,
                   help="источник задачи: internal-jira/XXX или ссылка на PR")
    i.add_argument("--base-image", default="python:3.11.9-slim")
    i.add_argument("--platform", default="linux/amd64")
    i.add_argument("--pip-index-url", default="",
                   help="индекс пакетов контура; без него сборка пойдёт в PyPI")
    i.add_argument("--pip-trusted-host", default="")
    i.add_argument("--force", action="store_true")
    i.set_defaults(func=cmd_init)

    f = sub.add_parser("finalize", help="перегенерировать контракт, sha256, task.toml")
    f.add_argument("case", type=Path)
    f.set_defaults(func=cmd_finalize)

    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
