"""Имитация модели для проверки draft без ключа и без сети.

Слушает 127.0.0.1 и отвечает на /v1/chat/completions (как Cloud.ru) и /v1/messages
(как Anthropic) текстом из файла. Это НЕ модель: ответ заранее записан руками.
Проверяется только цепочка: запрос -> разбор ответа -> файлы кейса -> проверки.

  python imitaciya-modeli/mock_llm.py imitaciya-modeli/otvet-modeli-0447.txt [порт]
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

REPLY = Path(sys.argv[1]).read_text(encoding="utf-8")
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8765


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])).decode("utf-8"))
        n = len(json.dumps(body, ensure_ascii=False))
        if self.path == "/v1/chat/completions":
            if not (self.headers.get("Authorization") or "").startswith("Bearer "):
                return self._send(401, {"error": {"message": "нет Bearer"}})
            print(f"запрос openai, модель {body.get('model')}, {n} символов")
            return self._send(200, {"choices": [{"message": {"role": "assistant", "content": REPLY},
                                                 "finish_reason": "stop"}],
                                    "usage": {"prompt_tokens": 0, "completion_tokens": 0}})
        if self.path == "/v1/messages":
            if not self.headers.get("x-api-key"):
                return self._send(401, {"error": {"message": "нет x-api-key"}})
            print(f"запрос anthropic, модель {body.get('model')}, {n} символов")
            return self._send(200, {"content": [{"type": "text", "text": REPLY}],
                                    "stop_reason": "end_turn",
                                    "usage": {"input_tokens": 0, "output_tokens": 0}})
        self._send(404, {"error": "not found"})


print(f"имитация модели слушает http://127.0.0.1:{PORT}/v1  (Ctrl+C — остановить)")
HTTPServer(("127.0.0.1", PORT), H).serve_forever()
