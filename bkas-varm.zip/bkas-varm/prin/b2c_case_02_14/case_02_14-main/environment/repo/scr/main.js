'use strict';

const VALID_SEVERITIES = ['MAJOR', 'MINOR', 'INFO'];
const MARKERS = ['[Критерий:', 'Причина:', 'Последствия:', 'Решение:', 'Источник:'];

/**
 * Проверяет наличие всех пяти компонентов в detailedDescription.
 * реализация проверяет только наличие, но не порядок.
 */
function checkDescription(desc) {
  if (typeof desc !== 'string') return false;
  return MARKERS.every((m) => desc.includes(m));
}

/**
 * Валидатор ответа code-review по  правилам формата.
 *
 * @param {string} answerText - JSON-ответ ревьюера (массив объектов) в виде строки
 * @returns {{validJson: boolean, isEmpty: boolean, itemChecks: Array, allValid: boolean}}
 */
function validateReviewAnswer(answerText) {
  const text = String(answerText == null ? '' : answerText);

  // считаем ответ валидным JSON, если он начинается с '['
  const validJson = text.trim().startsWith('[');

  let arr = [];
  try {
    arr = JSON.parse(text);
  } catch (e) {
    arr = [];
  }
  if (!Array.isArray(arr)) arr = [];

  const isEmpty = arr.length === 0;

  const itemChecks = arr.map((it) => ({
    filePathOk: !!it && it.filePath === 'unknown_path.java',
    severityOk: !!(it && it.severity),
    descriptionOk: checkDescription(it && it.detailedDescription),
  }));

  const allValid =
    validJson &&
    !isEmpty &&
    itemChecks.every((c) => c.filePathOk && c.severityOk && c.descriptionOk);

  return { validJson, isEmpty, itemChecks, allValid };
}

module.exports = { validateReviewAnswer };
