#!/bin/bash
set -e
REPO_DIR="${REPO_DIR:-/app/repo}"

cat > "$REPO_DIR/src/main.js" << 'JSEOF'
'use strict';

const VALID_SEVERITIES = ['MAJOR', 'MINOR', 'INFO'];
const MARKERS = ['[Критерий:', 'Причина:', 'Последствия:', 'Решение:', 'Источник:'];

/** Проверяет, что все пять компонентов присутствуют В УКАЗАННОМ ПОРЯДКЕ. */
function markersInOrder(desc) {
  if (typeof desc !== 'string') return false;
  let pos = -1;
  for (const m of MARKERS) {
    const idx = desc.indexOf(m, pos + 1);
    if (idx <= pos) return false;
    pos = idx;
  }
  return true;
}

/**
 * Валидатор ответа code-review по детерминированным правилам формата.
 *
 * @param {string} answerText - JSON-ответ ревьюера (массив объектов) в виде строки
 * @returns {{validJson: boolean, isEmpty: boolean, itemChecks: Array, allValid: boolean}}
 */
function validateReviewAnswer(answerText) {
  let arr;
  let validJson;
  try {
    arr = JSON.parse(String(answerText));
    validJson = Array.isArray(arr);
  } catch (e) {
    validJson = false;
  }

  if (!validJson) {
    return { validJson: false, isEmpty: false, itemChecks: [], allValid: false };
  }

  const isEmpty = arr.length === 0;

  const itemChecks = arr.map((it) => ({
    filePathOk: !!it && it.filePath === 'unknown_path.java',
    severityOk: !!it && VALID_SEVERITIES.includes(it.severity),
    descriptionOk: !!it && markersInOrder(it.detailedDescription),
  }));

  const allValid =
    validJson &&
    (isEmpty || itemChecks.every((c) => c.filePathOk && c.severityOk && c.descriptionOk));

  return { validJson, isEmpty, itemChecks, allValid };
}

module.exports = { validateReviewAnswer };
JSEOF

echo " src/main.js исправлен (эталонное решение)"
