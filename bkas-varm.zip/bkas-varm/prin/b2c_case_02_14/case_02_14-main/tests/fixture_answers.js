'use strict';

// Набор данных ответов ревьюера (в виде строк) и ожидаемых результатов валидации.
// Ожидаемые значения выведены по правилам формата рубрики:
//   - валидный JSON-массив;
//   - filePath === 'unknown_path.java';
//   - severity ∈ {MAJOR, MINOR, INFO};
//   - detailedDescription содержит 5 компонентов В ПОРЯДКЕ:
//       [Критерий: ...], Причина:, Последствия:, Решение:, Источник:
//   - пустой ответ [] считается валидным (проблем не найдено).

const GOOD_DESC =
  '[Критерий:  Логическая целостность]\n' +
  'Причина: Ручная параллельная группировка усложняет код.\n' +
  'Последствия: Ухудшение читаемости и поддерживаемости.\n' +
  'Решение: Использовать groupingByConcurrent.\n' +
  'Источник: Java Concurrency in Practice';

const OUT_OF_ORDER_DESC =
  '[Критерий:  Безопасность]\n' +
  'Источник: OWASP ASVS\n' +
  'Причина: X.\n' +
  'Последствия: Y.\n' +
  'Решение: Z.';

const validItem = {
  filePath: 'unknown_path.java',
  codeChanges: 'return transactions.stream().collect(Collectors.groupingByConcurrent(Transaction::getUserId));',
  changesDescription: 'Java: Ручная параллельная группировка',
  detailedDescription: GOOD_DESC,
  codeChangesStartLine: 68,
  severity: 'MINOR',
};

// Валидный непустой ответ.
const validSingle = {
  text: JSON.stringify([validItem]),
  expected: {
    validJson: true,
    isEmpty: false,
    itemChecks: [{ filePathOk: true, severityOk: true, descriptionOk: true }],
    allValid: true,
  },
};

// Пустой ответ [] — валиден (проблем нет).
const emptyAnswer = {
  text: '[]',
  expected: { validJson: true, isEmpty: true, itemChecks: [], allValid: true },
};

// Невалидный JSON.
const invalidJson = {
  text: '[{ "filePath": "unknown_path.java", severity: MAJOR ',
  expected: { validJson: false, isEmpty: false, itemChecks: [], allValid: false },
};

// detailedDescription: компоненты присутствуют, но в неверном порядке.
const descOutOfOrder = {
  text: JSON.stringify([{ ...validItem, detailedDescription: OUT_OF_ORDER_DESC }]),
  expected: {
    validJson: true,
    isEmpty: false,
    itemChecks: [{ filePathOk: true, severityOk: true, descriptionOk: false }],
    allValid: false,
  },
};

// Недопустимое значение severity.
const badSeverity = {
  text: JSON.stringify([{ ...validItem, severity: 'CRITICAL' }]),
  expected: {
    validJson: true,
    isEmpty: false,
    itemChecks: [{ filePathOk: true, severityOk: false, descriptionOk: true }],
    allValid: false,
  },
};

// Неверный filePath (проверка, которая и в базе работает корректно) — регрессия.
const badFilePath = {
  text: JSON.stringify([{ ...validItem, filePath: 'AuthService.java' }]),
  expected: {
    validJson: true,
    isEmpty: false,
    itemChecks: [{ filePathOk: false, severityOk: true, descriptionOk: true }],
    allValid: false,
  },
};

module.exports = {
  GOOD_DESC,
  OUT_OF_ORDER_DESC,
  validItem,
  validSingle,
  emptyAnswer,
  invalidJson,
  descOutOfOrder,
  badSeverity,
  badFilePath,
};
