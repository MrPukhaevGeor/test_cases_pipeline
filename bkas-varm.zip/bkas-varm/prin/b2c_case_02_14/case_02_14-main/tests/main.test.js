'use strict';

const path = require('path');
const { validateReviewAnswer } = require(path.join(__dirname, '..', 'src', 'main.js'));
const {
  GOOD_DESC,
  validItem,
  validSingle,
  emptyAnswer,
  invalidJson,
  descOutOfOrder,
  badSeverity,
  badFilePath,
} = require('./fixture_answers.js');

//реализация правил (источник истины для случайных проверок) 
const VALID_SEVERITIES = ['MAJOR', 'MINOR', 'INFO'];
const MARKERS = ['[Критерий:', 'Причина:', 'Последствия:', 'Решение:', 'Источник:'];

function refMarkersInOrder(desc) {
  if (typeof desc !== 'string') return false;
  let pos = -1;
  for (const m of MARKERS) {
    const idx = desc.indexOf(m, pos + 1);
    if (idx <= pos) return false;
    pos = idx;
  }
  return true;
}
function reference(answerText) {
  let arr;
  let validJson;
  try {
    arr = JSON.parse(String(answerText));
    validJson = Array.isArray(arr);
  } catch (e) {
    validJson = false;
  }
  if (!validJson) return { validJson: false, isEmpty: false, itemChecks: [], allValid: false };
  const isEmpty = arr.length === 0;
  const itemChecks = arr.map((it) => ({
    filePathOk: !!it && it.filePath === 'unknown_path.java',
    severityOk: !!it && VALID_SEVERITIES.includes(it.severity),
    descriptionOk: !!it && refMarkersInOrder(it.detailedDescription),
  }));
  const allValid = validJson && (isEmpty || itemChecks.every((c) => c.filePathOk && c.severityOk && c.descriptionOk));
  return { validJson, isEmpty, itemChecks, allValid };
}

describe('validateReviewAnswer', () => {
  // fail_to_pass #1: пустой ответ [] валиден.
  test('пустой ответ [] признаётся валидным', () => {
    expect(validateReviewAnswer(emptyAnswer.text)).toEqual(emptyAnswer.expected);
  });

  // fail_to_pass #2: невалидный JSON отвергается.
  test('невалидный JSON отвергается', () => {
    const r = validateReviewAnswer(invalidJson.text);
    expect(r.validJson).toBe(false);
    expect(r.allValid).toBe(false);
  });

  // fail_to_pass #3: нарушенный порядок компонентов detailedDescription.
  test('нарушение порядка компонентов описания отвергается', () => {
    expect(validateReviewAnswer(descOutOfOrder.text)).toEqual(descOutOfOrder.expected);
  });

  // fail_to_pass #4: недопустимое значение severity.
  test('недопустимое значение severity отвергается', () => {
    expect(validateReviewAnswer(badSeverity.text)).toEqual(badSeverity.expected);
  });

  // fail_to_pass #5: случайные ответы — защита от захардкоженных результатов.
  test('валидация корректна на случайно построенных ответах', () => {
    const rnd = (n) => Math.floor(Math.random() * n);
    const cases = [];

    // гарантированно «пробивающие» случаи
    cases.push('[]'); // пусто
    cases.push('[{ broken json '); // невалидный JSON
    cases.push(JSON.stringify([{ ...validItem, severity: 'WEIRD' }])); // плохой severity
    cases.push(
      JSON.stringify([
        { ...validItem, detailedDescription: 'Причина: X\n[Критерий: Y]\nПоследствия: Z\nРешение: W\nИсточник: S' },
      ])
    ); // порядок нарушен

    // случайные валидные/дефектные варианты
    for (let i = 0; i < 20; i++) {
      const item = { ...validItem };
      const defect = rnd(5);
      if (defect === 1) item.severity = ['WEIRD', 'BAD', 'x', ''][rnd(4)];
      if (defect === 2) item.filePath = ['Other.java', '', 'unknown.java'][rnd(3)];
      if (defect === 3) item.detailedDescription = 'Источник: S\nПричина: X\nПоследствия: Z\nРешение: W\n[Критерий: Y]';
      if (defect === 4) item.detailedDescription = 'Причина: X\nПоследствия: Z'; // не все компоненты
      cases.push(JSON.stringify([item]));
    }

    for (const text of cases) {
      expect(validateReviewAnswer(text)).toEqual(reference(text));
    }
  });

  // pass_to_pass: корректный непустой ответ валиден.
  test('корректный ответ признаётся валидным', () => {
    expect(validateReviewAnswer(validSingle.text)).toEqual(validSingle.expected);
  });

  // pass_to_pass: результат имеет ровно заявленную контрактом форму
  // (документированные поля {validJson, isEmpty, itemChecks, allValid}).
  test('результат содержит поля validJson/isEmpty/itemChecks/allValid', () => {
    const r = validateReviewAnswer(validSingle.text);
    expect(Object.keys(r).sort()).toEqual(['allValid', 'isEmpty', 'itemChecks', 'validJson']);
  });

  // pass_to_pass: неверный filePath отклоняется (проверка, работающая и в базе).
  test('неверный filePath помечается как невалидный', () => {
    expect(validateReviewAnswer(badFilePath.text)).toEqual(badFilePath.expected);
  });
});
