#!/bin/bash
set -u
REPO_DIR="${REPO_DIR:-/app/repo}"
REWARD_FILE="${REWARD_FILE:-/logs/verifier/reward.txt}"
LOG_FILE="${LOG_FILE:-/logs/verifier/pytest.log}"
TEST_SRC="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$(dirname "$REWARD_FILE")" "$(dirname "$LOG_FILE")"
echo "0" > "$REWARD_FILE"

EXPECTED_TESTS=8

[ -d "$REPO_DIR" ] || { echo "no repo dir" > "$LOG_FILE"; exit 0; }
[ -f "$REPO_DIR/src/main.js" ] || { echo "no src/main.js" > "$LOG_FILE"; exit 0; }

VDIR="$(mktemp -d)"
trap 'rm -rf "$VDIR"' EXIT
mkdir -p "$VDIR/src" "$VDIR/test"
cp -r "$REPO_DIR/src/." "$VDIR/src/"
cp "$TEST_SRC/main.test.js"       "$VDIR/test/main.test.js"
cp "$TEST_SRC/fixture_answers.js" "$VDIR/test/fixture_answers.js"
cat > "$VDIR/jest.config.js" <<'CFG'
module.exports = { testEnvironment: 'node', rootDir: __dirname, testMatch: ['**/test/**/*.test.js'], verbose: true };
CFG

JEST_BIN="$REPO_DIR/node_modules/.bin/jest"
[ -x "$JEST_BIN" ] || JEST_BIN="$(command -v jest || true)"
[ -x "$JEST_BIN" ] || { echo "jest not available" > "$LOG_FILE"; exit 0; }

"$JEST_BIN" --config "$VDIR/jest.config.js" --ci --runInBand > "$LOG_FILE" 2>&1
CODE=$?
cat "$LOG_FILE"

PASSED="$(grep -Eo '[0-9]+ passed' "$LOG_FILE" | grep -Eo '[0-9]+' | head -1)"
TOTAL="$(grep -Eo '[0-9]+ total'  "$LOG_FILE" | grep -Eo '[0-9]+' | head -1)"
if [ "$CODE" -eq 0 ] && [ "${PASSED:-0}" -eq "$EXPECTED_TESTS" ] && [ "${TOTAL:-0}" -eq "$EXPECTED_TESTS" ]; then
    echo "1" > "$REWARD_FILE"; echo " Полный набор из $EXPECTED_TESTS проверок пройден. reward=1"
else
    echo "0" > "$REWARD_FILE"; echo " Проверки не пройдены (passed=${PASSED:-0}/${TOTAL:-0}, code=$CODE). reward=0"
fi
exit 0
