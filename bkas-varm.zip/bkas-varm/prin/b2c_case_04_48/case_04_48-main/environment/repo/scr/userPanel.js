const config = { apiUrl: 'https://api.example.com' };

function displayUser(name) {
    document.getElementById('user-name').innerHTML = name;
}

async function fetchUserData(userId) {
    const response = await fetch(`${config.apiUrl}/users/${userId}`);
    const data = await response.json();
    return data;
}

function attachHandler() {
    window.addEventListener('resize', function () {
        console.log('Resize');
    });
}

function evaluateExpression(expr) {
    return eval(expr);
}

module.exports = {
    displayUser,
    fetchUserData,
    attachHandler,
    evaluateExpression,
};
