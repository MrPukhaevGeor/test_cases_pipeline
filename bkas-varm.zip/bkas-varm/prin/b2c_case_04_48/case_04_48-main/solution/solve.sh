#!/bin/bash
set -e

# Эталонное решение: патчим src/userPanel.js так, чтобы все тесты в
# test/userPanel.test.js проходили. Это имитирует то, что должен
# сделать агент — реально исправить код, а не описать проблему текстом.

REPO_DIR="${REPO_DIR:-/app/repo}"

cat > "$REPO_DIR/src/userPanel.js" << 'JSEOF'
const config = { apiUrl: 'https://api.example.com' };

// ИСПРАВЛЕНО: textContent вместо innerHTML — исключает XSS
function displayUser(name) {
    document.getElementById('user-name').textContent = name;
}

// ИСПРАВЛЕНО: проверка HTTP-статуса и обработка сетевых ошибок
async function fetchUserData(userId) {
    const response = await fetch(`${config.apiUrl}/users/${userId}`);
    if (!response.ok) {
        throw new Error(`HTTP ${response.status} while fetching user ${userId}`);
    }
    return response.json();
}

// ИСПРАВЛЕНО: возвращаем cleanup-функцию, которая снимает обработчик
function attachHandler() {
    const handler = () => console.log('Resize');
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
}

// ИСПРАВЛЕНО: eval больше не используется — только безопасная арифметика
function evaluateExpression(expr) {
    if (typeof expr !== 'string' || !/^[\d+\-*/().\s]+$/.test(expr)) {
        throw new Error('Unsupported expression');
    }
    // Function(...) с проверенным regexp — безопаснее eval, но всё ещё
    // ограничен только арифметикой, без доступа к глобальному scope.
    return Function(`"use strict"; return (${expr});`)();
}

module.exports = {
    displayUser,
    fetchUserData,
    attachHandler,
    evaluateExpression,
};
JSEOF

echo "✅ src/userPanel.js исправлен (эталонное решение)"
