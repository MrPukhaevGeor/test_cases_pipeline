#!/bin/bash

# Verifier: подкладывает тестовый файл в репозиторий агента непосредственно
# перед запуском (агент НЕ видит тесты заранее — они не лежат в environment/repo/
# на старте), затем запускает npm test и оценивает результат по коду выхода.

REPO_DIR="${REPO_DIR:-/app/repo}"
REWARD_FILE="${REWARD_FILE:-/logs/verifier/reward.txt}"
LOG_FILE="${LOG_FILE:-/logs/verifier/pytest.log}"
TEST_SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

mkdir -p "$(dirname "$REWARD_FILE")"
mkdir -p "$(dirname "$LOG_FILE")"

if [ ! -d "$REPO_DIR" ]; then
    echo "❌ Репозиторий $REPO_DIR не найден!" | tee "$LOG_FILE"
    echo "0" > "$REWARD_FILE"
    exit 0
fi

# Anti-cheat: тестовый файл не лежит в репозитории агента на старте.
# Подкладываем его прямо перед прогоном, тем самым агент не мог его увидеть
# и подогнать решение под конкретные assertion-ы заранее.
mkdir -p "$REPO_DIR/test"
cp "$TEST_SOURCE_DIR/userPanel.test.js" "$REPO_DIR/test/userPanel.test.js"

cd "$REPO_DIR" || { echo "0" > "$REWARD_FILE"; exit 0; }

npm test > "$LOG_FILE" 2>&1
TEST_EXIT_CODE=$?
cat "$LOG_FILE"

# Убираем за собой — verifier-тест не должен оставаться артефактом в репозитории.
rm -f "$REPO_DIR/test/userPanel.test.js"
rmdir "$REPO_DIR/test" 2>/dev/null

if [ "$TEST_EXIT_CODE" -eq 0 ]; then
    echo "1" > "$REWARD_FILE"
    echo "✅ Все тесты прошли! Награда: 1"
else
    echo "0" > "$REWARD_FILE"
    echo "❌ Тесты не прошли (exit code: $TEST_EXIT_CODE). Награда: 0"
fi
