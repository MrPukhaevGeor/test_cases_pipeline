/**
 * @jest-environment jsdom
 */

const { displayUser, fetchUserData, attachHandler, evaluateExpression } = require('../src/userPanel');

beforeEach(() => {
    document.body.innerHTML = '<div id="user-name"></div>';
});

test('displayUser не должен вставлять HTML-разметку из пользовательского ввода (XSS)', () => {
    const payload = '<img src=x onerror="window.__xss = true">';
    displayUser(payload);

    const el = document.getElementById('user-name');
    // При innerHTML без санитизации здесь появится реальный <img> тег.
    // При textContent / безопасной вставке тег останется текстом.
    expect(el.querySelector('img')).toBeNull();
});

test('evaluateExpression не должен пользоваться глобальным eval, но обычная арифметика должна считаться', () => {
    const evalSpy = jest.spyOn(global, 'eval');

    expect(evaluateExpression('2 + 2')).toBe(4);
    expect(evalSpy).not.toHaveBeenCalled();

    evalSpy.mockRestore();
});

test('evaluateExpression не должен выполнять произвольный код как побочный эффект', () => {
    global.__pwned = false;
    try {
        evaluateExpression('global.__pwned = true');
    } catch (e) {
        // Допустимо: реализация вправе отклонить небезопасное выражение ошибкой.
    }
    expect(global.__pwned).toBe(false);
    delete global.__pwned;
});

test('attachHandler должен возвращать cleanup-функцию, снимающую resize-listener', () => {
    const addSpy = jest.spyOn(window, 'addEventListener');
    const removeSpy = jest.spyOn(window, 'removeEventListener');

    const cleanup = attachHandler();
    expect(typeof cleanup).toBe('function');

    const [, registeredHandler] = addSpy.mock.calls[0];
    cleanup();
    expect(removeSpy).toHaveBeenCalledWith('resize', registeredHandler);

    addSpy.mockRestore();
    removeSpy.mockRestore();
});

test('fetchUserData должен бросать ошибку при HTTP-ошибке и сетевом сбое, а не падать на .json()', async () => {
    global.fetch = jest.fn().mockResolvedValue({
        ok: false,
        status: 500,
        json: async () => { throw new Error('should not be called'); },
    });
    await expect(fetchUserData('123')).rejects.toThrow();

    global.fetch = jest.fn().mockRejectedValue(new Error('network down'));
    await expect(fetchUserData('123')).rejects.toThrow('network down');

    delete global.fetch;
});
