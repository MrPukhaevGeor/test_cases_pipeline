#!/bin/sh
# Verifier кейса t50.
#
# Контракт логов:
#   /logs/verifier/reward.txt   — РОВНО одна строка: 0 или 1;
#   /logs/verifier/pytest.log   — полный вывод pytest;
#   /logs/verifier/verifier.log — почему именно такой reward.
#
# Итоговый reward пишется ПОСЛЕ прогона, поэтому значение, записанное агентом
# во время работы (в том числе при импорте его модуля), перетирается.
set -u

# Права могут теряться при распаковке архива на файловой системе без POSIX-битов.
chmod +x /tests/test.sh /solution/solve.sh 2>/dev/null || true

LOG_DIR="${VERIFIER_LOG_DIR:-/logs/verifier}"
mkdir -p "$LOG_DIR"

REWARD_FILE="$LOG_DIR/reward.txt"
PYTEST_LOG="$LOG_DIR/pytest.log"
DIAG_LOG="$LOG_DIR/verifier.log"

# Полное число объявленных проверок. Заполняется bkas_new_case.py finalize.
EXPECTED_TESTS=26

: > "$PYTEST_LOG"
: > "$DIAG_LOG"
printf '0\n' > "$REWARD_FILE"

log() { printf '%s\n' "$*" >> "$DIAG_LOG"; }

unset PYTHONPATH
unset PYTHONHOME
PYTHONNOUSERSITE=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONNOUSERSITE PYTEST_DISABLE_PLUGIN_AUTOLOAD

# Рабочий каталог со случайным именем: агент не может подготовить его заранее,
# а запуск из /app подхватил бы conftest.py и модули решения.
TRUSTED_WORK="$(mktemp -d 2>/dev/null || echo /run/verifier_work)"
mkdir -p "$TRUSTED_WORK/_isolate" 2>/dev/null || true
log "[verifier] рабочий каталог: $TRUSTED_WORK"

# Изоляция путей импорта, совместимая с Python 3.8+.
# Флаг -P делает то же самое, но появился только в 3.11: на более раннем
# интерпретаторе он даёт «Unknown option» уже ПОСЛЕ проверки доступности,
# и причина отказа по логам не читается. Поэтому используется sitecustomize.
cat > "$TRUSTED_WORK/_isolate/sitecustomize.py" <<'ISOLATE'
import os
import sys

_here = os.getcwd()
sys.path[:] = [p for p in sys.path if p not in ("", ".", _here)]
# Каталог верификатора доверенный. При --import-mode=importlib pytest сам его
# в sys.path не добавляет, и `import bkas_matcher` не находился бы: сбор тестов
# падал бы с ModuleNotFoundError, а reward был бы 0 даже у эталона.
sys.path.insert(0, "/tests")
ISOLATE

PY=""
for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 &&
       ( cd "$TRUSTED_WORK" && PYTHONPATH="$TRUSTED_WORK/_isolate" \
         "$candidate" -s -c "import pytest" >/dev/null 2>&1 ); then
        PY="$candidate"
        break
    fi
done

if [ -z "$PY" ]; then
    log "[verifier] FATAL: рабочий python с pytest не найден"
    log "[verifier] outcome=environment_error reward=0"
    printf '0\n' > "$REWARD_FILE"
    exit 0
fi

if [ ! -f /tests/test_verifier.py ]; then
    log "[verifier] FATAL: /tests/test_verifier.py отсутствует"
    log "[verifier] outcome=environment_error reward=0"
    printf '0\n' > "$REWARD_FILE"
    exit 0
fi

( cd "$TRUSTED_WORK" && PYTHONPATH="$TRUSTED_WORK/_isolate" \
  "$PY" -s -m pytest /tests/test_verifier.py -v --tb=short \
      --import-mode=importlib -p no:cacheprovider ) > "$PYTEST_LOG" 2>&1
PYTEST_CODE=$?

log "[verifier] pytest exit code: $PYTEST_CODE"

RESULT=0
case "$PYTEST_CODE" in
    0)
        PASSED="$(grep -oE '[0-9]+ passed' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        SKIPPED="$(grep -oE '[0-9]+ skipped' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        DESELECTED="$(grep -oE '[0-9]+ deselected' "$PYTEST_LOG" | grep -oE '[0-9]+' | head -1)"
        : "${PASSED:=0}"; : "${SKIPPED:=0}"; : "${DESELECTED:=0}"
        log "[verifier] passed=$PASSED skipped=$SKIPPED deselected=$DESELECTED (ожидается $EXPECTED_TESTS)"
        if [ "$EXPECTED_TESTS" -le 0 ]; then
            # Пустой набор не может быть успехом: значит finalize собрал кейс
            # с нулём проверок и это дефект самого кейса, а не решения.
            log "[verifier] outcome=no_expected_tests reward=0"
        elif [ "$SKIPPED" -ne 0 ] || [ "$DESELECTED" -ne 0 ]; then
            log "[verifier] outcome=checks_skipped reward=0"
        elif [ "$PASSED" -ne "$EXPECTED_TESTS" ]; then
            log "[verifier] outcome=unexpected_test_count reward=0 ($PASSED из $EXPECTED_TESTS)"
        else
            RESULT=1
            log "[verifier] outcome=all_checks_passed reward=1"
        fi
        ;;
    1) log "[verifier] outcome=checks_failed reward=0" ;;
    2) log "[verifier] outcome=pytest_interrupted reward=0" ;;
    3) log "[verifier] outcome=pytest_internal_error reward=0" ;;
    4) log "[verifier] outcome=pytest_usage_error reward=0" ;;
    5) log "[verifier] outcome=no_tests_collected reward=0" ;;
    *) log "[verifier] outcome=unexpected_exit_${PYTEST_CODE} reward=0" ;;
esac

# Единственная авторитетная запись: перекрывает всё, что мог оставить агент.
printf '%s\n' "$RESULT" > "$REWARD_FILE"
log "[verifier] final reward=$RESULT"
exit 0
