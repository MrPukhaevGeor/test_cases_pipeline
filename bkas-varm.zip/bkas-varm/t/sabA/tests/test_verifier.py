"""Verifier кейса t50.

Логика сопоставления — в bkas_matcher (общая библиотека, вендорится рядом).
Здесь только данные кейса и стандартный набор проверок. Ничего специфического
для кейса в поведении матчера нет: если нужно другое поведение, это меняется
в схеме, а не здесь.

sha256 входных файлов и фикстуры вычислены bkas_new_case.py finalize.
"""
import json
import os

import pytest

import bkas_matcher as bm

APP = "/app"
ANSWER = os.path.join(APP, "answer.json")
HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(HERE, "fixtures", "answer_schema.json")

INPUT_SHA256 = {
    "diff.txt": "a0a4d533e43e7d5d5e4765b58fbc305e8298e5b1d9fb569bd696aca74291c66a",
    "system_prompt.txt": "432eee823fc097e4664cd8159022ead2a01666fa7c7df205088a12968ecaea46"
}
SCHEMA_SHA256 = "3311db9fd7b5d96bbc5d5b3354070b70d7e878652a9013376c97a9dd71a8885e"

SCHEMA = bm.load_schema(FIXTURE)
ANALYZED_FILE = SCHEMA.analyzed_file


def _load():
    with open(ANSWER, "r", encoding="utf-8") as f:
        return json.load(f)


def _findings(data):
    return [f for f in data.get("important_findings", []) if isinstance(f, dict)]


def _changes(data):
    return [c for c in data.get("changes", []) if isinstance(c, dict)]


# ── pass_to_pass ────────────────────────────────────────────────────────────

@pytest.mark.parametrize("fname", sorted(INPUT_SHA256))
def test_inputs_untouched(fname):
    """Входные файлы существуют и не изменены агентом."""
    path = os.path.join(APP, fname)
    assert os.path.isfile(path), fname + " отсутствует в /app"
    assert bm.sha256(path) == INPUT_SHA256[fname], fname + " изменён агентом"


def test_fixture_schema_intact():
    """Фикстура схемы не подменена."""
    assert bm.sha256(FIXTURE) == SCHEMA_SHA256, "answer_schema.json изменён"


def test_visible_contract_matches_fixture():
    """Видимое задание и исполняемые проверки описывают одно и то же.

    Контракт порождается из этой же схемы, поэтому проверка сторожит
    рассинхронизацию, а не выверяет ручную работу. Скрытых правил нет.
    """
    path = os.path.join(APP, "system_prompt.txt")
    assert os.path.isfile(path), "system_prompt.txt отсутствует в /app"
    text = open(path, "r", encoding="utf-8").read()
    low = text.lower()
    for element in SCHEMA.valid_elements_raw:
        assert element.lower() in low, "элемент '" + element + "' не в видимом контракте"
    for category in SCHEMA.valid_categories:
        assert category in low, "категория '" + category + "' не в видимом контракте"
    for type_name in SCHEMA.valid_types:
        assert type_name in low, "тип '" + type_name + "' не в видимом контракте"
    # Пороги ищутся во фразе целиком: голое число совпало бы с любой цифрой
    # в тексте и делало бы проверку тривиальной.
    assert ("changes" in low and str(SCHEMA.min_changes) in text), (
        "порог changes не объявлен в видимом контракте")
    assert ("important_findings" in low and str(SCHEMA.min_findings) in text), (
        "порог findings не объявлен в видимом контракте")
    assert ANALYZED_FILE in text, "имя анализируемого файла не в видимом контракте"


# ── fail_to_pass: структура ─────────────────────────────────────────────────

def test_answer_file_exists():
    assert os.path.isfile(ANSWER), "агент не создал /app/answer.json"


def test_answer_is_valid_json():
    with open(ANSWER, "r", encoding="utf-8") as f:
        json.load(f)


def test_answer_has_required_fields():
    data = _load()
    for key in ("file", "changes", "important_findings"):
        assert key in data, "в ответе нет поля '" + key + "'"
    assert isinstance(data["changes"], list), "changes обязан быть списком"
    assert isinstance(data["important_findings"], list), "findings обязан быть списком"


def test_file_field_names_analyzed_file():
    """Разбор, указывающий на выдуманный файл, контракт не выполняет."""
    data = _load()
    value = bm.norm(data.get("file", "")).replace("\\", "/")
    name = bm.norm(ANALYZED_FILE)
    full = bm.norm(SCHEMA.analyzed_file_path)
    assert value in (name, full) or value.endswith("/" + name), (
        "поле file называет '" + str(data.get("file")) + "', "
        "а анализируется '" + ANALYZED_FILE + "'")


# ── fail_to_pass: changes ───────────────────────────────────────────────────

def test_changes_minimum_count():
    assert len(_changes(_load())) >= SCHEMA.min_changes, (
        "в changes меньше " + str(SCHEMA.min_changes) + " записей")


def test_changes_required_elements_present():
    got = {bm.norm(c.get("element", "")) for c in _changes(_load())}
    missing = SCHEMA.required_in_changes - got
    assert not missing, "в changes не описаны: " + ", ".join(sorted(missing))


def test_changes_elements_exist():
    for c in _changes(_load()):
        el = bm.norm(c.get("element", ""))
        assert el in SCHEMA.valid_elements, "элемент '" + el + "' отсутствует в коде"


def test_changes_types_valid():
    if not SCHEMA.valid_types:
        return
    for c in _changes(_load()):
        t = c.get("type", "")
        assert t in SCHEMA.valid_types, "недопустимый type: '" + str(t) + "'"


def test_changes_descriptions_substantive():
    """Описание объясняет роль элемента, а не повторяет его имя."""
    for c in _changes(_load()):
        d = str(c.get("description", ""))
        assert d.strip(), "описание '" + str(c.get("element")) + "' пустое"
        assert bm.norm(d) != bm.norm(c.get("element", "")), (
            "описание повторяет имя элемента")
        assert len(d) >= SCHEMA.min_detail_len, (
            "описание '" + str(c.get("element")) + "' не раскрывает роль элемента")


def test_changes_not_filler():
    for c in _changes(_load()):
        w = SCHEMA.filler_hit(c.get("description", ""))
        assert w is None, "заглушка '" + str(w) + "' в описании"


# ── fail_to_pass: findings ──────────────────────────────────────────────────

def test_findings_minimum_count():
    """Записи, отрицающие дефект, в объём не засчитываются."""
    subst = SCHEMA.substantive(_findings(_load()))
    assert len(subst) >= SCHEMA.min_findings, (
        "содержательных findings меньше " + str(SCHEMA.min_findings))


def test_findings_categories_valid():
    for f in _findings(_load()):
        cat = f.get("category", "")
        assert cat in SCHEMA.valid_categories, "недопустимая категория: '" + str(cat) + "'"


def test_findings_elements_exist():
    for f in _findings(_load()):
        el = bm.norm(f.get("element", ""))
        assert el in SCHEMA.valid_elements, "элемент '" + el + "' отсутствует в коде"


def test_findings_details_explain_mechanics():
    """detail объясняет механику дефекта: при каком условии он проявляется.

    Правило объявлено в видимом контракте (причинная связка, для code_quality
    не требуется). Буквального названия элемента кода в тексте требовать нельзя:
    правдивое объяснение вроде «адрес задан литералом в глобальной переменной»
    элемент по имени не называет, но дефект описывает верно, а такое требование
    в задании нигде не объявлено. Длина служит только отсечкой пустых заглушек
    и мерой качества не является.
    """
    for f in _findings(_load()):
        d = str(f.get("detail", ""))
        assert d.strip(), "detail пустой"
        cat = bm.norm(f.get("category", ""))
        assert SCHEMA.has_causal_link(d, cat), (
            "detail не объясняет механику: нужна причинная связка "
            "(при каком условии дефект проявляется и к чему приводит)")
        assert len(d) >= SCHEMA.min_detail_len, "detail не раскрывает механику"
        w = SCHEMA.filler_hit(d)
        assert w is None, "заглушка '" + str(w) + "' в detail"


def test_findings_have_finding_field():
    for f in _findings(_load()):
        assert str(f.get("finding", "")).strip(), "поле finding пустое"


def test_findings_no_duplicate_pairs():
    seen = set()
    for f in _findings(_load()):
        key = (bm.norm(f.get("element", "")), bm.norm(f.get("category", "")),
               bm.norm(f.get("finding", "")))
        assert key not in seen, "дублирующаяся запись: " + str(key)
        seen.add(key)


def test_findings_details_distinct():
    """Одно объяснение, скопированное в несколько записей, не закрывает их все."""
    seen = set()
    for f in _findings(_load()):
        d = bm.norm(f.get("detail", ""))
        assert d not in seen, "detail дословно повторяется между записями"
        seen.add(d)


# ── fail_to_pass: покрытие контракта ────────────────────────────────────────

REQUIRED_IDS = [s["id"] for s in SCHEMA.required_findings]


@pytest.mark.parametrize("spec_id", REQUIRED_IDS)
def test_required_finding_present(spec_id):
    """Обязательное замечание закрыто, причём отдельной записью.

    Сопоставление один к одному: «сборная» запись, перечисляющая несколько
    дефектов, закрывает не более одного.
    """
    matched = SCHEMA.matched_ids(_findings(_load()))
    assert spec_id in matched, "не закрыто обязательное замечание: " + spec_id


def test_minimum_alternative_findings():
    if SCHEMA.min_alternative <= 0:
        return
    _, alts = SCHEMA.assignment(_findings(_load()))
    assert len(alts) >= SCHEMA.min_alternative, (
        "закрыто альтернативных замечаний " + str(len(alts)) +
        ", требуется " + str(SCHEMA.min_alternative))
