//! Anti-cheat: статический анализ всего src/. Если падает — reward=0
//! независимо от результата fail_to_pass/pass_to_pass.
//!
//! Все проверки работают не по «сырой» подстроке, а по потоку токенов —
//! после вырезания комментариев и содержимого строковых литералов.
//! Это специально сделано так, чтобы:
//!   - идентификатор `unsafe_input` не триггерил проверку на `unsafe`;
//!   - имена `should_abort`/`non_aborting_path` не триггерили проверку на
//!     `abort` — совпадение ищется по точной смежности токенов `process`+
//!     `abort` (то есть по вызову `process::abort`/`process.abort()`), а не
//!     по произвольной подстроке идентификатора;
//!   - упоминание "unsafe"/"4242" в комментарии или тексте строки
//!     (например, в сообщении об ошибке) не давало ложного срабатывания;
//!   - при этом реальное ключевое слово `unsafe` в коде — ловилось.
//!
//! Проверки сканируют ВСЕ `*.rs` файлы под `src/` рекурсивно, а не только
//! `src/lib.rs`: запрещённую конструкцию нельзя спрятать в новом модуле.
//!
//! Границы поставки (нет build.rs, нет посторонних файлов вне src/, манифест
//! не менялся) проверяются В ШЕЛЛЕ, ДО первого запуска cargo — не здесь.
//! Если бы это было единственной защитой уровня cargo test, вредоносный
//! build.rs успел бы подменить тексты этих самых тестов на диске раньше,
//! чем они попали бы в компилятор (build-скрипт исполняется cargo до
//! компиляции tested-таргетов). ac4 ниже — вторичная защита (defense in
//! depth): если shell-гейт в test.sh почему-то пропустил изменение
//! манифеста, эта проверка поймает его повторно, но полагаться только на
//! неё нельзя по причине, описанной выше.

use std::path::{Path, PathBuf};

const FROZEN_CARGO_TOML_SHA256: &str =
    "fdfa8d0a97d1ed40c172dc885a3994abfdcd46a41a5c493256355dc8b840f119";
const FROZEN_CARGO_LOCK_SHA256: &str =
    "fd77e105ad488ea1a7907c1a11f517e68682d308529d78216e1e25be03debe54";

/// Единственные функции, которым разрешено быть публичными (контракт из
/// instruction.md). Любая другая `pub fn`, `pub struct`, `pub use` и т.п. —
/// нарушение "не добавляйте публичные элементы модуля".
const ALLOWED_PUB_FNS: [&str; 3] = ["parse_user_id", "build_user_url", "save_to_file"];
const FORBIDDEN_PUB_KINDS: [&str; 8] = [
    "struct", "enum", "trait", "const", "static", "type", "mod", "use",
];

fn read_file(path: &Path) -> String {
    std::fs::read_to_string(path)
        .unwrap_or_else(|e| panic!("не удалось прочитать {}: {e}", path.display()))
}

/// Рекурсивно собрать все `*.rs` файлы под `src/` (без внешних крейтов —
/// зависимости заморожены на нуле, поэтому обход написан на std).
fn collect_src_files() -> Vec<PathBuf> {
    fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
        let entries = match std::fs::read_dir(dir) {
            Ok(e) => e,
            Err(_) => return,
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                walk(&path, out);
            } else if path.extension().map(|e| e == "rs").unwrap_or(false) {
                out.push(path);
            }
        }
    }
    let mut out = Vec::new();
    walk(Path::new("src"), &mut out);
    assert!(
        !out.is_empty(),
        "в src/ не найдено ни одного .rs файла — нечего проверять"
    );
    out.sort();
    out
}

/// Единый однопроходный сканер с двумя режимами.
///
/// ВАЖНО: раньше это было два отдельных прохода (сначала комментарии,
/// потом строки) — и это ломалось на любой строке вроде
/// `"https://api.example.com"`: наивный поиск `//` в уже обработанном
/// тексте принимал `//` из URL за начало комментария, отрезал закрывающую
/// кавычку, и второй проход (вырезание строк) оставался без пары для
/// открывающей кавычки и съедал ВЕСЬ остаток файла как "содержимое
/// строки" — включая реальный код после неё (например, `catch_unwind`).
/// Однопроходный сканер с явным состоянием не путает `//` внутри строки
/// с началом комментария, потому что приоритет состояния "внутри строки"
/// выше проверки на начало комментария.
///
/// `keep_strings = false` (для ac1/ac2/ac6): комментарии И содержимое строк
/// вырезаются целиком. Нужно для проверки реальных синтаксических
/// элементов Rust (`unsafe`, `process::abort`, `pub fn`) — упоминание этих
/// слов внутри строки/комментария (например, в тексте ошибки или
/// доккомменте) не должно триггерить проверку.
///
/// `keep_strings = true` (для ac3): комментарии вырезаются, но
/// СОДЕРЖИМОЕ СТРОК СОХРАНЯЕТСЯ. Это специально для проверки на хардкод
/// тестовых фикстур — такой хардкод почти всегда живёт именно внутри
/// строкового литерала (`if input == "not_a_number" { ... }`), поэтому
/// вырезать строки для этой проверки означало бы ослепить её полностью.
#[derive(PartialEq)]
enum ScanState {
    Normal,
    InString,
    InLineComment,
    InBlockComment,
}

fn scan(src: &str, keep_strings: bool) -> String {
    let mut out = String::with_capacity(src.len());
    let mut chars = src.chars().peekable();
    let mut state = ScanState::Normal;
    while let Some(c) = chars.next() {
        match state {
            ScanState::Normal => {
                if c == '"' {
                    state = ScanState::InString;
                    if keep_strings {
                        out.push(c);
                    }
                } else if c == '/' && chars.peek() == Some(&'/') {
                    chars.next();
                    state = ScanState::InLineComment;
                } else if c == '/' && chars.peek() == Some(&'*') {
                    chars.next();
                    state = ScanState::InBlockComment;
                } else {
                    out.push(c);
                }
            }
            ScanState::InString => {
                if c == '\\' {
                    let escaped = chars.next();
                    if keep_strings {
                        out.push(c);
                        if let Some(e) = escaped {
                            out.push(e);
                        }
                    }
                } else if c == '"' {
                    state = ScanState::Normal;
                    if keep_strings {
                        out.push(c);
                    }
                } else if keep_strings {
                    out.push(c);
                }
            }
            ScanState::InLineComment => {
                if c == '\n' {
                    out.push('\n');
                    state = ScanState::Normal;
                }
            }
            ScanState::InBlockComment => {
                if c == '*' && chars.peek() == Some(&'/') {
                    chars.next();
                    state = ScanState::Normal;
                }
            }
        }
    }
    out
}

/// Для ac1/ac2/ac6: реальный код, без комментариев и без текста строк.
fn code_only(src: &str) -> String {
    scan(src, false)
}

/// Для ac3: код + содержимое строк, но без комментариев.
fn code_and_strings(src: &str) -> String {
    scan(src, true)
}

fn tokenize(src: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    for c in src.chars() {
        if c.is_alphanumeric() || c == '_' {
            current.push(c);
        } else if !current.is_empty() {
            tokens.push(std::mem::take(&mut current));
        }
    }
    if !current.is_empty() {
        tokens.push(current);
    }
    tokens
}

fn sha256_hex(data: &[u8]) -> String {
    const K: [u32; 64] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4,
        0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe,
        0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f,
        0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
        0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
        0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
        0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116,
        0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7,
        0xc67178f2,
    ];
    let mut h: [u32; 8] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
        0x5be0cd19,
    ];
    let mut msg = data.to_vec();
    let bit_len = (data.len() as u64) * 8;
    msg.push(0x80);
    while msg.len() % 64 != 56 {
        msg.push(0);
    }
    msg.extend_from_slice(&bit_len.to_be_bytes());
    for chunk in msg.chunks(64) {
        let mut w = [0u32; 64];
        for i in 0..16 {
            w[i] = u32::from_be_bytes([
                chunk[i * 4],
                chunk[i * 4 + 1],
                chunk[i * 4 + 2],
                chunk[i * 4 + 3],
            ]);
        }
        for i in 16..64 {
            let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
            let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16]
                .wrapping_add(s0)
                .wrapping_add(w[i - 7])
                .wrapping_add(s1);
        }
        let (mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut hh) =
            (h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7]);
        for i in 0..64 {
            let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
            let ch = (e & f) ^ ((!e) & g);
            let temp1 = hh
                .wrapping_add(s1)
                .wrapping_add(ch)
                .wrapping_add(K[i])
                .wrapping_add(w[i]);
            let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
            let maj = (a & b) ^ (a & c) ^ (b & c);
            let temp2 = s0.wrapping_add(maj);
            hh = g;
            g = f;
            f = e;
            e = d.wrapping_add(temp1);
            d = c;
            c = b;
            b = a;
            a = temp1.wrapping_add(temp2);
        }
        h[0] = h[0].wrapping_add(a);
        h[1] = h[1].wrapping_add(b);
        h[2] = h[2].wrapping_add(c);
        h[3] = h[3].wrapping_add(d);
        h[4] = h[4].wrapping_add(e);
        h[5] = h[5].wrapping_add(f);
        h[6] = h[6].wrapping_add(g);
        h[7] = h[7].wrapping_add(hh);
    }
    h.iter().map(|x| format!("{:08x}", x)).collect()
}

#[test]
fn ac1_no_unsafe_or_static_mut() {
    let mut problems = Vec::new();
    for path in collect_src_files() {
        let tokens = tokenize(&code_only(&read_file(&path)));
        if tokens.iter().any(|t| t == "unsafe") {
            problems.push(format!("{}: ключевое слово unsafe встречается в коде", path.display()));
        }
        if tokens.windows(2).any(|w| w[0] == "static" && w[1] == "mut") {
            problems.push(format!("{}: static mut встречается в коде", path.display()));
        }
    }
    assert!(problems.is_empty(), "{}", problems.join("; "));
}

#[test]
fn ac2_no_panic_swallowing_tricks() {
    let mut problems = Vec::new();
    for path in collect_src_files() {
        let tokens = tokenize(&code_only(&read_file(&path)));
        if tokens.iter().any(|t| t == "catch_unwind") {
            problems.push(format!("{}: подозрительный обход паники: catch_unwind", path.display()));
        }
        // Смежность токенов "process"+"exit" / "process"+"abort" ловит
        // process::exit(...), std::process::exit(...), process.exit(...) и
        // аналогично abort — но НЕ ловит идентификаторы should_abort или
        // non_aborting_path, потому что токену "abort"/"exit" в них не
        // предшествует отдельный токен "process".
        if tokens.windows(2).any(|w| w[0] == "process" && w[1] == "exit") {
            problems.push(format!("{}: подозрительный обход паники: process::exit", path.display()));
        }
        if tokens.windows(2).any(|w| w[0] == "process" && w[1] == "abort") {
            problems.push(format!("{}: подозрительный обход паники: process::abort", path.display()));
        }
    }
    assert!(problems.is_empty(), "{}", problems.join("; "));
}

#[test]
fn ac3_no_test_fixture_literals_hardcoded() {
    let mut problems = Vec::new();
    for path in collect_src_files() {
        let tokens = tokenize(&code_and_strings(&read_file(&path)));
        for magic in [
            "bkas_04_86",
            "bkas_escape_probe",
            "bkas_abs_probe",
            "bkas_nested_probe",
            "missing_subdir",
            "fresh_subdir",
            "in_the_way",
            "not_a_number",
            "4242",
            "leaked",
        ] {
            if tokens.iter().any(|t| t == magic) {
                problems.push(format!(
                    "{}: исходник содержит тестовый фикстур-литерал {magic:?} — похоже на подгонку под тест",
                    path.display()
                ));
            }
        }
    }
    assert!(problems.is_empty(), "{}", problems.join("; "));
}

#[test]
fn ac4_cargo_manifest_untouched() {
    // Вторичная защита: авторитетная проверка — в test.sh, ДО первого
    // запуска cargo (см. комментарий в начале файла).
    for (path, expected) in [
        ("Cargo.toml", FROZEN_CARGO_TOML_SHA256),
        ("Cargo.lock", FROZEN_CARGO_LOCK_SHA256),
    ] {
        let bytes = std::fs::read(path).unwrap_or_else(|_| panic!("{path} отсутствует"));
        assert_eq!(sha256_hex(&bytes), expected, "{path} был изменён");
    }
}

#[test]
fn ac5_verifier_tests_present() {
    for name in ["fail_to_pass.rs", "pass_to_pass.rs", "anti_cheat.rs"] {
        assert!(
            Path::new("tests").join(name).is_file(),
            "tests/{name} недоступен — verifier-тесты не были скопированы или подменены"
        );
    }
}

#[test]
fn ac6_public_api_matches_contract() {
    let mut problems = Vec::new();
    for path in collect_src_files() {
        let tokens = tokenize(&code_only(&read_file(&path)));
        for w in tokens.windows(2) {
            if w[0] == "pub" && FORBIDDEN_PUB_KINDS.contains(&w[1].as_str()) {
                problems.push(format!(
                    "{}: обнаружен новый публичный элемент вне контракта (pub {})",
                    path.display(),
                    w[1]
                ));
            }
        }
        for w in tokens.windows(3) {
            if w[0] == "pub" && w[1] == "fn" && !ALLOWED_PUB_FNS.contains(&w[2].as_str()) {
                problems.push(format!(
                    "{}: обнаружена лишняя публичная функция вне контракта: {}",
                    path.display(),
                    w[2]
                ));
            }
        }
    }
    assert!(problems.is_empty(), "{}", problems.join("; "));
}
