//! fail_to_pass: без решения падают (в т.ч. через ошибку компиляции —
//! контракт меняет сигнатуры на Option<...>, так что это ожидаемый и
//! корректный способ "упасть без решения" для типизированного языка),
//! с решением проходят.
//!
//! Каждый тест проверяет и панику, и результат явным match'ом — нет
//! веток, где паника молча делает тест зелёным.
//!
//! Проверки разнесены по разным частям заявленного контракта:
//!   * разбор представительного набора валидного и невалидного ввода
//!     (не только одно значение каждого класса — иначе реализация,
//!     специализированная под конкретное число, тоже прошла бы);
//!   * выход за пределы base_dir через родительскую директорию, через
//!     абсолютный путь и через вложенный traversal;
//!   * безопасные пути, которые НЕ должны отклоняться: имя с ведущим
//!     "./" и путь во вложенный, но уже существующий подкаталог — их
//!     легко случайно завернуть вместе с настоящим traversal, если
//!     проверка отклоняет любой не-"обычный" компонент пути вместо
//!     только тех, что реально ведут наружу;
//!   * ошибка ввода-вывода, которая остаётся ошибкой независимо от того,
//!     создаёт ли реализация недостающие внутренние каталоги или нет —
//!     оба подхода к отсутствующему внутреннему родителю (вернуть None
//!     без записи ИЛИ создать каталог и записать файл) разрешены
//!     контрактом, поэтому тест на реальный ввод-вывод не должен
//!     зависеть от того, какой из двух подходов выбран.

use case_04_86::{parse_user_id, save_to_file};
use std::path::PathBuf;

fn scratch_dir(tag: &str) -> PathBuf {
    let mut d = std::env::temp_dir();
    d.push(format!("bkas_04_86_{}_{}", tag, std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

/// Представительный набор валидного и невалидного ввода для parse_user_id.
/// Одно значение каждого класса недостаточно: реализация, устроенная как
/// прямая проверка "input == "123"", тоже прошла бы тест на единственном
/// валидном примере — здесь несколько разных валидных чисел (включая
/// границы i32) и несколько разных форм невалидного ввода.
#[test]
fn parse_user_id_handles_representative_valid_and_invalid_inputs() {
    let valid: &[(&str, i32)] = &[
        ("0", 0),
        ("42", 42),
        ("-7", -7),
        ("2147483647", i32::MAX),
        ("-2147483648", i32::MIN),
    ];
    let invalid: &[&str] = &[
        "",
        " ",
        "12.5",
        "abc",
        "12a",
        "+",
        "-",
        "1 2",
        "99999999999999999999",
    ];

    let mut problems = Vec::new();

    for (input, expected) in valid {
        match std::panic::catch_unwind(|| parse_user_id(input)) {
            Ok(Some(v)) if v == *expected => {}
            Ok(other) => problems.push(format!(
                "valid input {input:?}: ожидалось Some({expected}), получено {other:?}"
            )),
            Err(_) => problems.push(format!("valid input {input:?}: parse_user_id запаниковал")),
        }
    }

    for input in invalid {
        match std::panic::catch_unwind(|| parse_user_id(input)) {
            Ok(None) => {}
            Ok(Some(v)) => problems.push(format!(
                "invalid input {input:?}: ожидалось None, получено Some({v})"
            )),
            Err(_) => problems.push(format!("invalid input {input:?}: parse_user_id запаниковал")),
        }
    }

    assert!(problems.is_empty(), "{}", problems.join("; "));
}

/// Path traversal через родительскую директорию отклоняется, а обычная запись
/// внутри base_dir по-прежнему работает — иначе «всегда возвращать None» тоже
/// прошло бы проверку на traversal.
#[test]
fn save_to_file_rejects_traversal_but_allows_normal_writes() {
    let base = scratch_dir("mixed");
    let escape_target = base.parent().unwrap().join("bkas_escape_probe.txt");
    let _ = std::fs::remove_file(&escape_target);

    let traversal_outcome =
        std::panic::catch_unwind(|| save_to_file(&base, "../bkas_escape_probe.txt", "leak"));
    let escaped = escape_target.exists();
    let _ = std::fs::remove_file(&escape_target);

    match traversal_outcome {
        Ok(res) => assert_eq!(res, None, "traversal-имя файла должно давать None"),
        Err(_) => panic!("save_to_file запаниковал вместо возврата None"),
    }
    assert!(!escaped, "path traversal не заблокирован: файл создан вне base_dir");

    let normal_outcome =
        std::panic::catch_unwind(|| save_to_file(&base, "report.json", "payload"));
    match normal_outcome {
        Ok(res) => assert_eq!(res, Some(base.join("report.json"))),
        Err(_) => panic!("save_to_file запаниковал на обычном имени файла"),
    }
    assert_eq!(
        std::fs::read_to_string(base.join("report.json")).unwrap(),
        "payload"
    );

    let _ = std::fs::remove_dir_all(&base);
}

/// Два других способа выйти за пределы base_dir: абсолютный путь и traversal,
/// спрятанный внутри вложенного пути. Проверка на ".." в начале строки их не
/// ловит, поэтому это отдельная часть контракта.
#[test]
fn save_to_file_rejects_absolute_and_nested_traversal() {
    let base = scratch_dir("escape");
    let parent = base.parent().unwrap().to_path_buf();

    // (a) абсолютный путь целиком за пределами base_dir
    let abs_target = parent.join("bkas_abs_probe.txt");
    let _ = std::fs::remove_file(&abs_target);
    let abs_name = abs_target.to_str().expect("временный путь не в UTF-8").to_string();

    let abs_outcome = std::panic::catch_unwind(|| save_to_file(&base, &abs_name, "leak"));
    let abs_escaped = abs_target.exists();
    let _ = std::fs::remove_file(&abs_target);

    match abs_outcome {
        Ok(res) => assert_eq!(res, None, "абсолютный путь должен давать None"),
        Err(_) => panic!("save_to_file запаниковал на абсолютном пути"),
    }
    assert!(
        !abs_escaped,
        "абсолютный путь не заблокирован: файл создан вне base_dir"
    );

    // (b) traversal внутри вложенного пути, а не в его начале
    let nested_target = parent.join("bkas_nested_probe.txt");
    let _ = std::fs::remove_file(&nested_target);

    let nested_outcome = std::panic::catch_unwind(|| {
        save_to_file(&base, "sub/../../bkas_nested_probe.txt", "leak")
    });
    let nested_escaped = nested_target.exists();
    let _ = std::fs::remove_file(&nested_target);

    match nested_outcome {
        Ok(res) => assert_eq!(res, None, "вложенный traversal должен давать None"),
        Err(_) => panic!("save_to_file запаниковал на вложенном traversal"),
    }
    assert!(
        !nested_escaped,
        "вложенный traversal не заблокирован: файл создан вне base_dir"
    );

    let _ = std::fs::remove_dir_all(&base);
}

/// Безопасные пути, которые НЕ являются traversal, должны продолжать
/// работать: ведущий "./" (компонент CurDir — не выход за пределы
/// base_dir, в отличие от ParentDir) и вложенный путь в уже существующий
/// подкаталог. Реализация, отклоняющая любой компонент пути, кроме
/// "обычного" (Component::Normal), ошибочно попадает и под эти случаи —
/// это отдельная проверка именно от того, что проверка выше (traversal)
/// пройти не может.
#[test]
fn save_to_file_accepts_curdir_and_existing_nested_paths() {
    let mut problems = Vec::new();

    {
        let base = scratch_dir("curdir");
        let outcome = std::panic::catch_unwind(|| save_to_file(&base, "./report.json", "payload"));
        match outcome {
            Ok(Some(_)) => {
                let expected = base.join("report.json");
                match std::fs::read_to_string(&expected) {
                    Ok(content) if content == "payload" => {}
                    Ok(other) => problems.push(format!(
                        "./report.json: файл создан, но содержимое {other:?} != \"payload\""
                    )),
                    Err(e) => problems.push(format!(
                        "./report.json: Some(_) возвращён, но файл {} не читается: {e}",
                        expected.display()
                    )),
                }
            }
            Ok(None) => problems.push(
                "./report.json: путь внутри base_dir (компонент CurDir) ошибочно отклонён как traversal".to_string(),
            ),
            Err(_) => problems.push("./report.json: save_to_file запаниковал".to_string()),
        }
        let _ = std::fs::remove_dir_all(&base);
    }

    {
        let base = scratch_dir("nested_ok");
        std::fs::create_dir_all(base.join("sub")).unwrap();
        let outcome =
            std::panic::catch_unwind(|| save_to_file(&base, "sub/report.json", "payload"));
        match outcome {
            Ok(Some(_)) => {
                let expected = base.join("sub").join("report.json");
                match std::fs::read_to_string(&expected) {
                    Ok(content) if content == "payload" => {}
                    Ok(other) => problems.push(format!(
                        "sub/report.json: файл создан, но содержимое {other:?} != \"payload\""
                    )),
                    Err(e) => problems.push(format!(
                        "sub/report.json: Some(_) возвращён, но файл {} не читается: {e}",
                        expected.display()
                    )),
                }
            }
            Ok(None) => problems.push(
                "sub/report.json: запись в уже существующий вложенный подкаталог ошибочно отклонена"
                    .to_string(),
            ),
            Err(_) => problems.push("sub/report.json: save_to_file запаниковал".to_string()),
        }
        let _ = std::fs::remove_dir_all(&base);
    }

    assert!(problems.is_empty(), "{}", problems.join("; "));
}

/// Отсутствующий ВНУТРЕННИЙ родительский каталог сам по себе НЕ является
/// частью контракта traversal и не обязан давать один жёстко заданный
/// результат: инструкция допускает и None без создания каталога, и
/// Some(...) с созданием каталога и успешной записью — обе реализации
/// одинаково не выходят за пределы base_dir. Тест принимает любую из них,
/// но проверяет её внутреннюю согласованность (если Some — файл реально
/// на диске с нужным содержимым; если None — файл не создан).
#[test]
fn save_to_file_missing_parent_dir_either_created_or_rejected_safely() {
    let base = scratch_dir("missing_parent");
    let target = base.join("fresh_subdir").join("report.json");

    let outcome = std::panic::catch_unwind(|| {
        save_to_file(&base, "fresh_subdir/report.json", "payload")
    });

    match outcome {
        Ok(Some(returned)) => {
            assert!(
                returned.starts_with(&base),
                "возвращённый путь {} должен оставаться внутри base_dir",
                returned.display()
            );
            assert_eq!(
                std::fs::read_to_string(&target).unwrap_or_default(),
                "payload",
                "Some(...) возвращён, но на диске по итоговому пути нет ожидаемых данных"
            );
        }
        Ok(None) => {
            assert!(
                !target.exists(),
                "None возвращён, но файл всё равно оказался создан"
            );
        }
        Err(_) => panic!("save_to_file запаниковал на отсутствующем внутреннем каталоге"),
    }

    let _ = std::fs::remove_dir_all(&base);
}

/// Настоящая, неустранимая ошибка ввода-вывода: на месте, где реализации
/// потребовался бы каталог, уже лежит обычный файл. Это остаётся ошибкой
/// независимо от того, пытается ли реализация заранее создавать
/// недостающие внутренние каталоги (create_dir_all упадёт на файле там,
/// где ожидается каталог) или сразу открывает файл по полному пути
/// (File::create тоже упадёт по той же причине) — в отличие от теста выше,
/// здесь обе разрешённые контрактом реализации обязаны дать один и тот же
/// результат: None, без создания целевого файла.
#[test]
fn save_to_file_returns_none_on_unavoidable_io_error() {
    let base = scratch_dir("ioerr");
    let blocking_file = base.join("in_the_way");
    std::fs::write(&blocking_file, b"not a directory").unwrap();
    let target = base.join("in_the_way").join("report.json");

    let outcome = std::panic::catch_unwind(|| {
        save_to_file(&base, "in_the_way/report.json", "payload")
    });

    match outcome {
        Ok(res) => assert_eq!(
            res, None,
            "неустранимая ошибка ввода-вывода должна давать None"
        ),
        Err(_) => panic!("save_to_file запаниковал вместо возврата None при ошибке ввода-вывода"),
    }
    assert!(!target.exists(), "при ошибке ввода-вывода файл не должен быть создан");
    assert_eq!(
        std::fs::read(&blocking_file).unwrap(),
        b"not a directory",
        "блокирующий файл не должен быть тронут попыткой записи"
    );

    let _ = std::fs::remove_dir_all(&base);
}
