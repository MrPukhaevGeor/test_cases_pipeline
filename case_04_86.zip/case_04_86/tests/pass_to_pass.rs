//! pass_to_pass: регрессия. Специально ограничено функцией
//! `build_user_url` — единственной, чья публичная сигнатура НЕ меняется
//! фиксом (parse_user_id/save_to_file обязаны сменить тип возврата на
//! Option<...>, поэтому тесты на них не могут одинаково компилироваться
//! в base- и oracle-состояниях — они живут в fail_to_pass.rs).
//!
//! Это гарантирует: файл компилируется и проходит ДО решения и ПОСЛЕ.

use case_04_86::build_user_url;

#[test]
fn build_user_url_formats_correctly_for_known_id() {
    assert_eq!(build_user_url(123), "https://api.example.com/users/123");
}

/// Проверяем на нескольких других id (включая ноль и отрицательное
/// значение), чтобы тест нельзя было пройти константной захардкоженной
/// строкой под один конкретный вызов.
#[test]
fn build_user_url_is_computed_not_hardcoded_for_arbitrary_id() {
    assert_eq!(build_user_url(777), "https://api.example.com/users/777");
    assert_eq!(build_user_url(0), "https://api.example.com/users/0");
    assert_eq!(build_user_url(-42), "https://api.example.com/users/-42");
}
