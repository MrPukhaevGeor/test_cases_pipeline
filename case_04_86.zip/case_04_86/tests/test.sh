#!/bin/sh
# Verifier entrypoint. Контракт: одна строка (1|0) в /logs/verifier/reward.txt
set -u

mkdir -p /logs/verifier

# GF-01: канал результата не должен быть под контролем оцениваемого
# процесса. /logs/verifier/ монтируется до старта агента и остаётся
# доступным ему на запись — поэтому агент мог заранее подложить сюда
# reward.json (альтернативный/устаревший формат результата, который
# читается независимо от reward.txt). Чистим ЛЮБОЙ ранее существующий
# файл результата ДО того, как доверять чему-либо, и заново пишем 0 как
# единственное текущее значение — предварительно существующий файл не
# должен влиять на итог ни провалившихся, ни успешных тестов.
rm -f /logs/verifier/reward.json /logs/verifier/reward.txt
echo 0 > /logs/verifier/reward.txt

LOG_DIR=/logs/verifier

fail() {
    printf '%s\n' "$1" | tee -a "$LOG_DIR/verifier.log"
    rm -f "$LOG_DIR/reward.json"
    echo 0 > "$LOG_DIR/reward.txt"
    exit 0
}

cd /app || fail "verifier: /app недоступен"

# --- Фаза -1: целостность поставки — ДО первого запуска cargo -----------
# GF-02: build.rs (или иной управляющий сборкой файл) исполняется cargo'ом
# ДО компиляции тестовых таргетов. Если полагаться только на cargo-тест
# для проверки границ поставки, вредоносный build.rs успеет подменить
# скопированные ниже verifier-тесты на диске раньше, чем они попадут в
# компилятор — сам anti-cheat-гейт можно нейтрализовать изнутри одного
# `cargo test` вызова. Эта проверка — чистый POSIX shell, ни одного
# обращения к cargo, поэтому такой build.rs физически не успевает
# запуститься ни разу, если поставка не прошла проверку.
FROZEN_CARGO_TOML_SHA256="fdfa8d0a97d1ed40c172dc885a3994abfdcd46a41a5c493256355dc8b840f119"
FROZEN_CARGO_LOCK_SHA256="fd77e105ad488ea1a7907c1a11f517e68682d308529d78216e1e25be03debe54"

sha256_of() { sha256sum "$1" 2>/dev/null | awk '{print $1}'; }

[ -f Cargo.toml ] || fail "delivery-integrity: Cargo.toml отсутствует"
[ -f Cargo.lock ] || fail "delivery-integrity: Cargo.lock отсутствует"
[ "$(sha256_of Cargo.toml)" = "$FROZEN_CARGO_TOML_SHA256" ] \
    || fail "delivery-integrity: Cargo.toml изменён"
[ "$(sha256_of Cargo.lock)" = "$FROZEN_CARGO_LOCK_SHA256" ] \
    || fail "delivery-integrity: Cargo.lock изменён"

# Cargo автоматически исполняет файл build.rs в корне пакета, даже если
# он не объявлен явным полем build= в Cargo.toml — само присутствие файла
# достаточно. Поэтому запрещаем его наличие напрямую, а не факт объявления.
[ -e build.rs ] && fail "delivery-integrity: запрещённый build.rs обнаружен в корне проекта"
[ -e .cargo ] && fail "delivery-integrity: запрещённый каталог .cargo обнаружен"
[ -e rust-toolchain.toml ] && fail "delivery-integrity: запрещённый rust-toolchain.toml обнаружен"
[ -e rust-toolchain ] && fail "delivery-integrity: запрещённый rust-toolchain обнаружен"

# Единственные допустимые верхнеуровневые записи в /app на этом этапе:
# Cargo.toml, Cargo.lock, src/ (tests/ появится только следующим шагом,
# после этой проверки).
for entry in * .[!.]* ..?*; do
    [ -e "$entry" ] || continue
    case "$entry" in
        Cargo.toml|Cargo.lock|src) ;;
        *) fail "delivery-integrity: посторонняя запись вне контракта: $entry" ;;
    esac
done

[ -d src ] || fail "delivery-integrity: src/ отсутствует"
if find src -type f ! -name '*.rs' | grep -q .; then
    fail "delivery-integrity: в src/ есть файлы, отличные от *.rs"
fi

# --- Фаза 0: копирование доверенных verifier-тестов ---------------------
# Только теперь, когда поставка подтверждена чистой, можно один раз
# скопировать тесты и запустить cargo — build.rs (если бы прошёл
# предыдущую проверку) исполнился бы здесь, но предыдущая фаза уже
# гарантировала его отсутствие.
mkdir -p tests
cp /tests/*.rs tests/ 2>/dev/null

# --- Фаза 1: anti-cheat gate ---------------------------------------------
# Падает -> reward=0 немедленно, даже если функциональные тесты зелёные.
cargo test --test anti_cheat -q > "$LOG_DIR/anti_cheat.log" 2>&1
AC=$?
cat "$LOG_DIR/anti_cheat.log"
[ "$AC" -eq 0 ] || fail "ANTI-CHEAT FAILED -> reward=0"

# --- Фаза 2: fail_to_pass и pass_to_pass -------------------------------
cargo test --test fail_to_pass --test pass_to_pass -q \
    > "$LOG_DIR/cargo_test.log" 2>&1
STATUS=$?
cat "$LOG_DIR/cargo_test.log"

rm -f "$LOG_DIR/reward.json"
if [ "$STATUS" -eq 0 ]; then
    echo 1 > "$LOG_DIR/reward.txt"
else
    echo 0 > "$LOG_DIR/reward.txt"
fi

exit 0
