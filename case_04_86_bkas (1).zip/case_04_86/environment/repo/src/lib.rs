//! Модуль работы с пользовательскими данными.
//!
//! ВНИМАНИЕ: в текущем виде содержит три известных дефекта:
//! 1. unsafe-доступ к глобальной изменяемой статике для базового URL.
//! 2. Паника (unwrap) при невалидном пользовательском вводе вместо
//!    graceful error handling.
//! 3. Запись файла без проверки на path traversal.

use std::fs::File;
use std::io::Write;
use std::path::{Path, PathBuf};

static mut API_BASE_URL: &str = "https://api.example.com";

/// Разобрать пользовательский ID.
///
/// БАГ: паникует, если input не парсится в i32.
pub fn parse_user_id(input: &str) -> i32 {
    input.parse().unwrap()
}

/// Собрать URL для запроса данных пользователя.
pub fn build_user_url(user_id: i32) -> String {
    unsafe { format!("{}/users/{}", API_BASE_URL, user_id) }
}

/// Сохранить данные в файл filename внутри base_dir.
///
/// БАГ: не проверяет filename на выход за пределы base_dir
/// (path traversal через ../) и паникует при ошибках I/O.
pub fn save_to_file(base_dir: &Path, filename: &str, data: &str) -> PathBuf {
    let path = base_dir.join(filename);
    let mut file = File::create(&path).unwrap();
    file.write_all(data.as_bytes()).unwrap();
    path
}
