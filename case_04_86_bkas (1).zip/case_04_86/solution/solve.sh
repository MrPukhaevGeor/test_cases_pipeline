#!/bin/sh
set -eu

cat > /app/src/lib.rs << 'RUST_EOF'
//! Исправленная версия: без unsafe/static mut, без паник, без path traversal.

use std::fs::File;
use std::io::Write;
use std::path::{Component, Path, PathBuf};

const API_BASE_URL: &str = "https://api.example.com";

pub fn parse_user_id(input: &str) -> Option<i32> {
    input.parse::<i32>().ok()
}

pub fn build_user_url(user_id: i32) -> String {
    format!("{}/users/{}", API_BASE_URL, user_id)
}

pub fn save_to_file(base_dir: &Path, filename: &str, data: &str) -> Option<PathBuf> {
    let candidate = Path::new(filename);
    let escapes = candidate.components().any(|c| {
        matches!(
            c,
            Component::ParentDir | Component::RootDir | Component::Prefix(_)
        )
    });
    if escapes {
        return None;
    }
    let path = base_dir.join(candidate);
    let mut file = File::create(&path).ok()?;
    file.write_all(data.as_bytes()).ok()?;
    Some(path)
}
RUST_EOF
