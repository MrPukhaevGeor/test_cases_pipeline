//! fail_to_pass: без решения падают (в т.ч. через ошибку компиляции —
//! контракт меняет сигнатуры на Option<...>, так что это ожидаемый и
//! корректный способ "упасть без решения" для типизированного языка),
//! с решением проходят.
//!
//! Каждый тест проверяет и панику, и результат явным match'ом — нет
//! веток, где паника молча делает тест зелёным.

use case_04_86::{parse_user_id, save_to_file};
use std::path::PathBuf;

fn scratch_dir(tag: &str) -> PathBuf {
    let mut d = std::env::temp_dir();
    d.push(format!("bkas_04_86_{}_{}", tag, std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

/// Невалидный ввод: не паникует и явно возвращает None.
#[test]
fn parse_invalid_input_never_panics_and_returns_none() {
    match std::panic::catch_unwind(|| parse_user_id("not_a_number")) {
        Ok(value) => assert_eq!(value, None, "невалидный ввод должен вернуть None"),
        Err(_) => panic!("parse_user_id запаниковал на невалидном вводе"),
    }
}

/// Валидный ввод должен по-прежнему давать правильное значение — иначе
/// «всегда возвращать None» тоже прошло бы предыдущий тест.
#[test]
fn parse_valid_input_returns_expected_value() {
    match std::panic::catch_unwind(|| parse_user_id("123")) {
        Ok(value) => assert_eq!(value, Some(123), "валидный ввод должен дать Some(123)"),
        Err(_) => panic!("parse_user_id запаниковал на валидном вводе"),
    }
}

/// Path traversal отклоняется, а обычная запись внутри base_dir по-прежнему
/// работает — иначе «всегда возвращать None» тоже прошло бы проверку
/// на traversal.
#[test]
fn save_to_file_rejects_traversal_but_allows_normal_writes() {
    let base = scratch_dir("mixed");
    let escape_target = base.parent().unwrap().join("bkas_escape_probe.txt");
    let _ = std::fs::remove_file(&escape_target);

    let traversal_outcome =
        std::panic::catch_unwind(|| save_to_file(&base, "../bkas_escape_probe.txt", "leak"));
    let escaped = escape_target.exists();
    let _ = std::fs::remove_file(&escape_target);

    match traversal_outcome {
        Ok(res) => assert_eq!(res, None, "traversal-имя файла должно давать None"),
        Err(_) => panic!("save_to_file запаниковал вместо возврата None"),
    }
    assert!(!escaped, "path traversal не заблокирован: файл создан вне base_dir");

    let normal_outcome =
        std::panic::catch_unwind(|| save_to_file(&base, "report.json", "payload"));
    match normal_outcome {
        Ok(res) => assert_eq!(res, Some(base.join("report.json"))),
        Err(_) => panic!("save_to_file запаниковал на обычном имени файла"),
    }
    assert_eq!(
        std::fs::read_to_string(base.join("report.json")).unwrap(),
        "payload"
    );

    let _ = std::fs::remove_dir_all(&base);
}
