//! pass_to_pass: регрессия. Специально ограничено функцией
//! `build_user_url` — единственной, чья публичная сигнатура НЕ меняется
//! фиксом (parse_user_id/save_to_file обязаны сменить тип возврата на
//! Option<...>, поэтому тесты на них не могут одинаково компилироваться
//! в base- и oracle-состояниях — они живут в fail_to_pass.rs).
//!
//! Это гарантирует: файл компилируется и проходит ДО решения и ПОСЛЕ.

use case_04_86::build_user_url;

#[test]
fn build_user_url_formats_correctly_for_known_id() {
    assert_eq!(build_user_url(123), "https://api.example.com/users/123");
}

/// Проверяем на другом id, чтобы тест нельзя было пройти константной
/// захардкоженной строкой под один конкретный вызов.
#[test]
fn build_user_url_is_computed_not_hardcoded_for_arbitrary_id() {
    assert_eq!(build_user_url(777), "https://api.example.com/users/777");
}
