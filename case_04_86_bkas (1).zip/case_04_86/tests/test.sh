#!/bin/sh
# Verifier entrypoint. Контракт: одна строка (1|0) в /logs/verifier/reward.txt
set -u

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

cd /app || exit 0

# Тестовые файлы не входят в environment/repo (агент их не видит);
# verifier копирует их сюда непосредственно перед прогоном.
mkdir -p /app/tests
cp /tests/*.rs /app/tests/ 2>/dev/null

# --- Фаза 0: anti-cheat gate --------------------------------------------
# Падает -> reward=0 немедленно, даже если функциональные тесты зелёные.
cargo test --test anti_cheat -q > /logs/verifier/anti_cheat.log 2>&1
AC=$?
cat /logs/verifier/anti_cheat.log

if [ "$AC" -ne 0 ]; then
    echo "ANTI-CHEAT FAILED -> reward=0" | tee -a /logs/verifier/anti_cheat.log
    exit 0
fi

# --- Фаза 1+2: fail_to_pass и pass_to_pass -------------------------------
cargo test --test fail_to_pass --test pass_to_pass -q \
    > /logs/verifier/cargo_test.log 2>&1
STATUS=$?
cat /logs/verifier/cargo_test.log

if [ "$STATUS" -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
else
    echo 0 > /logs/verifier/reward.txt
fi

exit 0
