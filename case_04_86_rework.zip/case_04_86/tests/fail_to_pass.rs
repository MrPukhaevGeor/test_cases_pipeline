//! fail_to_pass: без решения падают (в т.ч. через ошибку компиляции —
//! контракт меняет сигнатуры на Option<...>, так что это ожидаемый и
//! корректный способ "упасть без решения" для типизированного языка),
//! с решением проходят.
//!
//! Каждый тест проверяет и панику, и результат явным match'ом — нет
//! веток, где паника молча делает тест зелёным.
//!
//! Проверки разнесены по разным частям заявленного контракта:
//!   * разбор невалидного и валидного ввода;
//!   * выход за пределы base_dir через родительскую директорию, через
//!     абсолютный путь и через вложенный traversal;
//!   * ошибка ввода-вывода, не связанная с traversal, — контракт требует
//!     вернуть None, а не паниковать.

use case_04_86::{parse_user_id, save_to_file};
use std::path::PathBuf;

fn scratch_dir(tag: &str) -> PathBuf {
    let mut d = std::env::temp_dir();
    d.push(format!("bkas_04_86_{}_{}", tag, std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

/// Невалидный ввод: не паникует и явно возвращает None.
#[test]
fn parse_invalid_input_never_panics_and_returns_none() {
    match std::panic::catch_unwind(|| parse_user_id("not_a_number")) {
        Ok(value) => assert_eq!(value, None, "невалидный ввод должен вернуть None"),
        Err(_) => panic!("parse_user_id запаниковал на невалидном вводе"),
    }
}

/// Валидный ввод должен по-прежнему давать правильное значение — иначе
/// «всегда возвращать None» тоже прошло бы предыдущий тест.
#[test]
fn parse_valid_input_returns_expected_value() {
    match std::panic::catch_unwind(|| parse_user_id("123")) {
        Ok(value) => assert_eq!(value, Some(123), "валидный ввод должен дать Some(123)"),
        Err(_) => panic!("parse_user_id запаниковал на валидном вводе"),
    }
}

/// Path traversal через родительскую директорию отклоняется, а обычная запись
/// внутри base_dir по-прежнему работает — иначе «всегда возвращать None» тоже
/// прошло бы проверку на traversal.
#[test]
fn save_to_file_rejects_traversal_but_allows_normal_writes() {
    let base = scratch_dir("mixed");
    let escape_target = base.parent().unwrap().join("bkas_escape_probe.txt");
    let _ = std::fs::remove_file(&escape_target);

    let traversal_outcome =
        std::panic::catch_unwind(|| save_to_file(&base, "../bkas_escape_probe.txt", "leak"));
    let escaped = escape_target.exists();
    let _ = std::fs::remove_file(&escape_target);

    match traversal_outcome {
        Ok(res) => assert_eq!(res, None, "traversal-имя файла должно давать None"),
        Err(_) => panic!("save_to_file запаниковал вместо возврата None"),
    }
    assert!(!escaped, "path traversal не заблокирован: файл создан вне base_dir");

    let normal_outcome =
        std::panic::catch_unwind(|| save_to_file(&base, "report.json", "payload"));
    match normal_outcome {
        Ok(res) => assert_eq!(res, Some(base.join("report.json"))),
        Err(_) => panic!("save_to_file запаниковал на обычном имени файла"),
    }
    assert_eq!(
        std::fs::read_to_string(base.join("report.json")).unwrap(),
        "payload"
    );

    let _ = std::fs::remove_dir_all(&base);
}

/// Два других способа выйти за пределы base_dir: абсолютный путь и traversal,
/// спрятанный внутри вложенного пути. Проверка на ".." в начале строки их не
/// ловит, поэтому это отдельная часть контракта.
#[test]
fn save_to_file_rejects_absolute_and_nested_traversal() {
    let base = scratch_dir("escape");
    let parent = base.parent().unwrap().to_path_buf();

    // (a) абсолютный путь целиком за пределами base_dir
    let abs_target = parent.join("bkas_abs_probe.txt");
    let _ = std::fs::remove_file(&abs_target);
    let abs_name = abs_target.to_str().expect("временный путь не в UTF-8").to_string();

    let abs_outcome = std::panic::catch_unwind(|| save_to_file(&base, &abs_name, "leak"));
    let abs_escaped = abs_target.exists();
    let _ = std::fs::remove_file(&abs_target);

    match abs_outcome {
        Ok(res) => assert_eq!(res, None, "абсолютный путь должен давать None"),
        Err(_) => panic!("save_to_file запаниковал на абсолютном пути"),
    }
    assert!(
        !abs_escaped,
        "абсолютный путь не заблокирован: файл создан вне base_dir"
    );

    // (b) traversal внутри вложенного пути, а не в его начале
    let nested_target = parent.join("bkas_nested_probe.txt");
    let _ = std::fs::remove_file(&nested_target);

    let nested_outcome = std::panic::catch_unwind(|| {
        save_to_file(&base, "sub/../../bkas_nested_probe.txt", "leak")
    });
    let nested_escaped = nested_target.exists();
    let _ = std::fs::remove_file(&nested_target);

    match nested_outcome {
        Ok(res) => assert_eq!(res, None, "вложенный traversal должен давать None"),
        Err(_) => panic!("save_to_file запаниковал на вложенном traversal"),
    }
    assert!(
        !nested_escaped,
        "вложенный traversal не заблокирован: файл создан вне base_dir"
    );

    let _ = std::fs::remove_dir_all(&base);
}

/// Ошибка ввода-вывода, не связанная с traversal: имя остаётся внутри base_dir,
/// но промежуточного каталога не существует, поэтому создать файл нельзя.
/// Контракт требует вернуть None, а не уронить процесс.
#[test]
fn save_to_file_returns_none_on_io_error() {
    let base = scratch_dir("ioerr");
    let target = base.join("missing_subdir").join("report.json");

    let outcome = std::panic::catch_unwind(|| {
        save_to_file(&base, "missing_subdir/report.json", "payload")
    });

    match outcome {
        Ok(res) => assert_eq!(res, None, "ошибка ввода-вывода должна давать None"),
        Err(_) => panic!("save_to_file запаниковал вместо возврата None при ошибке ввода-вывода"),
    }
    assert!(
        !target.exists(),
        "при ошибке ввода-вывода файл не должен быть создан"
    );

    let _ = std::fs::remove_dir_all(&base);
}
